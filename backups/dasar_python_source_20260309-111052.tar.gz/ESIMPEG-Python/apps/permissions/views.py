"""
Permission Management Views
Centralized permission & role management for ALL modules
"""

from django.shortcuts import render, redirect, get_object_or_404
from apps.permissions.decorators import permission_required_403
from django.contrib.auth.models import Permission, Group, User
from django.contrib.contenttypes.models import ContentType
from django.contrib import messages
from django.db.models import Q, Count


@permission_required_403('pengaturan', 'permission_dashboard', 'view')
def permission_dashboard(request):
    """Dashboard overview of all permissions and roles"""
    
    # Get statistics
    total_permissions = Permission.objects.count()
    total_roles = Group.objects.count()
    total_users = User.objects.filter(is_active=True).count()
    
    # Get permissions by app
    permissions_by_app = {}
    for perm in Permission.objects.select_related('content_type').all():
        app_label = perm.content_type.app_label
        if app_label not in permissions_by_app:
            permissions_by_app[app_label] = []
        permissions_by_app[app_label].append(perm)
    
    # Get roles with permission count
    roles = Group.objects.annotate(
        perm_count=Count('permissions')
    ).order_by('name')
    
    context = {
        'total_permissions': total_permissions,
        'total_roles': total_roles,
        'total_users': total_users,
        'permissions_by_app': permissions_by_app,
        'roles': roles,
    }
    
    return render(request, 'permissions/dashboard.html', context)


@permission_required_403('pengaturan', 'permission_rule', 'view')
def permission_list(request):
    """List all permissions from all apps"""
    
    # Get filter parameters
    app_filter = request.GET.get('app', '')
    search = request.GET.get('search', '')
    
    # Base queryset
    permissions = Permission.objects.select_related('content_type').all()
    
    # Apply filters
    if app_filter:
        permissions = permissions.filter(content_type__app_label=app_filter)
    
    if search:
        permissions = permissions.filter(
            Q(name__icontains=search) | Q(codename__icontains=search)
        )
    
    # Get all apps for filter
    apps = ContentType.objects.values_list('app_label', flat=True).distinct().order_by('app_label')
    
    context = {
        'permissions': permissions.order_by('content_type__app_label', 'codename'),
        'apps': apps,
        'current_app': app_filter,
        'search': search,
        'total': permissions.count(),
    }
    
    return render(request, 'permissions/list.html', context)


@permission_required_403('pengaturan', 'permission_rule', 'create')
def permission_create(request):
    """Create new permission"""
    
    if request.method == 'POST':
        app_label = request.POST.get('app_label', '').strip()
        model_name = request.POST.get('model_name', '').strip()
        codename = request.POST.get('codename', '').strip()
        name = request.POST.get('name', '').strip()
        
        if not all([app_label, model_name, codename, name]):
            messages.error(request, 'Semua field harus diisi!')
            return redirect('permissions:permission_create')
        
        # Validate codename format
        if not codename.replace('_', '').isalnum():
            messages.error(request, 'Codename hanya boleh alfanumerik dan underscore!')
            return redirect('permissions:permission_create')
        
        # Get or create content type
        try:
            content_type = ContentType.objects.get(app_label=app_label, model=model_name)
        except ContentType.DoesNotExist:
            messages.error(request, f'Content type {app_label}.{model_name} tidak ditemukan!')
            return redirect('permissions:permission_create')
        
        # Check if permission already exists
        if Permission.objects.filter(content_type=content_type, codename=codename).exists():
            messages.error(request, f'Permission "{codename}" sudah ada!')
            return redirect('permissions:permission_create')
        
        # Create permission
        Permission.objects.create(
            codename=codename,
            name=name,
            content_type=content_type
        )
        
        messages.success(request, f'✅ Permission "{name}" berhasil dibuat!')
        return redirect('permissions:permission_list')
    
    # Get all available content types
    content_types = ContentType.objects.order_by('app_label', 'model')
    apps = {}
    for ct in content_types:
        if ct.app_label not in apps:
            apps[ct.app_label] = []
        apps[ct.app_label].append(ct.model)
    
    context = {
        'apps': apps,
    }
    
    return render(request, 'permissions/form.html', context)


@permission_required_403('pengaturan', 'permission_rule', 'edit')
def permission_edit(request, perm_id):
    """Edit existing permission"""
    
    permission = get_object_or_404(Permission, id=perm_id)
    
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        
        if not name:
            messages.error(request, 'Display name harus diisi!')
            return redirect('permissions:permission_edit', perm_id=perm_id)
        
        permission.name = name
        permission.save()
        
        messages.success(request, f'✅ Permission "{name}" berhasil diupdate!')
        return redirect('permissions:permission_list')
    
    context = {
        'permission': permission,
        'edit_mode': True,
    }
    
    return render(request, 'permissions/form.html', context)


@permission_required_403('pengaturan', 'permission_rule', 'delete')
def permission_delete(request, perm_id):
    """Delete permission"""
    
    permission = get_object_or_404(Permission, id=perm_id)
    
    if request.method == 'POST':
        perm_name = permission.name
        permission.delete()
        
        messages.success(request, f'✅ Permission "{perm_name}" berhasil dihapus!')
        return redirect('permissions:permission_list')
    
    # Get affected roles
    affected_roles = Group.objects.filter(permissions=permission)
    
    context = {
        'permission': permission,
        'affected_roles': affected_roles,
    }
    
    return render(request, 'permissions/delete_confirm.html', context)


# ==================== ROLE MANAGEMENT ====================

@permission_required_403('pengaturan', 'permission_role', 'view')
def role_list(request):
    """List all roles"""
    
    roles = Group.objects.annotate(
        perm_count=Count('permissions'),
        user_count=Count('user')
    ).order_by('name')
    
    context = {
        'roles': roles,
        'total': roles.count(),
    }
    
    return render(request, 'permissions/role_list.html', context)


@permission_required_403('pengaturan', 'permission_role', 'create')
def role_create(request):
    """Create new role"""
    
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        permission_ids = request.POST.getlist('permissions')
        
        if not name:
            messages.error(request, 'Nama role harus diisi!')
            return redirect('permissions:role_create')
        
        if Group.objects.filter(name=name).exists():
            messages.error(request, f'Role "{name}" sudah ada!')
            return redirect('permissions:role_create')
        
        # Create role
        role = Group.objects.create(name=name)
        
        # Assign permissions
        if permission_ids:
            permissions = Permission.objects.filter(id__in=permission_ids)
            role.permissions.set(permissions)
        
        messages.success(request, f'✅ Role "{name}" berhasil dibuat dengan {len(permission_ids)} permissions!')
        return redirect('permissions:role_list')
    
    # Get all permissions grouped by app
    permissions_by_app = {}
    for perm in Permission.objects.select_related('content_type').order_by('content_type__app_label', 'codename'):
        app_label = perm.content_type.app_label
        if app_label not in permissions_by_app:
            permissions_by_app[app_label] = []
        permissions_by_app[app_label].append(perm)
    
    context = {
        'permissions_by_app': permissions_by_app,
    }
    
    return render(request, 'permissions/role_form.html', context)


@permission_required_403('pengaturan', 'permission_role', 'edit')
def role_edit(request, role_id):
    """Edit existing role"""
    
    role = get_object_or_404(Group, id=role_id)
    
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        permission_ids = request.POST.getlist('permissions')
        
        if not name:
            messages.error(request, 'Nama role harus diisi!')
            return redirect('permissions:role_edit', role_id=role_id)
        
        # Check if name changed and already exists
        if name != role.name and Group.objects.filter(name=name).exists():
            messages.error(request, f'Role "{name}" sudah ada!')
            return redirect('permissions:role_edit', role_id=role_id)
        
        role.name = name
        role.save()
        
        # Update permissions
        if permission_ids:
            permissions = Permission.objects.filter(id__in=permission_ids)
            role.permissions.set(permissions)
        else:
            role.permissions.clear()
        
        messages.success(request, f'✅ Role "{name}" berhasil diupdate!')
        return redirect('permissions:role_list')
    
    # Get all permissions grouped by app
    permissions_by_app = {}
    role_permission_ids = set(role.permissions.values_list('id', flat=True))
    
    for perm in Permission.objects.select_related('content_type').order_by('content_type__app_label', 'codename'):
        app_label = perm.content_type.app_label
        if app_label not in permissions_by_app:
            permissions_by_app[app_label] = []
        
        perm.is_selected = perm.id in role_permission_ids
        permissions_by_app[app_label].append(perm)
    
    context = {
        'role': role,
        'permissions_by_app': permissions_by_app,
        'edit_mode': True,
    }
    
    return render(request, 'permissions/role_form.html', context)


@permission_required_403('pengaturan', 'permission_role', 'delete')
def role_delete(request, role_id):
    """Delete role"""
    
    role = get_object_or_404(Group, id=role_id)
    
    if request.method == 'POST':
        role_name = role.name
        role.delete()
        
        messages.success(request, f'✅ Role "{role_name}" berhasil dihapus!')
        return redirect('permissions:role_list')
    
    # Get affected users
    affected_users = User.objects.filter(groups=role)
    
    context = {
        'role': role,
        'affected_users': affected_users,
        'user_count': affected_users.count(),
    }
    
    return render(request, 'permissions/role_delete_confirm.html', context)


@permission_required_403('pengaturan', 'permission_user', 'edit')
def user_permissions(request, user_id):
    """Manage user permissions and roles"""
    
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        role_ids = request.POST.getlist('roles')
        
        # Update roles
        if role_ids:
            roles = Group.objects.filter(id__in=role_ids)
            user.groups.set(roles)
        else:
            user.groups.clear()
        
        messages.success(request, f'✅ Permissions untuk {user.username} berhasil diupdate!')
        return redirect('permissions:permission_dashboard')
    
    # Get all roles
    all_roles = Group.objects.all()
    user_role_ids = set(user.groups.values_list('id', flat=True))
    
    for role in all_roles:
        role.is_selected = role.id in user_role_ids
    
    # Get all permissions for user
    user_permissions = user.get_all_permissions()
    
    context = {
        'user': user,
        'all_roles': all_roles,
        'user_permissions': sorted(user_permissions),
    }
    
    return render(request, 'permissions/user_permissions.html', context)
