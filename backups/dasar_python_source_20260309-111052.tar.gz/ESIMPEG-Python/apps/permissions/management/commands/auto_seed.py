"""
Auto-seed core data when database is empty.
- Seeds permission modules, controls, functions, and rules
- Seeds menu items (base + extend)
- Seeds admin access rules and sidebar link
- Seeds default users (Super Admin + Pegawai biasa)

Run: python manage.py auto_seed
Idempotent: safe to run multiple times.
"""
from django.core.management.base import BaseCommand
from django.core.management import call_command

from apps.permissions.models import MenuItem, PermissionModule


class Command(BaseCommand):
    help = 'Auto seed core data when empty (permissions, menus, admin access)'

    def handle(self, *args, **options):
        self.stdout.write('=' * 70)
        self.stdout.write(self.style.SUCCESS('🧩 AUTO SEED CHECK'))
        self.stdout.write('=' * 70)

        menu_empty = MenuItem.objects.count() == 0
        module_empty = PermissionModule.objects.count() == 0

        if not (menu_empty or module_empty):
            self.stdout.write('Database already has core data. Skipping auto-seed.')
            return

        self.stdout.write('Database looks empty. Running seeders...')
        # Core permissions (modules/controls/functions/rules)
        call_command('seed_permissions')
        # Base menus
        call_command('seed_menus')
        # Extended menus (Akun Saya, Manajemen User/Role)
        call_command('seed_menus_extend')
        # Admin access (rules + sidebar link)
        call_command('seed_admin_access')
        # Default users (Super Admin + Pegawai Biasa)
        call_command('seed_default_users')

        self.stdout.write(self.style.SUCCESS('✅ Auto-seed completed'))
