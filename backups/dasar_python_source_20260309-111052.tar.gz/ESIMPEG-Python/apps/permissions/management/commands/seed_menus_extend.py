"""
Seed extended MenuItem data to mirror common static sidebar items.
Run: python manage.py seed_menus_extend
"""
from django.core.management.base import BaseCommand
from apps.permissions.models import MenuItem


class Command(BaseCommand):
    help = 'Seed extended MenuItem records (SUPER ADMIN + Akun Saya)'

    def handle(self, *args, **options):
        self.stdout.write('=' * 70)
        self.stdout.write(self.style.SUCCESS('🌱 Seeding Extended Menu Items'))
        self.stdout.write('=' * 70)

        created_count = 0

        # SUPER ADMIN group (category 1)
        super_admin_group, created = MenuItem.objects.get_or_create(
            name='Manajemen Aplikasi',
            defaults={
                'type': 'menuItem',
                'icon': 'fas fa-cogs',
                'order': 1,
                'category': 1,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Manajemen Aplikasi (group)')

        # Children under SUPER ADMIN
        items_super_admin = [
            {
                'name': 'Permissions & Roles',
                'permission_key': 'pengaturan.manajemen_permission.view',
                'url_name': 'permissions:dashboard',
                'icon': 'fas fa-shield-alt',
                'order': 1,
            },
            {
                'name': 'Manajemen User',
                'permission_key': 'pengaturan.manajemen_user.view',
                'url_name': 'permissions:users_list',
                'icon': 'fas fa-users-cog',
                'order': 2,
            },
            {
                'name': 'Manajemen Role',
                'permission_key': 'pengaturan.manajemen_permission.view',  # reuse
                'url_name': 'permissions:roles_list',
                'icon': 'fas fa-user-tag',
                'order': 3,
            },
        ]

        for data in items_super_admin:
            obj, created = MenuItem.objects.get_or_create(
                name=data['name'],
                parent=super_admin_group,
                defaults={
                    'permission_key': data['permission_key'],
                    'url_name': data['url_name'],
                    'icon': data['icon'],
                    'type': 'module',
                    'order': data['order'],
                    'category': 1,
                    'is_active': True,
                }
            )
            created_count += int(created)
            if created:
                self.stdout.write(f"  ✓ Created: {data['name']}")

        # AKUN SAYA (we place under category 0: Menu Lainnya)
        akun_group, created = MenuItem.objects.get_or_create(
            name='Akun Saya',
            defaults={
                'type': 'menuItem',
                'icon': 'fas fa-user-circle',
                'order': 99,
                'category': 0,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Akun Saya (group)')

        items_akun = [
            {
                'name': 'Pengaturan Akun',
                'url_name': 'accounts:profile',
                'icon': 'fas fa-user-circle',
                'order': 1,
            },
            {
                'name': 'Logout',
                'url_name': 'accounts:logout',
                'icon': 'fas fa-sign-out-alt',
                'order': 99,
            },
        ]

        for data in items_akun:
            obj, created = MenuItem.objects.get_or_create(
                name=data['name'],
                parent=akun_group,
                defaults={
                    'permission_key': None,  # always visible for logged-in users
                    'url_name': data['url_name'],
                    'icon': data['icon'],
                    'type': 'module',
                    'order': data['order'],
                    'category': 0,
                    'is_active': True,
                }
            )
            created_count += int(created)
            if created:
                self.stdout.write(f"  ✓ Created: {data['name']}")
            else:
                # Ensure existing item matches desired config (especially url_name)
                changed = False
                if obj.url_name != data['url_name']:
                    obj.url_name = data['url_name']
                    changed = True
                if obj.icon != data['icon']:
                    obj.icon = data['icon']
                    changed = True
                if obj.order != data['order']:
                    obj.order = data['order']
                    changed = True
                if obj.category != 0:
                    obj.category = 0
                    changed = True
                if not obj.is_active:
                    obj.is_active = True
                    changed = True
                if changed:
                    obj.save()
                    self.stdout.write(f"  ✓ Updated: {data['name']}")

        # Deactivate legacy 'Profile' menu item if present
        try:
            deactivated = MenuItem.objects.filter(name='Profile', url_name='accounts:profile').update(is_active=False)
            if deactivated:
                self.stdout.write('  ✓ Deactivated legacy Profile menu')
        except Exception:
            pass

        # Rename legacy 'Profile Saya' to 'Pengaturan Akun' if present
        try:
            legacy = MenuItem.objects.filter(name='Profile Saya', parent=akun_group).first()
            if legacy:
                legacy.name = 'Pengaturan Akun'
                legacy.url_name = 'accounts:profile'
                legacy.is_active = True
                legacy.save()
                self.stdout.write('  ✓ Renamed "Profile Saya" to "Pengaturan Akun"')
        except Exception:
            pass

        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS(f'✅ Extended menu seeding completed! Created: {created_count}'))
