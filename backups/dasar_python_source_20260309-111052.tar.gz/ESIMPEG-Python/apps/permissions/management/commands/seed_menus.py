"""
Seed initial MenuItem data for DB-driven sidebar
Run: python manage.py seed_menus
"""
from django.core.management.base import BaseCommand
from apps.permissions.models import MenuItem


class Command(BaseCommand):
    help = 'Seed initial MenuItem records for dynamic sidebar'

    def handle(self, *args, **options):
        self.stdout.write('=' * 70)
        self.stdout.write(self.style.SUCCESS('🌱 Seeding Menu Items'))
        self.stdout.write('=' * 70)

        created_count = 0

        # Dashboard (category 0)
        dashboard, created = MenuItem.objects.get_or_create(
            name='Dashboard',
            defaults={
                'permission_key': 'dashboard.dashboard_main.view',
                'url_name': 'dashboard',
                'icon': 'fas fa-tachometer-alt',
                'type': 'module',
                'order': 1,
                'category': 0,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Dashboard')

        # SUPER ADMIN group (category 1)
        super_admin_group, created = MenuItem.objects.get_or_create(
            name='Manajemen Aplikasi',
            defaults={
                'type': 'menuItem',
                'icon': 'fas fa-cogs',
                'order': 1,
                'category': 1,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Manajemen Aplikasi (group)')

        perm_dash, created = MenuItem.objects.get_or_create(
            name='Permissions & Roles',
            parent=super_admin_group,
            defaults={
                'permission_key': 'pengaturan.manajemen_permission.view',
                'url_name': 'permissions:dashboard',
                'icon': 'fas fa-shield-alt',
                'type': 'module',
                'order': 1,
                'category': 1,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Permissions & Roles')

        # Manajemen Menu (category 1)
        manajemen_menu, created = MenuItem.objects.get_or_create(
            name='Manajemen Menu',
            parent=super_admin_group,
            defaults={
                'permission_key': 'pengaturan.manajemen_menu.view',
                'url_name': 'permissions:menu_list',
                'icon': 'fas fa-sitemap',
                'type': 'module',
                'order': 99,
                'category': 1,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Manajemen Menu')

        # Integrasi (category 4)
        siasn_group, created = MenuItem.objects.get_or_create(
            name='Integrasi SIASN',
            defaults={
                'type': 'menuItem',
                'icon': 'fas fa-sync-alt',
                'order': 1,
                'category': 4,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: Integrasi SIASN (group)')

        siasn_dash, created = MenuItem.objects.get_or_create(
            name='SIASN Dashboard',
            parent=siasn_group,
            defaults={
                'permission_key': 'siasn.siasn_dashboard.view',
                'url_name': 'integrations:siasn_dashboard',
                'icon': 'fas fa-sync-alt',
                'type': 'module',
                'order': 1,
                'category': 4,
                'is_active': True,
            }
        )
        created_count += int(created)
        if created:
            self.stdout.write('  ✓ Created: SIASN Dashboard')

        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS(f'✅ Menu seeding completed! Created: {created_count}'))
