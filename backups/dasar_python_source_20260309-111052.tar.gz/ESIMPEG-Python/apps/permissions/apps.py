from django.apps import AppConfig


class PermissionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.permissions'
    verbose_name = 'Permissions Management'

    def ready(self):
        # Import signal handlers
        from . import signals  # noqa: F401
