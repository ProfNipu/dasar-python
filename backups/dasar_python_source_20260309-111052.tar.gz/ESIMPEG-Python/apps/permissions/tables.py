"""
Django Tables2 Definitions for Permission Management
"""

import django_tables2 as tables
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.utils.html import format_html
from django.urls import reverse
from .models import PermissionFunction, PermissionModule, MenuItem, MenuCategory, PermissionControl, PermissionRule

User = get_user_model()


class UserTable(tables.Table):
    """Table for displaying users with sorting, searching, and pagination"""
    
    # Checkbox column for bulk selection
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'},
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )
    
    # Row number column (auto-increment with pagination)
    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )
    
    # Custom columns - Full Width with Proportional Sizing & Borders
    username = tables.Column(
        verbose_name='Username',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 12%'},
            'td': {'class': 'px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )
    
    email = tables.Column(
        verbose_name='Email',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 whitespace-nowrap text-sm text-gray-500 border border-gray-300'},
        }
    )
    
    name = tables.Column(
        verbose_name='Name',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 45%'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-700 border border-gray-300'},
        },
        orderable=True
    )
    
    group_count = tables.Column(
        verbose_name='Roles',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 whitespace-nowrap text-sm text-center border border-gray-300'},
        },
        orderable=False
    )
    
    is_active = tables.BooleanColumn(
        verbose_name='Status',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 whitespace-nowrap text-sm border border-gray-300'},
        }
    )
    
    
    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 whitespace-nowrap text-sm text-gray-500 border border-gray-300'},
        }
    )
    
    class Meta:
        model = User
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'username', 'email', 'name', 'group_count', 'is_active', 'actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10
    
    def render_row_number(self, record, table):
        """
        Calculate row number with pagination
        Formula: (page_number - 1) * per_page + current_row_in_page
        """
        # Get pagination info
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        
        # Get current row index from counter (set in __init__)
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        
        self._row_counter += 1
        return self._row_counter
    
    def render_is_active(self, value):
        """Custom rendering for active status"""
        if value:
            return format_html(
                '<span class="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">'
                '<i class="fas fa-check-circle mr-1"></i>Active'
                '</span>'
            )
        else:
            return format_html(
                '<span class="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded">'
                '<i class="fas fa-times-circle mr-1"></i>Inactive'
                '</span>'
            )
    
    def render_is_staff(self, value):
        """Custom rendering for staff status"""
        if value:
            return format_html(
                '<span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">'
                '<i class="fas fa-user-shield mr-1"></i>Yes'
                '</span>'
            )
        else:
            return format_html(
                '<span class="inline-block bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded">No</span>'
            )
    
    def render_group_count(self, record):
        """Display group count as badge"""
        count = record.groups.count()
        if count > 0:
            return format_html(
                '<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>',
                count
            )
        else:
            return format_html(
                '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
            )
    
    def render_actions(self, record):
        """Render action buttons"""
        edit_url = reverse('permissions:users_edit', args=[record.id])
        roles_url = reverse('permissions:users_assign_roles', args=[record.id])
        delete_url = reverse('permissions:users_delete', args=[record.id])
        
        return format_html(
            '<div class="flex gap-2">'
            '<a href="{}" class="text-blue-600 hover:text-blue-800" title="Edit User">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-purple-600 hover:text-purple-800" title="Assign Roles">'
            '<i class="fas fa-user-tag"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete User">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, roles_url, delete_url
        )


class MenuCategoryTable(tables.Table):
    """Table for displaying menu categories."""

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 6%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    code = tables.Column(
        verbose_name='Code',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    name = tables.Column(
        verbose_name='Nama Kategori',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    order = tables.Column(
        verbose_name='Order',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    is_active = tables.BooleanColumn(
        verbose_name='Active',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    menus_count = tables.Column(
        verbose_name='Jumlah Menu',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 12%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = MenuCategory
        template_name = 'django_tables2/tailwind.html'
        fields = ('row_number','code','name','order','is_active','menus_count','actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_actions(self, record):
        edit_url = reverse('permissions:menu_category_edit', args=[record.id])
        delete_url = reverse('permissions:menu_category_delete', args=[record.id])
        count = getattr(record, 'menus_count', 0)
        if count and count > 0:
            # Disable delete when linked menus exist
            return format_html(
                '<div class="flex gap-2 justify-center">'
                '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Category">'
                '<i class="fas fa-edit"></i>'
                '</a>'
                '<span class="text-gray-400 cursor-not-allowed" title="Tidak bisa dihapus (dipakai {} menu)">'
                '<i class="fas fa-trash"></i>'
                '</span>'
                '</div>',
                edit_url, count
            )
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Category">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Category">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )

    def render_menus_count(self, record):
        count = getattr(record, 'menus_count', 0)
        if count > 0:
            return format_html(
                '<span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded font-semibold">{}</span>',
                count
            )
        return format_html(
            '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
        )

class FunctionTable(tables.Table):
    """Table for displaying permission functions with selection and actions"""
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'},
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    id = tables.Column(
        verbose_name='ID',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 5%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    nama_fungsi = tables.Column(
        verbose_name='Nama Fungsi',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 20%'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    label_fungsi = tables.Column(
        verbose_name='Label',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 20%'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-700 border border-gray-300'},
        }
    )

    deskripsi_fungsi = tables.Column(
        verbose_name='Deskripsi',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 28%'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-600 border border-gray-300'},
        },
        orderable=False
    )

    rule_count = tables.Column(
        verbose_name='Rules',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = PermissionFunction
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'id', 'nama_fungsi', 'label_fungsi', 'deskripsi_fungsi', 'rule_count', 'actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_rule_count(self, record):
        count = getattr(record, 'rule_count', 0)
        if count > 0:
            return format_html(
                '<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>',
                count
            )
        return format_html(
            '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
        )

    def render_actions(self, record):
        edit_url = reverse('permissions:function_edit', args=[record.id])
        delete_url = reverse('permissions:function_delete', args=[record.id])
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Function">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Function">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )

class ControlTable(tables.Table):
    """Table for displaying permission controls with selection and actions"""
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'},
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    id = tables.Column(
        verbose_name='ID',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 5%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    nama_kontrol = tables.Column(
        verbose_name='Nama Kontrol',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 20%'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    label_kontrol = tables.Column(
        verbose_name='Label',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 20%'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-700 border border-gray-300'},
        }
    )

    deskripsi_kontrol = tables.Column(
        verbose_name='Deskripsi',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 28%'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-600 border border-gray-300'},
        },
        orderable=False
    )

    rule_count = tables.Column(
        verbose_name='Rules',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = PermissionControl
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'id', 'nama_kontrol', 'label_kontrol', 'deskripsi_kontrol', 'rule_count', 'actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_rule_count(self, record):
        count = getattr(record, 'rule_count', 0)
        if count > 0:
            return format_html(
                '<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>',
                count
            )
        return format_html(
            '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
        )

    def render_actions(self, record):
        edit_url = reverse('permissions:control_edit', args=[record.id])
        delete_url = reverse('permissions:control_delete', args=[record.id])
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Control">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Control">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )

class RuleTable(tables.Table):
    """Table for displaying permission rules with selection and actions"""
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'},
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    id = tables.Column(
        verbose_name='ID',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 6%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    module = tables.Column(
        accessor='module.label_module',
        verbose_name='Module',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    control = tables.Column(
        accessor='control.label_kontrol',
        verbose_name='Control',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-700 border border-gray-300'},
        }
    )

    function = tables.Column(
        accessor='function.label_fungsi',
        verbose_name='Function',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm text-gray-700 border border-gray-300'},
        }
    )

    permission_string = tables.Column(
        verbose_name='Permission String',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-xs text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    is_active = tables.BooleanColumn(
        verbose_name='Status',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    role_count = tables.Column(
        verbose_name='Roles',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 12%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = PermissionRule
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection','row_number','id','module','control','function','permission_string','is_active','role_count','actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_is_active(self, value):
        if value:
            return format_html('<span class="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded"><i class="fas fa-check-circle mr-1"></i>Active</span>')
        return format_html('<span class="inline-block bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded">Inactive</span>')

    def render_role_count(self, record):
        count = getattr(record, 'role_count', 0)
        if count > 0:
            return format_html('<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>', count)
        return format_html('<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>')

    def render_actions(self, record):
        edit_url = reverse('permissions:rule_edit', args=[record.id])
        delete_url = reverse('permissions:rule_delete', args=[record.id])
        count = getattr(record, 'role_count', 0)
        if count and count > 0:
            return format_html(
                '<div class="flex gap-2 justify-center">'
                '<a href="{}" class="text-amber-600 hover:text-amber-800" title="Edit Rule">'
                '<i class="fas fa-edit"></i>'
                '</a>'
                '<span class="text-gray-400 cursor-not-allowed" title="Tidak bisa dihapus (dipakai {} role)">'
                '<i class="fas fa-trash"></i>'
                '</span>'
                '</div>',
                edit_url, count
            )
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-amber-600 hover:text-amber-800" title="Edit Rule">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Rule">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )

class RoleTable(tables.Table):
    """Table for displaying roles/groups with sorting, searching, and pagination"""
    
    # Checkbox column for bulk selection
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'},
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )
    
    # Row number column (auto-increment with pagination)
    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )
    
    # ID column
    id = tables.Column(
        verbose_name='ID',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 5%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )
    
    # Role name column
    name = tables.Column(
        verbose_name='Nama Role',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 30%'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )
    
    # Users count column
    users_count = tables.Column(
        verbose_name='Users',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )
    
    # Permissions count column
    permissions_count = tables.Column(
        verbose_name='Permissions',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )
    
    # Actions column
    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )
    
    class Meta:
        model = Group
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'id', 'name', 'users_count', 'permissions_count', 'actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10
    
    def render_row_number(self, record, table):
        """Calculate row number with pagination"""
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        
        self._row_counter += 1
        return self._row_counter
    
    def render_users_count(self, record):
        """Display users count as badge"""
        count = record.user_set.count()
        if count > 0:
            return format_html(
                '<span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded font-semibold">'
                '<i class="fas fa-users mr-1"></i>{}'
                '</span>',
                count
            )
        else:
            return format_html(
                '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
            )
    
    def render_permissions_count(self, record):
        """Display permissions count as badge"""
        count = record.permissions.count()
        if count > 0:
            return format_html(
                '<span class="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded font-semibold">'
                '<i class="fas fa-shield-alt mr-1"></i>{}'
                '</span>',
                count
            )
        else:
            return format_html(
                '<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>'
            )
    
    def render_actions(self, record):
        """Render action buttons"""
        edit_url = reverse('permissions:roles_edit', args=[record.id])
        permissions_url = reverse('permissions:role_rule_manage', args=[record.id])
        delete_url = reverse('permissions:roles_delete', args=[record.id])
        
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Role">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-green-600 hover:text-green-800" title="Assign Permissions">'
            '<i class="fas fa-shield-alt"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Role">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, permissions_url, delete_url
        )


class ModuleTable(tables.Table):
    """Table for displaying modules with rules count (no selection checkbox for dashboard)"""

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    order = tables.Column(
        verbose_name='Order',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 6%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    module = tables.Column(
        empty_values=(),
        verbose_name='Module',
        order_by=('label_module',),
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    icon = tables.Column(
        verbose_name='Icon',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    status = tables.Column(
        empty_values=(),
        verbose_name='Status',
        order_by=('is_active',),
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    rule_count = tables.Column(
        verbose_name='Rules',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = PermissionModule
        template_name = 'django_tables2/tailwind.html'
        fields = ('row_number','order','module','icon','status','rule_count','actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_module(self, record):
        return format_html(
            '<div class="font-semibold text-gray-800">{}</div>'
            '<div class="text-gray-500 text-xs">{}</div>',
            record.label_module,
            record.nama_module
        )

    def render_icon(self, record):
        return format_html('<i class="{}"></i>', record.icon)

    def render_status(self, record):
        if record.is_active:
            return format_html('<span class="inline-block bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">Active</span>')
        return format_html('<span class="inline-block bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-medium">Inactive</span>')

    def render_rule_count(self, record):
        count = getattr(record, 'rule_count', 0)
        if count > 0:
            return format_html('<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>', count)
        return format_html('<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>')

    def render_actions(self, record):
        edit_url = reverse('permissions:module_edit', args=[record.id])
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Module">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '</div>',
            edit_url
        )


class ModuleManageTable(tables.Table):
    """Table for modules on the dedicated modules list page (with selection)."""

    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs={
            'th__input': {'id': 'select-all-top', 'class': 'w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'td__input': {'class': 'row-checkbox w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500'},
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 3%'} ,
            'td': {'class': 'px-3 py-3 text-center border border-gray-300'},
        },
        orderable=False
    )

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    order = tables.Column(
        verbose_name='Order',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 6%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    module = tables.Column(
        empty_values=(),
        verbose_name='Module',
        order_by=('label_module',),
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    icon = tables.Column(
        verbose_name='Icon',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    status = tables.Column(
        empty_values=(),
        verbose_name='Status',
        order_by=('is_active',),
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    rule_count = tables.Column(
        verbose_name='Rules',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        },
        orderable=False
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = PermissionModule
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection','row_number','order','module','icon','status','rule_count','actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_module(self, record):
        return format_html(
            '<div class="font-semibold text-gray-800">{}</div>'
            '<div class="text-gray-500 text-xs">{}</div>',
            record.label_module,
            record.nama_module
        )

    def render_icon(self, record):
        return format_html('<i class="{}"></i>', record.icon)

    def render_status(self, record):
        if record.is_active:
            return format_html('<span class="inline-block bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">Active</span>')
        return format_html('<span class="inline-block bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-medium">Inactive</span>')

    def render_rule_count(self, record):
        count = getattr(record, 'rule_count', 0)
        if count > 0:
            return format_html('<span class="inline-block bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded font-semibold">{}</span>', count)
        return format_html('<span class="inline-block bg-gray-100 text-gray-500 text-xs px-2 py-1 rounded">0</span>')

    def render_actions(self, record):
        edit_url = reverse('permissions:module_edit', args=[record.id])
        delete_url = reverse('permissions:module_delete', args=[record.id])
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Module">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Module">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )


class MenuItemTable(tables.Table):
    """Table for displaying MenuItem records."""

    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 4%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    order = tables.Column(
        verbose_name='Order',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 6%'},
            'td': {'class': 'px-3 py-3 text-center text-sm font-medium text-gray-700 border border-gray-300'},
        }
    )

    name = tables.Column(
        verbose_name='Nama Menu',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm font-medium text-gray-900 border border-gray-300'},
        }
    )

    type = tables.Column(
        verbose_name='Type',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    category = tables.Column(
        verbose_name='Category',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    parent = tables.Column(
        verbose_name='Parent',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-sm border border-gray-300'},
        }
    )

    permission_key = tables.Column(
        verbose_name='Permission Key',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-xs text-gray-700 border border-gray-300'},
        },
        orderable=False
    )

    link = tables.Column(
        empty_values=(),
        verbose_name='Link',
        attrs={
            'th': {'class': 'px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300'},
            'td': {'class': 'px-3 py-3 text-xs text-blue-700 border border-gray-300'},
        },
        orderable=False
    )

    is_active = tables.BooleanColumn(
        verbose_name='Active',
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 8%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    actions = tables.Column(
        verbose_name='Actions',
        empty_values=(),
        orderable=False,
        attrs={
            'th': {'class': 'px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border border-gray-300', 'style': 'width: 10%'},
            'td': {'class': 'px-3 py-3 text-center text-sm border border-gray-300'},
        }
    )

    class Meta:
        model = MenuItem
        template_name = 'django_tables2/tailwind.html'
        fields = ('row_number','order','name','type','category','parent','permission_key','link','is_active','actions')
        attrs = {
            'class': 'w-full table-fixed border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_row_number(self, record, table):
        page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
        per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
        if not hasattr(self, '_row_counter'):
            self._row_counter = (page_number - 1) * per_page
        self._row_counter += 1
        return self._row_counter

    def render_parent(self, record):
        return record.parent.name if record.parent else '-'

    def render_type(self, value):
        v = str(value or '').lower()
        return 'Submenu' if v == 'menuitem' else 'Module'

    def render_category(self, record):
        try:
            cat = MenuCategory.objects.filter(code=record.category).first()
            if cat:
                url = reverse('permissions:menu_category_edit', args=[cat.id])
                return format_html('<a href="{}" class="text-blue-600 hover:underline">{}</a>', url, cat.name)
        except Exception:
            pass
        mapping = {1: 'SUPER ADMIN', 2: 'Data Pegawai', 3: 'Laporan Data', 4: 'Manajemen Integrasi', 0: 'Menu Lainnya'}
        return mapping.get(record.category or 0, 'Menu Lainnya')

    def render_link(self, record):
        if record.url_name:
            return format_html('<span class="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded">{}</span>', record.url_name)
        if record.external_url:
            return format_html('<a href="{}" target="_blank" class="underline">{}</a>', record.external_url, record.external_url)
        return '-'

    def render_is_active(self, value):
        if value:
            return format_html('<span class="inline-block bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">Active</span>')
        return format_html('<span class="inline-block bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-medium">Inactive</span>')

    def render_actions(self, record):
        edit_url = reverse('permissions:menu_edit', args=[record.id])
        delete_url = reverse('permissions:menu_delete', args=[record.id])
        return format_html(
            '<div class="flex gap-2 justify-center">'
            '<a href="{}" class="text-orange-600 hover:text-orange-800" title="Edit Menu">'
            '<i class="fas fa-edit"></i>'
            '</a>'
            '<a href="{}" class="text-red-600 hover:text-red-800" title="Delete Menu">'
            '<i class="fas fa-trash"></i>'
            '</a>'
            '</div>',
            edit_url, delete_url
        )
