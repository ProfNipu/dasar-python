
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Count, Q
from django.db import IntegrityError
from django_tables2 import RequestConfig
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.urls import reverse
import json
from urllib.parse import quote as urlquote

from apps.permissions.decorators import permission_required_403
from apps.permissions.models import UserTableSelection
from apps.permissions.tables import UserTable
# Reuse existing export helpers to avoid duplication during incremental refactor
from apps.permissions.views_granular import (
    export_users_csv,
    export_users_excel,
    export_users_pdf,
)

from apps.permissions.forms import UserCreateForm, UserEditForm

User = get_user_model()


@permission_required_403('pengaturan', 'permission_user', 'view')
def user_list(request):
    """List all users with django-tables2 + HTMX support + Search + Export"""
    # Get search query from GET or POST (POST for download with filter)
    search_query = request.GET.get('search', '').strip() or request.POST.get('search', '').strip()

    # Get status filter from POST (download) or GET (datatable), prioritize POST
    status_filter = request.POST.get('status') or request.GET.get('status', 'all')

    # Queryset with group count annotation
    users = User.objects.annotate(group_count=Count('groups'))

    # Handle JSON selection save/load (AJAX only)
    if (
        request.method == 'POST'
        and request.headers.get('X-Requested-With') == 'XMLHttpRequest'
        and (request.headers.get('Content-Type') or '').startswith('application/json')
    ):
        import json
        data = json.loads(request.body)
        action = data.get('action')
        if action == 'save_selection':
            page_key = data.get('page_key', 'user_list')
            selected_ids = data.get('selected_ids', [])
            UserTableSelection.objects.update_or_create(
                user=request.user,
                page_key=page_key,
                defaults={'selected_ids': selected_ids}
            )
            return JsonResponse({'success': True, 'count': len(selected_ids)})
        elif action == 'load_selection':
            page_key = data.get('page_key', 'user_list')
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
            except UserTableSelection.DoesNotExist:
                return JsonResponse({'success': True, 'selected_ids': []})

    # Handle selected actions (form-encoded POST)
    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')

        if selected_ids:
            selected_users = User.objects.filter(id__in=selected_ids).annotate(
                group_count=Count('groups')
            ).order_by('-is_active', 'username')

            if action == 'export_csv':
                return export_users_csv(selected_users)
            elif action == 'export_excel':
                return export_users_excel(selected_users)
            elif action == 'export_pdf':
                return export_users_pdf(selected_users)
            elif action == 'bulk_delete':
                deleted_count = selected_users.count()
                deleted_usernames = list(selected_users.values_list('username', flat=True))
                selected_users.delete()
                UserTableSelection.objects.filter(user=request.user, page_key='user_list').delete()
                # AJAX: return JSON
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'success': True,
                        'deleted': deleted_count,
                        'ids': selected_ids,
                        'names': deleted_usernames[:5],
                    })
                messages.success(request, f'{deleted_count} user berhasil dihapus: {", ".join(deleted_usernames[:5])}{"..." if deleted_count > 5 else ""}')
                return redirect('permissions:users_list')
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
            messages.error(request, 'Tidak ada item yang dipilih')
            return redirect('permissions:users_list')

    # Apply filters for GET
    if search_query:
        users = users.filter(
            Q(username__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(name__icontains=search_query)
        )
    status_filter_value = status_filter
    if status_filter_value == 'active':
        users = users.filter(is_active=True)
    elif status_filter_value == 'inactive':
        users = users.filter(is_active=False)

    users = users.order_by('id')

    table = UserTable(users)
    RequestConfig(request, paginate={'per_page': 10}).configure(table)

    context = {
        'table': table,
        'total': users.count(),
        'active_count': users.filter(is_active=True).count(),
        'search_query': search_query,
    }

    # HTMX partial
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'permissions/granular/_user_table.html', context)
    return render(request, 'permissions/granular/user_list.html', context)


@permission_required_403('pengaturan', 'permission_user', 'create')
def users_create(request):
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            full_name = f"{cd.get('first_name') or ''} {cd.get('last_name') or ''}".strip() or cd['username']
            try:
                user = User.objects.create_user(
                    username=cd['username'],
                    email=(cd.get('email') or None),
                    password=cd['password'],
                    name=full_name,
                    is_active=bool(cd.get('is_active')),
                )
            except IntegrityError:
                # Likely email/username uniqueness
                if cd.get('email'):
                    form.add_error('email', 'Email sudah digunakan.')
                else:
                    form.add_error('username', 'Username sudah digunakan.')
                errors_list = []
                field_errors = {}
                for field, errors in form.errors.items():
                    field_errors[field] = [str(e) for e in errors]
                    for err in errors:
                        errors_list.append(str(err))
                resp = HttpResponse(status=204)
                resp['HX-Trigger'] = json.dumps({'user-form-invalid': {'errors': errors_list, 'fieldErrors': field_errors}})
                return resp

            # HTMX-friendly success: show SweetAlert then redirect
            if request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                resp = HttpResponse(status=204)
                resp['HX-Trigger'] = json.dumps({
                    'user-form-success': {
                        'message': f'User "{user.username}" berhasil dibuat!',
                        'redirect': reverse('permissions:users_list')
                    }
                })
                return resp
            # Non-HTMX: redirect with SweetAlert query params (no toast)
            msg = f'User "{user.username}" berhasil dibuat!'
            return redirect(f"{reverse('permissions:users_list')}?swal=success&msg={urlquote(msg)}")
        pass
        errors_list = []
        field_errors = {}
        for field, errors in form.errors.items():
            field_errors[field] = [str(e) for e in errors]
            for err in errors:
                errors_list.append(str(err))
        resp = HttpResponse(status=204)
        resp['HX-Trigger'] = json.dumps({'user-form-invalid': {'errors': errors_list, 'fieldErrors': field_errors}})
        return resp
    form = UserCreateForm(initial={'is_active': True})
    return render(request, 'permissions/granular/user_form.html', {
        'form': form,
        'edit_mode': False,
    })


@permission_required_403('pengaturan', 'permission_user', 'edit')
def users_edit(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = UserEditForm(request.POST, user=user)
        if form.is_valid():
            cd = form.cleaned_data
            new_username = cd.get('username') or user.username
            new_email = (cd.get('email') or None)
            fname = cd.get('first_name') or ''
            lname = cd.get('last_name') or ''
            new_name = (f"{fname} {lname}".strip() or (user.name or user.username))
            new_is_active = bool(cd.get('is_active'))
            pwd = cd.get('password') or ''

            # If nothing changes, treat as success (no-op) and show SweetAlert success
            has_changes = (
                new_username != user.username or
                (new_email or '') != (user.email or '') or
                (new_name or '') != (user.name or '') or
                new_is_active != bool(user.is_active) or
                bool(pwd)
            )
            if not has_changes:
                if request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    resp = HttpResponse(status=204)
                    resp['HX-Trigger'] = json.dumps({
                        'user-form-success': {
                            'message': f'User "{user.username}" tidak ada perubahan.',
                            'redirect': reverse('permissions:users_list')
                        }
                    })
                    return resp
                msg = f'User "{user.username}" tidak ada perubahan.'
                return redirect(f"{reverse('permissions:users_list')}?swal=success&msg={urlquote(msg)}")

            # Apply changes and save
            user.username = new_username
            user.email = new_email
            user.name = new_name
            user.is_active = new_is_active
            if pwd:
                user.set_password(pwd)
            try:
                user.save()
            except IntegrityError:
                if cd.get('email'):
                    form.add_error('email', 'Email sudah digunakan.')
                else:
                    form.add_error('username', 'Username sudah digunakan.')
                errors_list = []
                field_errors = {}
                for field, errors in form.errors.items():
                    field_errors[field] = [str(e) for e in errors]
                    for err in errors:
                        errors_list.append(str(err))
                resp = HttpResponse(status=204)
                resp['HX-Trigger'] = json.dumps({'user-form-invalid': {'errors': errors_list, 'fieldErrors': field_errors}})
                return resp
            # HTMX-friendly success: show SweetAlert then redirect
            if request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                resp = HttpResponse(status=204)
                resp['HX-Trigger'] = json.dumps({
                    'user-form-success': {
                        'message': f'User "{user.username}" berhasil diupdate!',
                        'redirect': reverse('permissions:users_list')
                    }
                })
                return resp
            # Non-HTMX: redirect with SweetAlert query params (no toast)
            msg = f'User "{user.username}" berhasil diupdate!'
            return redirect(f"{reverse('permissions:users_list')}?swal=success&msg={urlquote(msg)}")
        pass
        errors_list = []
        field_errors = {}
        for field, errors in form.errors.items():
            field_errors[field] = [str(e) for e in errors]
            for err in errors:
                errors_list.append(str(err))
        resp = HttpResponse(status=204)
        resp['HX-Trigger'] = json.dumps({'user-form-invalid': {'errors': errors_list, 'fieldErrors': field_errors}})
        return resp
    form = UserEditForm(initial={
        'username': user.username,
        'first_name': user.name,
        'last_name': '',
        'email': user.email or '',
        'is_active': user.is_active,
    }, user=user)
    user_obj = {
        'username': user.username,
        'first_name': user.name,
        'last_name': '',
        'email': user.email or '',
        'is_active': user.is_active,
    }
    return render(request, 'permissions/granular/user_form.html', {
        'form': form,
        'user_obj': user_obj,
        'edit_mode': True,
    })


@permission_required_403('pengaturan', 'permission_user', 'delete')
def users_delete(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if user.is_superuser:
        messages.error(request, 'Tidak bisa menghapus superuser!')
        return redirect('permissions:users_list')
    if user.id == request.user.id:
        messages.error(request, 'Tidak bisa menghapus diri sendiri!')
        return redirect('permissions:users_list')
    if request.method == 'POST':
        username = user.username
        user.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'deleted': user_id, 'name': username})
        messages.success(request, f'✅ User "{username}" berhasil dihapus!')
        return redirect('permissions:users_list')
    return render(request, 'permissions/granular/user_delete.html', { 'user_obj': user })


@permission_required_403('pengaturan', 'permission_user', 'edit')
def users_assign_roles(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        role_ids = request.POST.getlist('roles')
        user.groups.clear()
        if role_ids:
            roles = Group.objects.filter(id__in=role_ids)
            user.groups.set(roles)
        messages.success(request, f'✅ Roles untuk user "{user.username}" berhasil diupdate!')
        return redirect('permissions:users_list')
    all_roles = Group.objects.all().order_by('name')
    user_role_ids = set(user.groups.values_list('id', flat=True))
    for role in all_roles:
        role.is_selected = role.id in user_role_ids
    return render(request, 'permissions/granular/user_assign_roles.html', {
        'user_obj': user,
        'all_roles': all_roles,
        'selected_count': len(user_role_ids),
    })
