# Package for views grouped by route prefix `manajemen-aplikasi`
# Intentionally thin wrappers around existing granular views for incremental refactor.
