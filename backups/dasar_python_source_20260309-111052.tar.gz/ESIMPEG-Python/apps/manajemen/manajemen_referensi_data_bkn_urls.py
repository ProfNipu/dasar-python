from django.urls import path

from apps.manajemen import manajemen_referensi_data_bkn as views

app_name = 'manajemen_referensi_data_bkn'

urlpatterns = [
    path('bkn-lokasi-kerja/', views.bkn_lokasi_kerja_list, name='bkn_lokasi_kerja_list'),
    path('bkn-lokasi-kerja/create/', views.bkn_lokasi_kerja_create, name='bkn_lokasi_kerja_create'),
    path('bkn-lokasi-kerja/<int:pk>/edit/', views.bkn_lokasi_kerja_edit, name='bkn_lokasi_kerja_edit'),
    path('bkn-lokasi-kerja/<int:pk>/delete/', views.bkn_lokasi_kerja_delete, name='bkn_lokasi_kerja_delete'),

    path('bkn-alasan-hukuman/', views.bkn_alasan_hukuman_list, name='bkn_alasan_hukuman_list'),
    path('bkn-alasan-hukuman/create/', views.bkn_alasan_hukuman_create, name='bkn_alasan_hukuman_create'),
    path('bkn-alasan-hukuman/<int:pk>/edit/', views.bkn_alasan_hukuman_edit, name='bkn_alasan_hukuman_edit'),
    path('bkn-alasan-hukuman/<int:pk>/delete/', views.bkn_alasan_hukuman_delete, name='bkn_alasan_hukuman_delete'),

    path('bkn-jenis-hukuman/', views.bkn_jenis_hukuman_list, name='bkn_jenis_hukuman_list'),
    path('bkn-jenis-hukuman/create/', views.bkn_jenis_hukuman_create, name='bkn_jenis_hukuman_create'),
    path('bkn-jenis-hukuman/<int:pk>/edit/', views.bkn_jenis_hukuman_edit, name='bkn_jenis_hukuman_edit'),
    path('bkn-jenis-hukuman/<int:pk>/delete/', views.bkn_jenis_hukuman_delete, name='bkn_jenis_hukuman_delete'),

    path('bkn-tingkat-hukdis/', views.bkn_tingkat_hukdis_list, name='bkn_tingkat_hukdis_list'),
    path('bkn-tingkat-hukdis/create/', views.bkn_tingkat_hukdis_create, name='bkn_tingkat_hukdis_create'),
    path('bkn-tingkat-hukdis/<int:pk>/edit/', views.bkn_tingkat_hukdis_edit, name='bkn_tingkat_hukdis_edit'),
    path('bkn-tingkat-hukdis/<int:pk>/delete/', views.bkn_tingkat_hukdis_delete, name='bkn_tingkat_hukdis_delete'),

    path('bkn-nomorpp-hukdis/', views.bkn_nomorpp_hukdis_list, name='bkn_nomorpp_hukdis_list'),
    path('bkn-nomorpp-hukdis/create/', views.bkn_nomorpp_hukdis_create, name='bkn_nomorpp_hukdis_create'),
    path('bkn-nomorpp-hukdis/<int:pk>/edit/', views.bkn_nomorpp_hukdis_edit, name='bkn_nomorpp_hukdis_edit'),
    path('bkn-nomorpp-hukdis/<int:pk>/delete/', views.bkn_nomorpp_hukdis_delete, name='bkn_nomorpp_hukdis_delete'),

    path('bkn-jabatan-fungsional/', views.bkn_jabatan_fungsional_list, name='bkn_jabatan_fungsional_list'),
    path('bkn-jabatan-fungsional/create/', views.bkn_jabatan_fungsional_create, name='bkn_jabatan_fungsional_create'),
    path('bkn-jabatan-fungsional/<int:pk>/edit/', views.bkn_jabatan_fungsional_edit, name='bkn_jabatan_fungsional_edit'),
    path('bkn-jabatan-fungsional/<int:pk>/delete/', views.bkn_jabatan_fungsional_delete, name='bkn_jabatan_fungsional_delete'),

    path('bkn-jenis-kenaikan-pangkat/', views.bkn_jenis_kenaikan_pangkat_list, name='bkn_jenis_kenaikan_pangkat_list'),
    path('bkn-jenis-kenaikan-pangkat/create/', views.bkn_jenis_kenaikan_pangkat_create, name='bkn_jenis_kenaikan_pangkat_create'),
    path('bkn-jenis-kenaikan-pangkat/<int:pk>/edit/', views.bkn_jenis_kenaikan_pangkat_edit, name='bkn_jenis_kenaikan_pangkat_edit'),
    path('bkn-jenis-kenaikan-pangkat/<int:pk>/delete/', views.bkn_jenis_kenaikan_pangkat_delete, name='bkn_jenis_kenaikan_pangkat_delete'),

    path('bkn-jenis-diklat/', views.bkn_jenis_diklat_list, name='bkn_jenis_diklat_list'),
    path('bkn-jenis-diklat/create/', views.bkn_jenis_diklat_create, name='bkn_jenis_diklat_create'),
    path('bkn-jenis-diklat/<int:pk>/edit/', views.bkn_jenis_diklat_edit, name='bkn_jenis_diklat_edit'),
    path('bkn-jenis-diklat/<int:pk>/delete/', views.bkn_jenis_diklat_delete, name='bkn_jenis_diklat_delete'),

    path('bkn-daftar-kppn/', views.bkn_daftar_kppn_list, name='bkn_daftar_kppn_list'),
    path('bkn-daftar-kppn/create/', views.bkn_daftar_kppn_create, name='bkn_daftar_kppn_create'),
    path('bkn-daftar-kppn/<int:pk>/edit/', views.bkn_daftar_kppn_edit, name='bkn_daftar_kppn_edit'),
    path('bkn-daftar-kppn/<int:pk>/delete/', views.bkn_daftar_kppn_delete, name='bkn_daftar_kppn_delete'),

    path('bkn-jenis-penghargaan/', views.bkn_jenis_penghargaan_list, name='bkn_jenis_penghargaan_list'),
    path('bkn-jenis-penghargaan/create/', views.bkn_jenis_penghargaan_create, name='bkn_jenis_penghargaan_create'),
    path('bkn-jenis-penghargaan/<int:pk>/edit/', views.bkn_jenis_penghargaan_edit, name='bkn_jenis_penghargaan_edit'),
    path('bkn-jenis-penghargaan/<int:pk>/delete/', views.bkn_jenis_penghargaan_delete, name='bkn_jenis_penghargaan_delete'),

    path('bkn-jenis-mutasi/', views.bkn_jenis_mutasi_list, name='bkn_jenis_mutasi_list'),
    path('bkn-jenis-mutasi/create/', views.bkn_jenis_mutasi_create, name='bkn_jenis_mutasi_create'),
    path('bkn-jenis-mutasi/<int:pk>/edit/', views.bkn_jenis_mutasi_edit, name='bkn_jenis_mutasi_edit'),
    path('bkn-jenis-mutasi/<int:pk>/delete/', views.bkn_jenis_mutasi_delete, name='bkn_jenis_mutasi_delete'),

    path('bkn-jenis-penugasan/', views.bkn_jenis_penugasan_list, name='bkn_jenis_penugasan_list'),
    path('bkn-jenis-penugasan/create/', views.bkn_jenis_penugasan_create, name='bkn_jenis_penugasan_create'),
    path('bkn-jenis-penugasan/<int:pk>/edit/', views.bkn_jenis_penugasan_edit, name='bkn_jenis_penugasan_edit'),
    path('bkn-jenis-penugasan/<int:pk>/delete/', views.bkn_jenis_penugasan_delete, name='bkn_jenis_penugasan_delete'),

    path('bkn-sub-jabatan/', views.bkn_sub_jabatan_list, name='bkn_sub_jabatan_list'),
    path('bkn-sub-jabatan/create/', views.bkn_sub_jabatan_create, name='bkn_sub_jabatan_create'),
    path('bkn-sub-jabatan/<int:pk>/edit/', views.bkn_sub_jabatan_edit, name='bkn_sub_jabatan_edit'),
    path('bkn-sub-jabatan/<int:pk>/delete/', views.bkn_sub_jabatan_delete, name='bkn_sub_jabatan_delete'),
]
