import django_tables2 as tables
from django.urls import reverse
from django.utils.html import format_html
from apps.manajemen.helpers import check_permission

from apps.common.table_attrs import dt_actions_attrs, dt_checkbox_attrs, dt_col_attrs, dt_map_status_aktif_nonaktif, dt_render_actions, dt_render_row_number, dt_row_number_attrs

from apps.master_data.models import (
    MaAnSatuanKerja,
    MaAnSjBakat,
    MaAnSjTemperamenKerja,
    MaAnSjMinatKerja,
    MaAnSjJabatanData,
    MaAnSjJabatanOrang,
    MaAnSjJabatanBenda,
    MaAnSjUpayaFisik,
    MaAnSjPengetahuanKerja,
    MaAnSjKeterampilanKerja,
    MaAnSjPelatihanFungsional,
    MaAnSjJenisKelamin,
    MaAnSjPelatihanTeknis,
)


def _row_number(record, table, counter_attr='_row_counter'):
    page_number = getattr(table.page, 'number', 1) if hasattr(table, 'page') else 1
    per_page = getattr(table.paginator, 'per_page', 10) if hasattr(table, 'paginator') else 10
    if not hasattr(table, counter_attr):
        setattr(table, counter_attr, (page_number - 1) * per_page)
    setattr(table, counter_attr, getattr(table, counter_attr) + 1)
    return getattr(table, counter_attr)

def _anjab_render_actions(record, table, control_name, edit_url, delete_url):
    request = getattr(table, 'request', None)
    user = getattr(request, 'user', None) if request else None
    can_edit = False
    can_delete = False
    try:
        if user is not None and getattr(user, 'is_authenticated', False):
            can_edit = check_permission(user, 'manajemen_analisis_jabatan', control_name, 'edit')
            can_delete = check_permission(user, 'manajemen_analisis_jabatan', control_name, 'delete')
    except Exception:
        can_edit = False
        can_delete = False

    edit_link = (
        {
            'url': edit_url,
            'title': 'Edit',
            'a_class': 'text-blue-600 hover:text-blue-800',
            'icon_class': 'fas fa-edit',
        }
        if can_edit
        else None
    )
    delete_link = (
        {
            'url': delete_url,
            'title': 'Delete',
            'a_class': 'text-red-600 hover:text-red-800',
            'icon_class': 'fas fa-trash',
        }
        if can_delete
        else None
    )
    return dt_render_actions(
        *(link for link in [edit_link, delete_link] if link),
        container_class='flex gap-2 justify-center',
    )


class _BaseAnjabTable(tables.Table):
    selection = tables.CheckBoxColumn(
        accessor='pk',
        attrs=dt_checkbox_attrs(th_width='3%'),
        orderable=False,
    )
    row_number = tables.Column(
        empty_values=(),
        verbose_name='No',
        attrs=dt_row_number_attrs(width='6%'),
        orderable=False,
    )
    actions = tables.Column(
        empty_values=(),
        verbose_name='Aksi',
        attrs=dt_actions_attrs(width='10%', th_align='center', td_align='center'),
        orderable=False,
    )

    def render_row_number(self, record, table):
        return dt_render_row_number(table, self)


class MaAnSatuanKerjaTable(_BaseAnjabTable):
    satuan_kerja = tables.Column(
        verbose_name='Satuan Kerja',
        attrs=dt_col_attrs(td_weight='medium', td_color='gray-900'),
    )
    status = tables.Column(
        verbose_name='Status',
        attrs=dt_col_attrs(th_align='center', td_align='center', width='12%', td_color='gray-700'),
    )

    class Meta:
        model = MaAnSatuanKerja
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'satuan_kerja', 'status', 'actions')
        attrs = {
            'id': 'ma_an_satuan_kerja_table',
            'class': 'w-full table-auto border-collapse border border-gray-300',
            'thead': {'class': 'bg-gray-50'},
            'tbody': {'class': 'bg-white'},
        }
        per_page = 10

    def render_status(self, value):
        return dt_map_status_aktif_nonaktif(value)

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:satuan_kerja_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:satuan_kerja_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_satuan_kerja', edit_url, delete_url)


class MaAnSjBakatTable(_BaseAnjabTable):
    kode_bakat = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_bakat = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_bakat = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjBakat
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_bakat', 'nama_bakat', 'deskripsi_bakat', 'actions')
        attrs = {'id': 'ma_an_sj_bakat_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_bakat_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_bakat_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_bakat', edit_url, delete_url)


class MaAnSjTemperamenKerjaTable(_BaseAnjabTable):
    kode_temperamen = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_temperamen = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_temperamen = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjTemperamenKerja
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_temperamen', 'nama_temperamen', 'deskripsi_temperamen', 'actions')
        attrs = {'id': 'ma_an_sj_temperamen_kerja_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_temperamen_kerja_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_temperamen_kerja_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_temperamen_kerja', edit_url, delete_url)


class MaAnSjMinatKerjaTable(_BaseAnjabTable):
    kode_minat = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_minat = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_minat = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjMinatKerja
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_minat', 'nama_minat', 'deskripsi_minat', 'actions')
        attrs = {'id': 'ma_an_sj_minat_kerja_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_minat_kerja_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_minat_kerja_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_minat_kerja', edit_url, delete_url)


class MaAnSjJabatanDataTable(_BaseAnjabTable):
    kode_jabatan_data = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_jabatan_data = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_jabatan_data = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjJabatanData
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_jabatan_data', 'nama_jabatan_data', 'deskripsi_jabatan_data', 'actions')
        attrs = {'id': 'ma_an_sj_jabatan_data_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_jabatan_data_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_jabatan_data_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_jabatan_data', edit_url, delete_url)


class MaAnSjJabatanOrangTable(_BaseAnjabTable):
    kode_jabatan_orang = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_jabatan_orang = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_jabatan_orang = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjJabatanOrang
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_jabatan_orang', 'nama_jabatan_orang', 'deskripsi_jabatan_orang', 'actions')
        attrs = {'id': 'ma_an_sj_jabatan_orang_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_jabatan_orang_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_jabatan_orang_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_jabatan_orang', edit_url, delete_url)


class MaAnSjJabatanBendaTable(_BaseAnjabTable):
    kode_jabatan_benda = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_jabatan_benda = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_jabatan_benda = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjJabatanBenda
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_jabatan_benda', 'nama_jabatan_benda', 'deskripsi_jabatan_benda', 'actions')
        attrs = {'id': 'ma_an_sj_jabatan_benda_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_jabatan_benda_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_jabatan_benda_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_jabatan_benda', edit_url, delete_url)


class MaAnSjUpayaFisikTable(_BaseAnjabTable):
    kode_upaya = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_upaya = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_upaya = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjUpayaFisik
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_upaya', 'nama_upaya', 'deskripsi_upaya', 'actions')
        attrs = {'id': 'ma_an_sj_upaya_fisik_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_upaya_fisik_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_upaya_fisik_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_upaya_fisik', edit_url, delete_url)


class MaAnSjPengetahuanKerjaTable(_BaseAnjabTable):
    kode_pengetahuan = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_pengetahuan = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_pengetahuan = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjPengetahuanKerja
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_pengetahuan', 'nama_pengetahuan', 'deskripsi_pengetahuan', 'actions')
        attrs = {'id': 'ma_an_sj_pengetahuan_kerja_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_pengetahuan_kerja_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_pengetahuan_kerja_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_pengetahuan_kerja', edit_url, delete_url)


class MaAnSjKeterampilanKerjaTable(_BaseAnjabTable):
    kode_keterampilan = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_keterampilan = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_keterampilan = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjKeterampilanKerja
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_keterampilan', 'nama_keterampilan', 'deskripsi_keterampilan', 'actions')
        attrs = {'id': 'ma_an_sj_keterampilan_kerja_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_keterampilan_kerja_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_keterampilan_kerja_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_keterampilan_kerja', edit_url, delete_url)


class MaAnSjPelatihanFungsionalTable(_BaseAnjabTable):
    kode_pelatihan = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_pelatihan = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_pelatihan = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjPelatihanFungsional
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_pelatihan', 'nama_pelatihan', 'deskripsi_pelatihan', 'actions')
        attrs = {'id': 'ma_an_sj_pelatihan_fungsional_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_pelatihan_fungsional_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_pelatihan_fungsional_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_pelatihan_fungsional', edit_url, delete_url)


class MaAnSjJenisKelaminTable(_BaseAnjabTable):
    kode_jenis_kelamin = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_jenis_kelamin = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(width='28%', td_weight='medium', td_color='gray-900'),
    )
    deskripsi_jenis_kelamin = tables.Column(
        verbose_name='Deskripsi',
        attrs=dt_col_attrs(td_color='gray-700'),
    )

    class Meta:
        model = MaAnSjJenisKelamin
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_jenis_kelamin', 'nama_jenis_kelamin', 'deskripsi_jenis_kelamin', 'actions')
        attrs = {'id': 'ma_an_sj_jenis_kelamin_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_jenis_kelamin_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_jenis_kelamin_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_jenis_kelamin', edit_url, delete_url)


class MaAnSjPelatihanTeknisTable(_BaseAnjabTable):
    kode_pelatihan = tables.Column(
        verbose_name='Kode',
        attrs=dt_col_attrs(width='12%', td_weight='medium', td_color='gray-900'),
    )
    nama_pelatihan = tables.Column(
        verbose_name='Nama',
        attrs=dt_col_attrs(td_weight='medium', td_color='gray-900'),
    )

    class Meta:
        model = MaAnSjPelatihanTeknis
        template_name = 'django_tables2/tailwind.html'
        fields = ('selection', 'row_number', 'kode_pelatihan', 'nama_pelatihan', 'actions')
        attrs = {'id': 'ma_an_sj_pelatihan_teknis_table', 'class': 'w-full table-auto border-collapse border border-gray-300', 'thead': {'class': 'bg-gray-50'}, 'tbody': {'class': 'bg-white'}}
        per_page = 10

    def render_actions(self, record, table):
        edit_url = reverse('manajemen_analisis_jabatan:sj_pelatihan_teknis_edit', args=[record.id])
        delete_url = reverse('manajemen_analisis_jabatan:sj_pelatihan_teknis_delete', args=[record.id])
        return _anjab_render_actions(record, table, 'ma_an_sj_pelatihan_teknis', edit_url, delete_url)