from django.urls import path

from . import assessment_views as views

app_name = 'assessment'

urlpatterns = [
    path('mr-assessment/', views.mr_assessment_list, name='mr_assessment_list'),
    path('mr-assessment/<int:pk>/', views.mr_assessment_detail, name='mr_assessment_detail'),
]
