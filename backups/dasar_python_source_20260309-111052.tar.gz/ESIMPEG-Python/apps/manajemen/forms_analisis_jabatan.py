from django import forms

from apps.master_data.models import (
    MaAnSatuanKerja,
    MaAnSjBakat,
    MaAnSjTemperamenKerja,
    MaAnSjMinatKerja,
    MaAnSjJabatanData,
    MaAnSjJabatanOrang,
    MaAnSjJabatanBenda,
    MaAnSjUpayaFisik,
    MaAnSjPengetahuanKerja,
    MaAnSjKeterampilanKerja,
    MaAnSjPelatihanFungsional,
    MaAnSjJenisKelamin,
    MaAnSjPelatihanTeknis,
)

from apps.common.forms import select_search_attrs
from apps.common.choices import STATUS_CHOICES_AKTIF_NONAKTIF


class _LabelRequiredMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for f in self.fields.values():
            try:
                label = (f.label or '').strip()
                if not label:
                    continue
                f.error_messages = {**getattr(f, 'error_messages', {}), 'required': f'{label} harus diisi.'}
            except Exception:
                continue


class MaAnSatuanKerjaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSatuanKerja
        fields = ['satuan_kerja', 'status']
        labels = {
            'satuan_kerja': 'Satuan Kerja',
            'status': 'Status',
        }
        widgets = {
            'satuan_kerja': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjBakatForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjBakat
        fields = ['kode_bakat', 'nama_bakat', 'deskripsi_bakat', 'status']
        labels = {
            'kode_bakat': 'Kode',
            'nama_bakat': 'Nama Bakat',
            'deskripsi_bakat': 'Deskripsi',
            'status': 'Status',
        }
        widgets = {
            'kode_bakat': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_bakat': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'deskripsi_bakat': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjTemperamenKerjaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjTemperamenKerja
        fields = ['kode_temperamen', 'nama_temperamen', 'deskripsi_temperamen', 'status']
        labels = {
            'kode_temperamen': 'Kode',
            'nama_temperamen': 'Nama Temperamen',
            'deskripsi_temperamen': 'Deskripsi',
            'status': 'Status',
        }
        widgets = {
            'kode_temperamen': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_temperamen': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'deskripsi_temperamen': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjMinatKerjaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjMinatKerja
        fields = ['kode_minat', 'nama_minat', 'deskripsi_minat', 'status']
        labels = {
            'kode_minat': 'Kode',
            'nama_minat': 'Nama Minat',
            'deskripsi_minat': 'Deskripsi',
            'status': 'Status',
        }
        widgets = {
            'kode_minat': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_minat': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'deskripsi_minat': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjJabatanDataForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjJabatanData
        fields = ['kode_jabatan_data', 'nama_jabatan_data', 'status']
        labels = {
            'kode_jabatan_data': 'Kode',
            'nama_jabatan_data': 'Nama',
            'status': 'Status',
        }
        widgets = {
            'kode_jabatan_data': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_jabatan_data': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjJabatanOrangForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjJabatanOrang
        fields = ['kode_jabatan_orang', 'nama_jabatan_orang', 'status']
        labels = {
            'kode_jabatan_orang': 'Kode',
            'nama_jabatan_orang': 'Nama',
            'status': 'Status',
        }
        widgets = {
            'kode_jabatan_orang': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_jabatan_orang': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjJabatanBendaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjJabatanBenda
        fields = ['kode_jabatan_benda', 'nama_jabatan_benda', 'status']
        labels = {
            'kode_jabatan_benda': 'Kode',
            'nama_jabatan_benda': 'Nama',
            'status': 'Status',
        }
        widgets = {
            'kode_jabatan_benda': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_jabatan_benda': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjUpayaFisikForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjUpayaFisik
        fields = ['kode_upaya', 'nama_upaya', 'deskripsi_upaya', 'status']
        labels = {
            'kode_upaya': 'Kode',
            'nama_upaya': 'Nama',
            'deskripsi_upaya': 'Deskripsi',
            'status': 'Status',
        }
        widgets = {
            'kode_upaya': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_upaya': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'deskripsi_upaya': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjPengetahuanKerjaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjPengetahuanKerja
        fields = ['kode_pengetahuan', 'nama_pengetahuan', 'status']
        labels = {
            'kode_pengetahuan': 'Kode',
            'nama_pengetahuan': 'Nama Pengetahuan',
            'status': 'Status',
        }
        widgets = {
            'kode_pengetahuan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_pengetahuan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjKeterampilanKerjaForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjKeterampilanKerja
        fields = ['kode_keterampilan', 'nama_keterampilan', 'status']
        labels = {
            'kode_keterampilan': 'Kode',
            'nama_keterampilan': 'Nama Keterampilan',
            'status': 'Status',
        }
        widgets = {
            'kode_keterampilan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_keterampilan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjPelatihanFungsionalForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjPelatihanFungsional
        fields = ['kode_pelatihan', 'nama_pelatihan', 'status']
        labels = {
            'kode_pelatihan': 'Kode',
            'nama_pelatihan': 'Nama Pelatihan',
            'status': 'Status',
        }
        widgets = {
            'kode_pelatihan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_pelatihan': forms.Textarea(attrs={'rows': 2, 'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjJenisKelaminForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjJenisKelamin
        fields = ['kode_jenis_kelamin', 'nama_jenis_kelamin', 'status']
        labels = {
            'kode_jenis_kelamin': 'Kode',
            'nama_jenis_kelamin': 'Nama Jenis Kelamin',
            'status': 'Status',
        }
        widgets = {
            'kode_jenis_kelamin': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_jenis_kelamin': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }


class MaAnSjPelatihanTeknisForm(_LabelRequiredMixin, forms.ModelForm):
    STATUS_CHOICES = STATUS_CHOICES_AKTIF_NONAKTIF

    status = forms.TypedChoiceField(
        choices=STATUS_CHOICES,
        coerce=int,
        required=True,
        widget=forms.Select(
            attrs={
                **select_search_attrs('Cari status...'),
            }
        ),
    )

    class Meta:
        model = MaAnSjPelatihanTeknis
        fields = ['kode_pelatihan', 'nama_pelatihan', 'status']
        labels = {
            'kode_pelatihan': 'Kode',
            'nama_pelatihan': 'Nama Pelatihan',
            'status': 'Status',
        }
        widgets = {
            'kode_pelatihan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
            'nama_pelatihan': forms.TextInput(attrs={'class': 'w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary/25 focus:outline-none transition-all'}),
        }
