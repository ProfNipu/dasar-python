from django.shortcuts import render, get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie
from django.db.models import Q
from django_tables2 import RequestConfig

from apps.manajemen.decorators import permission_required_403
from apps.pegawai.models import MrAngkaKredit, MrAssessment, MrDiklatFungsional, MrDiklatStruktural, MrDiklatTeknis, MrGajiBerkala, MrHukumanDisiplin, MrJabatan, MrKeluarga, MrKinerja, MrOrtu, MrPangkat, MrPendidikan, MrSeminar, MrSkp, MrTandaJasa, MrTugasLn, MsPegawai, MsTataNaskahPegawai
from apps.manajemen.tables_kepegawaian import MrAnakTable, MrAngkaKreditTable, MrAssessmentTable, MrDiklatFungsionalTable, MrDiklatStrukturalTable, MrDiklatTeknisTable, MrGajiBerkalaTable, MrHukumanDisiplinTable, MrJabatanTable, MrKinerjaTable, MrOrtuTable, MrPasanganTable, MrPangkatTable, MrPendidikanTable, MrSeminarTable, MrSkpTable, MrTandaJasaTable, MrTugasLnTable, MsPegawaiTable, MsTataNaskahPegawaiTable


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Ms_pegawai', 'view')
def ms_pegawai_list(request):
    search_query = request.GET.get('search', '').strip()
    status_value = (request.GET.get('status') or 'aktif').strip().lower()

    qs = MsPegawai.objects.filter(deleted_at__isnull=True)
    if status_value == 'aktif':
        qs = qs.exclude(A_01=99).exclude(B_11__status_hitung=2)
    elif status_value == 'nonaktif':
        qs = qs.filter(Q(A_01=99) | Q(B_11__status_hitung=2))
    elif status_value == 'semua':
        pass
    else:
        status_value = 'aktif'
        qs = qs.exclude(A_01=99).exclude(B_11__status_hitung=2)

    if search_query:
        qs = qs.filter(
            Q(B_02B__icontains=search_query)
            | Q(B_02__icontains=search_query)
            | Q(B_03__icontains=search_query)
        )
    qs = qs.order_by('id_pegawai')

    table = MsPegawaiTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
        'status_value': status_value,
        'status_list': [
            {'value': 'aktif', 'label': 'Aktif'},
            {'value': 'nonaktif', 'label': 'Non Aktif'},
            {'value': 'semua', 'label': 'Semua'},
        ],
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_pegawai/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_pegawai/list.html', context)


@permission_required_403('kepegawaian', 'Ms_pegawai', 'view')
def ms_pegawai_detail(request, pk):
    obj = get_object_or_404(MsPegawai, id_pegawai=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_pegawai/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_pegawai/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_pangkat', 'view')
def mr_pangkat_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrPangkat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(PF_04__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'PF_03').order_by('-PF_06', '-id')

    table = MrPangkatTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pangkat/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pangkat/list.html', context)


@permission_required_403('kepegawaian', 'Mr_pangkat', 'view')
def mr_pangkat_detail(request, pk):
    obj = get_object_or_404(MrPangkat, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pangkat/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pangkat/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_jabatan', 'view')
def mr_jabatan_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrJabatan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(JF_03__icontains=search_query)
            | Q(JF_05__icontains=search_query)
        )

    qs = qs.select_related(
        'id_pegawai',
        'id_jenis_jabatan',
        'id_jabatan_struktural',
        'id_jabatan_non_struktural',
        'JF_01_ref',
        'JF_02_ref',
        'JF_04',
        'id_opd',
        'id_sub_opd',
        'JF_23',
        'JF_24',
        'JF_25_ref',
        'MM_07',
    ).order_by('-JF_07', '-id')

    table = MrJabatanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_jabatan/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_jabatan/list.html', context)


@permission_required_403('kepegawaian', 'Mr_jabatan', 'view')
def mr_jabatan_detail(request, pk):
    obj = get_object_or_404(MrJabatan, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_jabatan/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_jabatan/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_pendidikan', 'view')
def mr_pendidikan_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrPendidikan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(DK_05__icontains=search_query)
            | Q(DK_04__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'DK_03', 'DK_03B').order_by('-DK_09', '-id')

    table = MrPendidikanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pendidikan/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pendidikan/list.html', context)


@permission_required_403('kepegawaian', 'Mr_pendidikan', 'view')
def mr_pendidikan_detail(request, pk):
    obj = get_object_or_404(MrPendidikan, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pendidikan/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pendidikan/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Ms_tata_naskah_pegawai', 'view')
def ms_tata_naskah_pegawai_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MsTataNaskahPegawai.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(PJ_01__icontains=search_query)
            | Q(PJ_02__icontains=search_query)
            | Q(PJ_07__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-updated_at', '-id')

    table = MsTataNaskahPegawaiTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_tata_naskah_pegawai/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_tata_naskah_pegawai/list.html', context)


@permission_required_403('kepegawaian', 'Ms_tata_naskah_pegawai', 'view')
def ms_tata_naskah_pegawai_detail(request, pk):
    obj = get_object_or_404(MsTataNaskahPegawai, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_tata_naskah_pegawai/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Ms_tata_naskah_pegawai/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_ortu', 'view')
def mr_ortu_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrOrtu.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(NM_04__icontains=search_query)
            | Q(NM_05__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-updated_at', '-id')

    table = MrOrtuTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_ortu/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_ortu/list.html', context)


@permission_required_403('kepegawaian', 'Mr_ortu', 'view')
def mr_ortu_detail(request, pk):
    obj = get_object_or_404(MrOrtu, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_ortu/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_ortu/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_pasangan', 'view')
def mr_pasangan_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrKeluarga.objects.filter(deleted_at__isnull=True, KF_02=1)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(KF_04__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-updated_at', '-id')

    table = MrPasanganTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pasangan/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pasangan/list.html', context)


@permission_required_403('kepegawaian', 'Mr_pasangan', 'view')
def mr_pasangan_detail(request, pk):
    obj = get_object_or_404(MrKeluarga, id=pk, deleted_at__isnull=True, KF_02=1)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pasangan/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_pasangan/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_anak', 'view')
def mr_anak_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrKeluarga.objects.filter(deleted_at__isnull=True, KF_02=2)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(KF_04__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-updated_at', '-id')

    table = MrAnakTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_anak/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_anak/list.html', context)


@permission_required_403('kepegawaian', 'Mr_anak', 'view')
def mr_anak_detail(request, pk):
    obj = get_object_or_404(MrKeluarga, id=pk, deleted_at__isnull=True, KF_02=2)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_anak/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_anak/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_diklat_struktural', 'view')
def mr_diklat_struktural_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrDiklatStruktural.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(LT_04__icontains=search_query)
            | Q(LT_05__icontains=search_query)
            | Q(LT_10__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'LT_03', 'LT_12').order_by('-LT_11', '-id')

    table = MrDiklatStrukturalTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_struktural/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_struktural/list.html', context)


@permission_required_403('kepegawaian', 'Mr_diklat_struktural', 'view')
def mr_diklat_struktural_detail(request, pk):
    obj = get_object_or_404(MrDiklatStruktural, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_struktural/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_struktural/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_diklat_fungsional', 'view')
def mr_diklat_fungsional_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrDiklatFungsional.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(LT_03__icontains=search_query)
            | Q(LT_04__icontains=search_query)
            | Q(LT_05__icontains=search_query)
            | Q(LT_10__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-LT_11', '-id')

    table = MrDiklatFungsionalTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_fungsional/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_fungsional/list.html', context)


@permission_required_403('kepegawaian', 'Mr_diklat_fungsional', 'view')
def mr_diklat_fungsional_detail(request, pk):
    obj = get_object_or_404(MrDiklatFungsional, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_fungsional/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_fungsional/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_diklat_teknis', 'view')
def mr_diklat_teknis_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrDiklatTeknis.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(LT_03__icontains=search_query)
            | Q(LT_04__icontains=search_query)
            | Q(LT_05__icontains=search_query)
            | Q(LT_10__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-LT_11', '-id')

    table = MrDiklatTeknisTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_teknis/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_teknis/list.html', context)


@permission_required_403('kepegawaian', 'Mr_diklat_teknis', 'view')
def mr_diklat_teknis_detail(request, pk):
    obj = get_object_or_404(MrDiklatTeknis, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_teknis/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_diklat_teknis/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_seminar', 'view')
def mr_seminar_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrSeminar.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(LT_03__icontains=search_query)
            | Q(LT_05__icontains=search_query)
            | Q(LT_10__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'LT_12').order_by('-LT_11', '-id')

    table = MrSeminarTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_seminar/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_seminar/list.html', context)


@permission_required_403('kepegawaian', 'Mr_seminar', 'view')
def mr_seminar_detail(request, pk):
    obj = get_object_or_404(MrSeminar, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_seminar/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_seminar/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_angka_kredit', 'view')
def mr_angka_kredit_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrAngkaKredit.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(AK_01__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'AK_13').order_by('-AK_02', '-id')

    table = MrAngkaKreditTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_angka_kredit/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_angka_kredit/list.html', context)


@permission_required_403('kepegawaian', 'Mr_angka_kredit', 'view')
def mr_angka_kredit_detail(request, pk):
    obj = get_object_or_404(MrAngkaKredit, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_angka_kredit/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_angka_kredit/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_hukuman_disiplin', 'view')
def mr_hukuman_disiplin_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrHukumanDisiplin.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(HD_02__icontains=search_query)
        )

    qs = qs.select_related(
        'id_pegawai',
        'F_03',
        'HD_01',
        'HD_08',
        'HD_09',
        'HD_11',
    ).order_by('-HD_03', '-id')

    table = MrHukumanDisiplinTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_hukuman_disiplin/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_hukuman_disiplin/list.html', context)


@permission_required_403('kepegawaian', 'Mr_hukuman_disiplin', 'view')
def mr_hukuman_disiplin_detail(request, pk):
    obj = get_object_or_404(MrHukumanDisiplin, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_hukuman_disiplin/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_hukuman_disiplin/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_skp', 'view')
def mr_skp_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrSkp.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(SKP2021_20__icontains=search_query)
            | Q(SKP2021_19__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'id_jenis_jabatan').order_by('-SKP2021_32', '-id')

    table = MrSkpTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_skp/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_skp/list.html', context)


@permission_required_403('kepegawaian', 'Mr_skp', 'view')
def mr_skp_detail(request, pk):
    obj = get_object_or_404(MrSkp, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_skp/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_skp/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_tugas_ln', 'view')
def mr_tugas_ln_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrTugasLn.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(TG_03__icontains=search_query)
            | Q(TG_04__icontains=search_query)
            | Q(TG_06__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-TG_08', '-id')

    table = MrTugasLnTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tugas_ln/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tugas_ln/list.html', context)


@permission_required_403('kepegawaian', 'Mr_tugas_ln', 'view')
def mr_tugas_ln_detail(request, pk):
    obj = get_object_or_404(MrTugasLn, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tugas_ln/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tugas_ln/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_tandajasa', 'view')
def mr_tandajasa_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrTandaJasa.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(JS_03__icontains=search_query)
            | Q(JS_04__icontains=search_query)
            | Q(JS_07__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'JS_08').order_by('-id')

    table = MrTandaJasaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tandajasa/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tandajasa/list.html', context)


@permission_required_403('kepegawaian', 'Mr_tandajasa', 'view')
def mr_tandajasa_detail(request, pk):
    obj = get_object_or_404(MrTandaJasa, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tandajasa/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_tandajasa/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_gaji_berkala', 'view')
def mr_gaji_berkala_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrGajiBerkala.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(MR_GK01__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'MR_GK03', 'MR_GK08').order_by('-MR_GK04', '-id')

    table = MrGajiBerkalaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_gaji_berkala/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_gaji_berkala/list.html', context)


@permission_required_403('kepegawaian', 'Mr_gaji_berkala', 'view')
def mr_gaji_berkala_detail(request, pk):
    obj = get_object_or_404(MrGajiBerkala, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_gaji_berkala/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_gaji_berkala/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_kinerja', 'view')
def mr_kinerja_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrKinerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(SKP2022_19__icontains=search_query)
            | Q(SKP2022_20__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai', 'id_jenis_jabatan').order_by('-SKP2022_32', '-id')

    table = MrKinerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_kinerja/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_kinerja/list.html', context)


@permission_required_403('kepegawaian', 'Mr_kinerja', 'view')
def mr_kinerja_detail(request, pk):
    obj = get_object_or_404(MrKinerja, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_kinerja/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_kinerja/form.html', context)


@ensure_csrf_cookie
@permission_required_403('kepegawaian', 'Mr_assessment', 'view')
def mr_assessment_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrAssessment.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(MRA_02__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-MRA_01', '-id')

    table = MrAssessmentTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_assessment/partials/_table.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_assessment/list.html', context)


@permission_required_403('kepegawaian', 'Mr_assessment', 'view')
def mr_assessment_detail(request, pk):
    obj = get_object_or_404(MrAssessment, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_assessment/partials/_form.html', context)
    return render(request, 'manajemen_data_kepegawaian/access/ma_da_ke_Mr_assessment/form.html', context)
