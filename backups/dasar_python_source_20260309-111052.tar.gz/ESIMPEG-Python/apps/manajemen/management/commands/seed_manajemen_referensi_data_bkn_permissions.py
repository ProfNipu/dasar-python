from django.core.management.base import BaseCommand
from django.conf import settings
from django.contrib.auth.models import Group

from apps.manajemen.models import (
    PermissionModule,
    PermissionControl,
    PermissionFunction,
    PermissionRule,
    RoleRule,
)

MODULE_NAME = 'manajemen_referensi_data_bkn'
MODULE_LABEL = 'Manajemen Referensi Data BKN'
MODULE_ICON = 'fas fa-cloud'
MODULE_ORDER = 12

CONTROLS = [
    ('bkn_lokasi_kerja', 'BKN Lokasi Kerja'),
    ('bkn_alasan_hukuman', 'BKN Alasan Hukuman'),
    ('bkn_jenis_hukuman', 'BKN Jenis Hukuman'),
    ('bkn_tingkat_hukdis', 'BKN Tingkat Hukuman Disiplin'),
    ('bkn_nomorpp_hukdis', 'BKN Nomor PP Hukuman Disiplin'),
    ('bkn_jabatan_fungsional', 'BKN Jabatan Fungsional'),
    ('bkn_jenis_kenaikan_pangkat', 'BKN Jenis Kenaikan Pangkat'),
    ('bkn_jenis_diklat', 'BKN Jenis Diklat'),
    ('bkn_daftar_kppn', 'BKN Daftar KPPN'),
    ('bkn_jenis_penghargaan', 'BKN Jenis Penghargaan'),
    ('bkn_jenis_mutasi', 'BKN Jenis Mutasi'),
    ('bkn_jenis_penugasan', 'BKN Jenis Penugasan'),
    ('bkn_sub_jabatan', 'BKN Sub Jabatan'),
]

FUNCTIONS = [
    ('view', 'Lihat'),
    ('create', 'Tambah'),
    ('edit', 'Ubah'),
    ('delete', 'Hapus'),
    ('bulk_delete', 'Hapus Banyak'),
    ('export', 'Export'),
]


class Command(BaseCommand):
    help = 'Seed permissions for Manajemen Referensi Data BKN'

    def handle(self, *args, **options):
        self.stdout.write('=' * 70)
        self.stdout.write(self.style.SUCCESS('🌱 Seeding Manajemen Referensi Data BKN permissions'))
        self.stdout.write('=' * 70)

        module, _ = PermissionModule.objects.get_or_create(
            nama_module=MODULE_NAME,
            defaults={
                'label_module': MODULE_LABEL,
                'icon': MODULE_ICON,
                'order': MODULE_ORDER,
                'is_active': True,
            },
        )

        changed = False
        if module.label_module != MODULE_LABEL:
            module.label_module = MODULE_LABEL; changed = True
        if module.icon != MODULE_ICON:
            module.icon = MODULE_ICON; changed = True
        if module.order != MODULE_ORDER:
            module.order = MODULE_ORDER; changed = True
        if not module.is_active:
            module.is_active = True; changed = True
        if changed:
            module.save()

        control_objs = {}
        for name, label in CONTROLS:
            ctrl, _ = PermissionControl.objects.get_or_create(
                nama_kontrol=name,
                defaults={'label_kontrol': label},
            )
            if ctrl.label_kontrol != label:
                ctrl.label_kontrol = label
                ctrl.save()
            control_objs[name] = ctrl

        func_objs = {}
        for name, label in FUNCTIONS:
            func, _ = PermissionFunction.objects.get_or_create(
                nama_fungsi=name,
                defaults={'label_fungsi': label},
            )
            if func.label_fungsi != label:
                func.label_fungsi = label
                func.save()
            func_objs[name] = func

        created_rules = 0
        for ctrl_name, ctrl in control_objs.items():
            for func_name, func in func_objs.items():
                _, created = PermissionRule.objects.get_or_create(
                    module=module,
                    control=ctrl,
                    function=func,
                    defaults={'is_active': True},
                )
                created_rules += int(created)
        self.stdout.write(f'  ✓ Rules created (new): {created_rules}')

        group_names = getattr(settings, 'SUPERADMIN_GROUPS', ['Super Admin'])
        if not isinstance(group_names, (list, tuple)):
            group_names = [str(group_names)]

        rules = PermissionRule.objects.filter(module=module, is_active=True)
        assigned = 0
        for gname in group_names:
            grp, _ = Group.objects.get_or_create(name=gname)
            for rule in rules:
                _, created = RoleRule.objects.get_or_create(role=grp, rule=rule)
                assigned += int(created)
        self.stdout.write(f'  ✓ Role assignments (new): {assigned}')

        self.stdout.write(self.style.SUCCESS('✅ Manajemen Referensi Data BKN permission seeding completed'))
