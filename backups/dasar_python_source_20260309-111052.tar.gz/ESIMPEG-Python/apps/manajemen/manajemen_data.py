from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.db.models import Q
from django.core.exceptions import PermissionDenied
from django_tables2 import RequestConfig
from io import BytesIO
import csv

from apps.manajemen.decorators import permission_required_403
from apps.manajemen.helpers import check_permission
from apps.manajemen.models import UserTableSelection
from apps.master_data.models import (
    MdKategoriPegawai,
    MdAgama,
    MdStatusPerkawinan,
    MdJenjangPendidikan,
    MsDaftarPendidikan,
    MdKedudukanPegawai,
    MdJenisJabatan,
    MdKategoriJabatan,
    MdPangkat,
    MdJenjangJabatan,
    MdEselon,
    MdDiklatStruktural,
    MdJenisSurat,
    MdPejabatMenetapkan,
    MdJenisOrganisasi,
    MdKategoriPemberitahuan,
    MdKategoriPeraturan,
    MdPeraturan,
    MdTentang,
)

from apps.manajemen.forms_master_data import (
    MdKategoriPegawaiForm,
    MdAgamaForm,
    MdStatusPerkawinanForm,
    MdJenjangPendidikanForm,
    MsDaftarPendidikanForm,
    MdKedudukanPegawaiForm,
    MdJenisJabatanForm,
    MdKategoriJabatanForm,
    MdPangkatForm,
    MdJenjangJabatanForm,
    MdEselonForm,
    MdDiklatStrukturalForm,
    MdJenisSuratForm,
    MdPejabatMenetapkanForm,
    MdJenisOrganisasiForm,
    MdKategoriPemberitahuanForm,
    MdKategoriPeraturanForm,
    MdPeraturanForm,
    MdTentangForm,
)
from apps.manajemen.tables_master_data import (
    KategoriPegawaiTable,
    AgamaTable,
    StatusPerkawinanTable,
    JenjangPendidikanTable,
    DaftarPendidikanTable,
    KedudukanPegawaiTable,
    JenisJabatanTable,
    KategoriJabatanTable,
    PangkatTable,
    JenjangJabatanTable,
    EselonTable,
    DiklatStrukturalTable,
    JenisSuratTable,
    PejabatMenetapkanTable,
    JenisOrganisasiTable,
    KategoriPemberitahuanTable,
    KategoriPeraturanTable,
    PeraturanTable,
    TentangTable,
)


def _datatable_export_get_columns(table):
    cols = []
    try:
        for col in list(table.columns):
            if getattr(col, 'name', None) in ('selection', 'row_number', 'actions'):
                continue
            cols.append(col)
    except Exception:
        cols = []
    return cols


def _datatable_export_row(table, col, record):
    name = getattr(col, 'name', None)
    if not name:
        return ''
    try:
        value = getattr(record, name)
    except Exception:
        value = ''
    try:
        bc = table.columns[name]
        rendered = bc.render(record, value)
        return str(rendered)
    except Exception:
        return str(value)


def export_table_csv(qs, table_class, filename_prefix='export'):
    table = table_class(qs)
    cols = _datatable_export_get_columns(table)
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{filename_prefix}.csv"'
    writer = csv.writer(response)
    writer.writerow([str(getattr(c, 'header', getattr(c, 'name', '')) or '').strip() for c in cols])
    for record in qs:
        writer.writerow([_datatable_export_row(table, c, record) for c in cols])
    return response


def export_table_excel(qs, table_class, filename_prefix='export'):
    try:
        from openpyxl import Workbook
        from openpyxl.utils import get_column_letter
    except Exception:
        return export_table_csv(qs, table_class, filename_prefix=filename_prefix)

    table = table_class(qs)
    cols = _datatable_export_get_columns(table)
    wb = Workbook()
    ws = wb.active
    ws.title = 'Export'
    headers = [str(getattr(c, 'header', getattr(c, 'name', '')) or '').strip() for c in cols]
    ws.append(headers)
    for record in qs:
        ws.append([_datatable_export_row(table, c, record) for c in cols])
    for idx, _ in enumerate(headers, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = 28

    out = BytesIO()
    wb.save(out)
    out.seek(0)
    response = HttpResponse(out.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{filename_prefix}.xlsx"'
    return response


def export_table_pdf(qs, table_class, filename_prefix='export', title='Export'):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Table as PdfTable, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
    except Exception:
        return export_table_csv(qs, table_class, filename_prefix=filename_prefix)

    table = table_class(qs)
    cols = _datatable_export_get_columns(table)
    headers = [str(getattr(c, 'header', getattr(c, 'name', '')) or '').strip() for c in cols]
    data = [headers]
    for record in qs:
        data.append([_datatable_export_row(table, c, record) for c in cols])

    out = BytesIO()
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=1*cm, rightMargin=1*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
    styles = getSampleStyleSheet()
    elements = [Paragraph(f"<b>{title}</b>", styles['Heading2']), Spacer(1, 0.3*cm)]
    t = PdfTable(data, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4B5563')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    elements.append(t)
    doc.build(elements)
    pdf = out.getvalue()
    out.close()

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename_prefix}.pdf"'
    response.write(pdf)
    return response


def handle_datatable_export(request, qs, table_class, filename_prefix, title=None):
    if request.method != 'POST':
        return None

    def _apply_generic_filters(base_qs, search_value, status_value):
        out_qs = base_qs
        try:
            search_value = (search_value or '').strip()
        except Exception:
            search_value = ''
        if search_value:
            try:
                q = Q()
                for f in getattr(out_qs.model, '_meta', {}).fields:
                    try:
                        if getattr(f, 'name', '') in ('created_at', 'updated_at', 'deleted_at'):
                            continue
                        it = getattr(f, 'get_internal_type', lambda: '')()
                        if it in ('CharField', 'TextField', 'EmailField'):
                            q |= Q(**{f"{f.name}__icontains": search_value})
                    except Exception:
                        continue
                if q:
                    out_qs = out_qs.filter(q)
            except Exception:
                pass
        try:
            status_value = (status_value or '').strip()
        except Exception:
            status_value = ''
        if status_value:
            try:
                field_names = [f.name for f in out_qs.model._meta.fields]
                if 'status' in field_names:
                    out_qs = out_qs.filter(status=status_value)
            except Exception:
                pass
        return out_qs

    if 'export_all' in request.POST:
        fmt = (request.POST.get('export_all') or '').strip().lower()
        qs_all = _apply_generic_filters(
            qs,
            request.POST.get('search', ''),
            request.POST.get('status', ''),
        ).order_by('id')
        if fmt == 'excel':
            return export_table_excel(qs_all, table_class, filename_prefix=filename_prefix)
        if fmt == 'pdf':
            return export_table_pdf(qs_all, table_class, filename_prefix=filename_prefix, title=title or filename_prefix)
        if fmt == 'csv':
            return export_table_csv(qs_all, table_class, filename_prefix=filename_prefix)
        return export_table_csv(qs_all, table_class, filename_prefix=filename_prefix)

    action = (request.POST.get('action') or '').strip().lower()
    if action in ('export_csv', 'export_excel', 'export_pdf'):
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            return None
        qs2 = qs.model.objects.filter(id__in=selected_ids)
        if 'deleted_at' in [f.name for f in qs.model._meta.fields]:
            qs2 = qs2.filter(deleted_at__isnull=True)
        qs2 = _apply_generic_filters(
            qs2,
            request.POST.get('search', ''),
            request.POST.get('status', ''),
        ).order_by('id')
        if action == 'export_excel':
            return export_table_excel(qs2, table_class, filename_prefix=filename_prefix)
        if action == 'export_pdf':
            return export_table_pdf(qs2, table_class, filename_prefix=filename_prefix, title=title or filename_prefix)
        return export_table_csv(qs2, table_class, filename_prefix=filename_prefix)

    return None


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_kategori_pegawai', 'view')
def kategori_pegawai_list(request):
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_kategori_pegawai_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_kategori_pegawai_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_kategori_pegawai_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:kategori_pegawai_list')

            now = timezone.now()
            qs = MdKategoriPegawai.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_kategori_pegawai_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data kategori pegawai berhasil dihapus')
            return redirect('manajemen_data:kategori_pegawai_list')

    export_resp = handle_datatable_export(
        request,
        MdKategoriPegawai.objects.filter(deleted_at__isnull=True),
        KategoriPegawaiTable,
        filename_prefix='kategori_pegawai_export',
        title='Kategori Pegawai Export',
    )
    if export_resp is not None:
        return export_resp

    search_query = request.GET.get('search', '').strip()
    qs = MdKategoriPegawai.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(nama_kategori_pegawai__icontains=search_query)
            | Q(keterangan_kategori_pegawai__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = KategoriPegawaiTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/list.html', context)


@permission_required_403('manajemen_data', 'md_kategori_pegawai', 'create')
def kategori_pegawai_create(request):
    if request.method == 'POST':
        form = MdKategoriPegawaiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Pegawai berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-pegawai-form-success": {"message": "Kategori Pegawai berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:kategori_pegawai_list'),
                })
            return redirect('manajemen_data:kategori_pegawai_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-pegawai-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/form.html', {'form': form, 'edit_mode': False})

    form = MdKategoriPegawaiForm()
    return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_kategori_pegawai', 'edit')
def kategori_pegawai_edit(request, pk):
    obj = get_object_or_404(MdKategoriPegawai, id=pk)
    if request.method == 'POST':
        form = MdKategoriPegawaiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Pegawai berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-pegawai-form-success": {"message": "Kategori Pegawai berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:kategori_pegawai_list'),
                })
            return redirect('manajemen_data:kategori_pegawai_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-pegawai-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(
            request,
            'manajemen_data/access/ma_da_kategori_pegawai/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MdKategoriPegawaiForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_kategori_pegawai', 'delete')
def kategori_pegawai_delete(request, pk):
    obj = get_object_or_404(MdKategoriPegawai, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Kategori Pegawai berhasil dihapus')
        return redirect('manajemen_data:kategori_pegawai_list')
    return render(request, 'manajemen_data/access/ma_da_kategori_pegawai/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_agama', 'view')
def agama_list(request):
    export_qs = MdAgama.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, AgamaTable, filename_prefix='agama_export', title='Agama Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_agama_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_agama_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_agama_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_agama', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:agama_list')

            now = timezone.now()
            qs = MdAgama.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_agama_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data agama berhasil dihapus')
            return redirect('manajemen_data:agama_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdAgama.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_agama__icontains=search_query))
    qs = qs.order_by('id')

    table = AgamaTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_agama/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_agama/list.html', context)


@permission_required_403('manajemen_data', 'md_agama', 'create')
def agama_create(request):
    if request.method == 'POST':
        form = MdAgamaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Agama berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"agama-form-success": {"message": "Agama berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:agama_list'),
                })
            return redirect('manajemen_data:agama_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'agama-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_data/access/ma_da_agama/form.html', {'form': form, 'edit_mode': False})

    form = MdAgamaForm()
    return render(request, 'manajemen_data/access/ma_da_agama/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_agama', 'edit')
def agama_edit(request, pk):
    obj = get_object_or_404(MdAgama, id=pk)
    if request.method == 'POST':
        form = MdAgamaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Agama berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"agama-form-success": {"message": "Agama berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:agama_list'),
                })
            return redirect('manajemen_data:agama_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'agama-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(
            request,
            'manajemen_data/access/ma_da_agama/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MdAgamaForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_agama/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_agama', 'delete')
def agama_delete(request, pk):
    obj = get_object_or_404(MdAgama, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Agama berhasil dihapus')
        return redirect('manajemen_data:agama_list')
    return render(request, 'manajemen_data/access/ma_da_agama/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_status_perkawinan', 'view')
def status_perkawinan_list(request):
    export_qs = MdStatusPerkawinan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, StatusPerkawinanTable, filename_prefix='status_perkawinan_export', title='Status Perkawinan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_status_perkawinan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_status_perkawinan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_status_perkawinan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:status_perkawinan_list')

            now = timezone.now()
            qs = MdStatusPerkawinan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_status_perkawinan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data status perkawinan berhasil dihapus')
            return redirect('manajemen_data:status_perkawinan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdStatusPerkawinan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(status_perkawinan__icontains=search_query))
    qs = qs.order_by('id')

    table = StatusPerkawinanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_status_perkawinan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_status_perkawinan/list.html', context)


@permission_required_403('manajemen_data', 'md_status_perkawinan', 'create')
def status_perkawinan_create(request):
    if request.method == 'POST':
        form = MdStatusPerkawinanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Status Perkawinan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"status-perkawinan-form-success": {"message": "Status Perkawinan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:status_perkawinan_list'),
                })
            return redirect('manajemen_data:status_perkawinan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'status-perkawinan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_data/access/ma_da_status_perkawinan/form.html', {'form': form, 'edit_mode': False})

    form = MdStatusPerkawinanForm()
    return render(request, 'manajemen_data/access/ma_da_status_perkawinan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_status_perkawinan', 'edit')
def status_perkawinan_edit(request, pk):
    obj = get_object_or_404(MdStatusPerkawinan, id=pk)
    if request.method == 'POST':
        form = MdStatusPerkawinanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Status Perkawinan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"status-perkawinan-form-success": {"message": "Status Perkawinan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:status_perkawinan_list'),
                })
            return redirect('manajemen_data:status_perkawinan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'status-perkawinan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(
            request,
            'manajemen_data/access/ma_da_status_perkawinan/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MdStatusPerkawinanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_status_perkawinan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_status_perkawinan', 'delete')
def status_perkawinan_delete(request, pk):
    obj = get_object_or_404(MdStatusPerkawinan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Status Perkawinan berhasil dihapus')
        return redirect('manajemen_data:status_perkawinan_list')
    return render(request, 'manajemen_data/access/ma_da_status_perkawinan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_jenjang_pendidikan', 'view')
def jenjang_pendidikan_list(request):
    export_qs = MdJenjangPendidikan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, JenjangPendidikanTable, filename_prefix='jenjang_pendidikan_export', title='Jenjang Pendidikan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_jenjang_pendidikan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_jenjang_pendidikan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_jenjang_pendidikan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:jenjang_pendidikan_list')

            now = timezone.now()
            qs = MdJenjangPendidikan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_jenjang_pendidikan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenjang pendidikan berhasil dihapus')
            return redirect('manajemen_data:jenjang_pendidikan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdJenjangPendidikan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_tingkat__icontains=search_query)
            | Q(tingkat_pendidikan__icontains=search_query)
            | Q(keterangan__icontains=search_query)
            | Q(group_tk_pend_nm__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = JenjangPendidikanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/list.html', context)


@permission_required_403('manajemen_data', 'md_jenjang_pendidikan', 'create')
def jenjang_pendidikan_create(request):
    if request.method == 'POST':
        form = MdJenjangPendidikanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenjang Pendidikan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenjang-pendidikan-form-success": {"message": "Jenjang Pendidikan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:jenjang_pendidikan_list'),
                })
            return redirect('manajemen_data:jenjang_pendidikan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenjang-pendidikan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/form.html', {'form': form, 'edit_mode': False})

    form = MdJenjangPendidikanForm()
    return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_jenjang_pendidikan', 'edit')
def jenjang_pendidikan_edit(request, pk):
    obj = get_object_or_404(MdJenjangPendidikan, id=pk)
    if request.method == 'POST':
        form = MdJenjangPendidikanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenjang Pendidikan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenjang-pendidikan-form-success": {"message": "Jenjang Pendidikan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:jenjang_pendidikan_list'),
                })
            return redirect('manajemen_data:jenjang_pendidikan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenjang-pendidikan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(
            request,
            'manajemen_data/access/ma_da_jenjang_pendidikan/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MdJenjangPendidikanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_jenjang_pendidikan', 'delete')
def jenjang_pendidikan_delete(request, pk):
    obj = get_object_or_404(MdJenjangPendidikan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenjang Pendidikan berhasil dihapus')
        return redirect('manajemen_data:jenjang_pendidikan_list')
    return render(request, 'manajemen_data/access/ma_da_jenjang_pendidikan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'ms_daftar_pendidikan', 'view')
def daftar_pendidikan_list(request):
    export_qs = MsDaftarPendidikan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, DaftarPendidikanTable, filename_prefix='daftar_pendidikan_export', title='Daftar Pendidikan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_daftar_pendidikan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_daftar_pendidikan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_daftar_pendidikan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'ms_daftar_pendidikan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:daftar_pendidikan_list')

            now = timezone.now()
            qs = MsDaftarPendidikan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_daftar_pendidikan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data daftar pendidikan berhasil dihapus')
            return redirect('manajemen_data:daftar_pendidikan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MsDaftarPendidikan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_pendidikan__icontains=search_query)
            | Q(nm_pendidikan__icontains=search_query)
            | Q(kode_tingkat__tingkat_pendidikan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = DaftarPendidikanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/list.html', context)


@permission_required_403('manajemen_data', 'ms_daftar_pendidikan', 'create')
def daftar_pendidikan_create(request):
    if request.method == 'POST':
        form = MsDaftarPendidikanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Daftar Pendidikan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"daftar-pendidikan-form-success": {"message": "Daftar Pendidikan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:daftar_pendidikan_list'),
                })
            return redirect('manajemen_data:daftar_pendidikan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'daftar-pendidikan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/form.html', {'form': form, 'edit_mode': False})

    form = MsDaftarPendidikanForm()
    return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'ms_daftar_pendidikan', 'edit')
def daftar_pendidikan_edit(request, pk):
    obj = get_object_or_404(MsDaftarPendidikan, id=pk)
    if request.method == 'POST':
        form = MsDaftarPendidikanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Daftar Pendidikan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"daftar-pendidikan-form-success": {"message": "Daftar Pendidikan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:daftar_pendidikan_list'),
                })
            return redirect('manajemen_data:daftar_pendidikan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'daftar-pendidikan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(
            request,
            'manajemen_data/access/ma_da_daftar_pendidikan/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MsDaftarPendidikanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'ms_daftar_pendidikan', 'delete')
def daftar_pendidikan_delete(request, pk):
    obj = get_object_or_404(MsDaftarPendidikan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Daftar Pendidikan berhasil dihapus')
        return redirect('manajemen_data:daftar_pendidikan_list')
    return render(request, 'manajemen_data/access/ma_da_daftar_pendidikan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_kedudukan_pegawai', 'view')
def kedudukan_pegawai_list(request):
    export_qs = MdKedudukanPegawai.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, KedudukanPegawaiTable, filename_prefix='kedudukan_pegawai_export', title='Kedudukan Pegawai Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_kedudukan_pegawai_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_kedudukan_pegawai_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_kedudukan_pegawai_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:kedudukan_pegawai_list')

            now = timezone.now()
            qs = MdKedudukanPegawai.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_kedudukan_pegawai_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data kedudukan pegawai berhasil dihapus')
            return redirect('manajemen_data:kedudukan_pegawai_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdKedudukanPegawai.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_kedudukan_pegawai__icontains=search_query))
    qs = qs.order_by('id')

    table = KedudukanPegawaiTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/list.html', context)


@permission_required_403('manajemen_data', 'md_kedudukan_pegawai', 'create')
def kedudukan_pegawai_create(request):
    if request.method == 'POST':
        form = MdKedudukanPegawaiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kedudukan Pegawai berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kedudukan-pegawai-form-success": {"message": "Kedudukan Pegawai berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:kedudukan_pegawai_list'),
                })
            return redirect('manajemen_data:kedudukan_pegawai_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kedudukan-pegawai-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/form.html', {'form': form, 'edit_mode': False})

    form = MdKedudukanPegawaiForm()
    return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_kedudukan_pegawai', 'edit')
def kedudukan_pegawai_edit(request, pk):
    obj = get_object_or_404(MdKedudukanPegawai, id=pk)
    if request.method == 'POST':
        form = MdKedudukanPegawaiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kedudukan Pegawai berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kedudukan-pegawai-form-success": {"message": "Kedudukan Pegawai berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:kedudukan_pegawai_list'),
                })
            return redirect('manajemen_data:kedudukan_pegawai_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kedudukan-pegawai-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_data/access/ma_da_kedudukan_pegawai/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MdKedudukanPegawaiForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_kedudukan_pegawai', 'delete')
def kedudukan_pegawai_delete(request, pk):
    obj = get_object_or_404(MdKedudukanPegawai, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Kedudukan Pegawai berhasil dihapus')
        return redirect('manajemen_data:kedudukan_pegawai_list')
    return render(request, 'manajemen_data/access/ma_da_kedudukan_pegawai/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_jenis_jabatan', 'view')
def jenis_jabatan_list(request):
    export_qs = MdJenisJabatan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, JenisJabatanTable, filename_prefix='jenis_jabatan_export', title='Jenis Jabatan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_jenis_jabatan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_jenis_jabatan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_jenis_jabatan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:jenis_jabatan_list')

            now = timezone.now()
            qs = MdJenisJabatan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_jenis_jabatan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis jabatan berhasil dihapus')
            return redirect('manajemen_data:jenis_jabatan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdJenisJabatan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(jenis_jabatan__icontains=search_query))
    qs = qs.order_by('id')

    table = JenisJabatanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/list.html', context)


@permission_required_403('manajemen_data', 'md_jenis_jabatan', 'create')
def jenis_jabatan_create(request):
    if request.method == 'POST':
        form = MdJenisJabatanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Jabatan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-jabatan-form-success": {"message": "Jenis Jabatan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:jenis_jabatan_list'),
                })
            return redirect('manajemen_data:jenis_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/form.html', {'form': form, 'edit_mode': False})

    form = MdJenisJabatanForm()
    return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_jenis_jabatan', 'edit')
def jenis_jabatan_edit(request, pk):
    obj = get_object_or_404(MdJenisJabatan, id=pk)
    if request.method == 'POST':
        form = MdJenisJabatanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Jabatan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-jabatan-form-success": {"message": "Jenis Jabatan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:jenis_jabatan_list'),
                })
            return redirect('manajemen_data:jenis_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdJenisJabatanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_jenis_jabatan', 'delete')
def jenis_jabatan_delete(request, pk):
    obj = get_object_or_404(MdJenisJabatan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenis Jabatan berhasil dihapus')
        return redirect('manajemen_data:jenis_jabatan_list')
    return render(request, 'manajemen_data/access/ma_da_jenis_jabatan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_kategori_jabatan', 'view')
def kategori_jabatan_list(request):
    export_qs = MdKategoriJabatan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, KategoriJabatanTable, filename_prefix='kategori_jabatan_export', title='Kategori Jabatan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_kategori_jabatan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_kategori_jabatan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_kategori_jabatan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:kategori_jabatan_list')

            now = timezone.now()
            qs = MdKategoriJabatan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_kategori_jabatan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data kategori jabatan berhasil dihapus')
            return redirect('manajemen_data:kategori_jabatan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdKategoriJabatan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(kj_01__icontains=search_query))
    qs = qs.order_by('id')

    table = KategoriJabatanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/list.html', context)


@permission_required_403('manajemen_data', 'md_kategori_jabatan', 'create')
def kategori_jabatan_create(request):
    if request.method == 'POST':
        form = MdKategoriJabatanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Jabatan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-jabatan-form-success": {"message": "Kategori Jabatan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:kategori_jabatan_list'),
                })
            return redirect('manajemen_data:kategori_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/form.html', {'form': form, 'edit_mode': False})

    form = MdKategoriJabatanForm()
    return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_kategori_jabatan', 'edit')
def kategori_jabatan_edit(request, pk):
    obj = get_object_or_404(MdKategoriJabatan, id=pk)
    if request.method == 'POST':
        form = MdKategoriJabatanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Jabatan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-jabatan-form-success": {"message": "Kategori Jabatan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:kategori_jabatan_list'),
                })
            return redirect('manajemen_data:kategori_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdKategoriJabatanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_kategori_jabatan', 'delete')
def kategori_jabatan_delete(request, pk):
    obj = get_object_or_404(MdKategoriJabatan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Kategori Jabatan berhasil dihapus')
        return redirect('manajemen_data:kategori_jabatan_list')
    return render(request, 'manajemen_data/access/ma_da_kategori_jabatan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_pangkat', 'view')
def pangkat_list(request):
    export_qs = MdPangkat.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, PangkatTable, filename_prefix='pangkat_export', title='Pangkat Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_pangkat_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_pangkat_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_pangkat_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:pangkat_list')

            now = timezone.now()
            qs = MdPangkat.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_pangkat_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data pangkat berhasil dihapus')
            return redirect('manajemen_data:pangkat_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdPangkat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_pangkat__icontains=search_query) | Q(nama_golongan__icontains=search_query))
    qs = qs.order_by('nama_golongan', 'id')

    table = PangkatTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_pangkat/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_pangkat/list.html', context)


@permission_required_403('manajemen_data', 'md_pangkat', 'create')
def pangkat_create(request):
    if request.method == 'POST':
        form = MdPangkatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pangkat berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"pangkat-form-success": {"message": "Pangkat berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:pangkat_list'),
                })
            return redirect('manajemen_data:pangkat_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'pangkat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_pangkat/form.html', {'form': form, 'edit_mode': False})

    form = MdPangkatForm()
    return render(request, 'manajemen_data/access/ma_da_pangkat/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_pangkat', 'edit')
def pangkat_edit(request, pk):
    obj = get_object_or_404(MdPangkat, id=pk)
    if request.method == 'POST':
        form = MdPangkatForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pangkat berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"pangkat-form-success": {"message": "Pangkat berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:pangkat_list'),
                })
            return redirect('manajemen_data:pangkat_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'pangkat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_pangkat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdPangkatForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_pangkat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_pangkat', 'delete')
def pangkat_delete(request, pk):
    obj = get_object_or_404(MdPangkat, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Pangkat berhasil dihapus')
        return redirect('manajemen_data:pangkat_list')
    return render(request, 'manajemen_data/access/ma_da_pangkat/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_jenjang_jabatan', 'view')
def jenjang_jabatan_list(request):
    export_qs = MdJenjangJabatan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, JenjangJabatanTable, filename_prefix='jenjang_jabatan_export', title='Jenjang Jabatan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_jenjang_jabatan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_jenjang_jabatan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_jenjang_jabatan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:jenjang_jabatan_list')

            now = timezone.now()
            qs = MdJenjangJabatan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_jenjang_jabatan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenjang jabatan berhasil dihapus')
            return redirect('manajemen_data:jenjang_jabatan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdJenjangJabatan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_jenjang__icontains=search_query) | Q(id__icontains=search_query))
    qs = qs.order_by('id')

    table = JenjangJabatanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/list.html', context)


@permission_required_403('manajemen_data', 'md_jenjang_jabatan', 'create')
def jenjang_jabatan_create(request):
    if request.method == 'POST':
        form = MdJenjangJabatanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenjang Jabatan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenjang-jabatan-form-success": {"message": "Jenjang Jabatan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:jenjang_jabatan_list'),
                })
            return redirect('manajemen_data:jenjang_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenjang-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/form.html', {'form': form, 'edit_mode': False})

    form = MdJenjangJabatanForm()
    return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_jenjang_jabatan', 'edit')
def jenjang_jabatan_edit(request, pk):
    obj = get_object_or_404(MdJenjangJabatan, pk=pk)
    if request.method == 'POST':
        form = MdJenjangJabatanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenjang Jabatan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenjang-jabatan-form-success": {"message": "Jenjang Jabatan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:jenjang_jabatan_list'),
                })
            return redirect('manajemen_data:jenjang_jabatan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenjang-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdJenjangJabatanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_jenjang_jabatan', 'delete')
def jenjang_jabatan_delete(request, pk):
    obj = get_object_or_404(MdJenjangJabatan, pk=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenjang Jabatan berhasil dihapus')
        return redirect('manajemen_data:jenjang_jabatan_list')
    return render(request, 'manajemen_data/access/ma_da_jenjang_jabatan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_eselon', 'view')
def eselon_list(request):
    export_qs = MdEselon.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, EselonTable, filename_prefix='eselon_export', title='Eselon Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_eselon_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_eselon_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_eselon_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:eselon_list')

            now = timezone.now()
            qs = MdEselon.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_eselon_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data eselon berhasil dihapus')
            return redirect('manajemen_data:eselon_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdEselon.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(eselon__icontains=search_query))
    qs = qs.order_by('urutan', 'id')

    table = EselonTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_eselon/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_eselon/list.html', context)


@permission_required_403('manajemen_data', 'md_eselon', 'create')
def eselon_create(request):
    if request.method == 'POST':
        form = MdEselonForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Eselon berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"eselon-form-success": {"message": "Eselon berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:eselon_list'),
                })
            return redirect('manajemen_data:eselon_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'eselon-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_eselon/form.html', {'form': form, 'edit_mode': False})

    form = MdEselonForm()
    return render(request, 'manajemen_data/access/ma_da_eselon/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_eselon', 'edit')
def eselon_edit(request, pk):
    obj = get_object_or_404(MdEselon, id=pk)
    if request.method == 'POST':
        form = MdEselonForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Eselon berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"eselon-form-success": {"message": "Eselon berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:eselon_list'),
                })
            return redirect('manajemen_data:eselon_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'eselon-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_eselon/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdEselonForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_eselon/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_eselon', 'delete')
def eselon_delete(request, pk):
    obj = get_object_or_404(MdEselon, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Eselon berhasil dihapus')
        return redirect('manajemen_data:eselon_list')
    return render(request, 'manajemen_data/access/ma_da_eselon/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_diklat_struktural', 'view')
def diklat_struktural_list(request):
    export_qs = MdDiklatStruktural.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, DiklatStrukturalTable, filename_prefix='diklat_struktural_export', title='Diklat Struktural Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_diklat_struktural_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_diklat_struktural_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_diklat_struktural_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_diklat_struktural', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:diklat_struktural_list')

            now = timezone.now()
            qs = MdDiklatStruktural.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_diklat_struktural_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data diklat struktural berhasil dihapus')
            return redirect('manajemen_data:diklat_struktural_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdDiklatStruktural.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(diklat_struktural__icontains=search_query) | Q(eselon_level__icontains=search_query))
    qs = qs.order_by('id')

    table = DiklatStrukturalTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_diklat_struktural/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_diklat_struktural/list.html', context)


@permission_required_403('manajemen_data', 'md_diklat_struktural', 'create')
def diklat_struktural_create(request):
    if request.method == 'POST':
        form = MdDiklatStrukturalForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Diklat Struktural berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"diklat-struktural-form-success": {"message": "Diklat Struktural berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:diklat_struktural_list'),
                })
            return redirect('manajemen_data:diklat_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'diklat-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_diklat_struktural/form.html', {'form': form, 'edit_mode': False})

    form = MdDiklatStrukturalForm()
    return render(request, 'manajemen_data/access/ma_da_diklat_struktural/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_diklat_struktural', 'edit')
def diklat_struktural_edit(request, pk):
    obj = get_object_or_404(MdDiklatStruktural, id=pk)
    if request.method == 'POST':
        form = MdDiklatStrukturalForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Diklat Struktural berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"diklat-struktural-form-success": {"message": "Diklat Struktural berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:diklat_struktural_list'),
                })
            return redirect('manajemen_data:diklat_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'diklat-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_diklat_struktural/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdDiklatStrukturalForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_diklat_struktural/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_diklat_struktural', 'delete')
def diklat_struktural_delete(request, pk):
    obj = get_object_or_404(MdDiklatStruktural, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Diklat Struktural berhasil dihapus')
        return redirect('manajemen_data:diklat_struktural_list')
    return render(request, 'manajemen_data/access/ma_da_diklat_struktural/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_jenis_surat', 'view')
def jenis_surat_list(request):
    export_qs = MdJenisSurat.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, JenisSuratTable, filename_prefix='jenis_surat_export', title='Jenis Surat Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_jenis_surat_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_jenis_surat_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_jenis_surat_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:jenis_surat_list')

            now = timezone.now()
            qs = MdJenisSurat.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_jenis_surat_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis surat berhasil dihapus')
            return redirect('manajemen_data:jenis_surat_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdJenisSurat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(js_01__icontains=search_query))
    qs = qs.order_by('js_02', 'id')

    table = JenisSuratTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_jenis_surat/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_jenis_surat/list.html', context)


@permission_required_403('manajemen_data', 'md_jenis_surat', 'create')
def jenis_surat_create(request):
    if request.method == 'POST':
        form = MdJenisSuratForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Surat berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-surat-form-success": {"message": "Jenis Surat berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:jenis_surat_list'),
                })
            return redirect('manajemen_data:jenis_surat_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-surat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_surat/form.html', {'form': form, 'edit_mode': False})

    form = MdJenisSuratForm()
    return render(request, 'manajemen_data/access/ma_da_jenis_surat/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_jenis_surat', 'edit')
def jenis_surat_edit(request, pk):
    obj = get_object_or_404(MdJenisSurat, id=pk)
    if request.method == 'POST':
        form = MdJenisSuratForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Surat berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-surat-form-success": {"message": "Jenis Surat berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:jenis_surat_list'),
                })
            return redirect('manajemen_data:jenis_surat_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-surat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_surat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdJenisSuratForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_jenis_surat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_jenis_surat', 'delete')
def jenis_surat_delete(request, pk):
    obj = get_object_or_404(MdJenisSurat, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenis Surat berhasil dihapus')
        return redirect('manajemen_data:jenis_surat_list')
    return render(request, 'manajemen_data/access/ma_da_jenis_surat/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_pejabat_menetapkan', 'view')
def pejabat_menetapkan_list(request):
    export_qs = MdPejabatMenetapkan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, PejabatMenetapkanTable, filename_prefix='pejabat_menetapkan_export', title='Pejabat Menetapkan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_pejabat_menetapkan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_pejabat_menetapkan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_pejabat_menetapkan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:pejabat_menetapkan_list')

            now = timezone.now()
            qs = MdPejabatMenetapkan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_pejabat_menetapkan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data pejabat menetapkan berhasil dihapus')
            return redirect('manajemen_data:pejabat_menetapkan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdPejabatMenetapkan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(pm_01__icontains=search_query) | Q(kode_pejabat_menetapkan__icontains=search_query))
    qs = qs.order_by('pm_03', 'id')

    table = PejabatMenetapkanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/list.html', context)


@permission_required_403('manajemen_data', 'md_pejabat_menetapkan', 'create')
def pejabat_menetapkan_create(request):
    if request.method == 'POST':
        form = MdPejabatMenetapkanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pejabat Menetapkan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"pejabat-menetapkan-form-success": {"message": "Pejabat Menetapkan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:pejabat_menetapkan_list'),
                })
            return redirect('manajemen_data:pejabat_menetapkan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'pejabat-menetapkan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/form.html', {'form': form, 'edit_mode': False})

    form = MdPejabatMenetapkanForm()
    return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_pejabat_menetapkan', 'edit')
def pejabat_menetapkan_edit(request, pk):
    obj = get_object_or_404(MdPejabatMenetapkan, id=pk)
    if request.method == 'POST':
        form = MdPejabatMenetapkanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pejabat Menetapkan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"pejabat-menetapkan-form-success": {"message": "Pejabat Menetapkan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:pejabat_menetapkan_list'),
                })
            return redirect('manajemen_data:pejabat_menetapkan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'pejabat-menetapkan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdPejabatMenetapkanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_pejabat_menetapkan', 'delete')
def pejabat_menetapkan_delete(request, pk):
    obj = get_object_or_404(MdPejabatMenetapkan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Pejabat Menetapkan berhasil dihapus')
        return redirect('manajemen_data:pejabat_menetapkan_list')
    return render(request, 'manajemen_data/access/ma_da_pejabat_menetapkan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_jenis_organisasi', 'view')
def jenis_organisasi_list(request):
    export_qs = MdJenisOrganisasi.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, JenisOrganisasiTable, filename_prefix='jenis_organisasi_export', title='Jenis Organisasi Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_jenis_organisasi_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_jenis_organisasi_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_jenis_organisasi_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_jenis_organisasi', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:jenis_organisasi_list')

            now = timezone.now()
            qs = MdJenisOrganisasi.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_jenis_organisasi_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis organisasi berhasil dihapus')
            return redirect('manajemen_data:jenis_organisasi_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdJenisOrganisasi.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(jo_01__icontains=search_query))
    qs = qs.order_by('jo_02', 'id')

    table = JenisOrganisasiTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/list.html', context)


@permission_required_403('manajemen_data', 'md_jenis_organisasi', 'create')
def jenis_organisasi_create(request):
    if request.method == 'POST':
        form = MdJenisOrganisasiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Organisasi berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-organisasi-form-success": {"message": "Jenis Organisasi berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:jenis_organisasi_list'),
                })
            return redirect('manajemen_data:jenis_organisasi_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/form.html', {'form': form, 'edit_mode': False})

    form = MdJenisOrganisasiForm()
    return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_jenis_organisasi', 'edit')
def jenis_organisasi_edit(request, pk):
    obj = get_object_or_404(MdJenisOrganisasi, id=pk)
    if request.method == 'POST':
        form = MdJenisOrganisasiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Organisasi berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jenis-organisasi-form-success": {"message": "Jenis Organisasi berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:jenis_organisasi_list'),
                })
            return redirect('manajemen_data:jenis_organisasi_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jenis-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdJenisOrganisasiForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_jenis_organisasi', 'delete')
def jenis_organisasi_delete(request, pk):
    obj = get_object_or_404(MdJenisOrganisasi, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenis Organisasi berhasil dihapus')
        return redirect('manajemen_data:jenis_organisasi_list')
    return render(request, 'manajemen_data/access/ma_da_jenis_organisasi/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_kategori_pemberitahuan', 'view')
def kategori_pemberitahuan_list(request):
    export_qs = MdKategoriPemberitahuan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, KategoriPemberitahuanTable, filename_prefix='kategori_pemberitahuan_export', title='Kategori Pemberitahuan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_kategori_pemberitahuan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_kategori_pemberitahuan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_kategori_pemberitahuan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_kategori_pemberitahuan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:kategori_pemberitahuan_list')

            now = timezone.now()
            qs = MdKategoriPemberitahuan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_kategori_pemberitahuan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data kategori pemberitahuan berhasil dihapus')
            return redirect('manajemen_data:kategori_pemberitahuan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdKategoriPemberitahuan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_kategori_pemberitahuan__icontains=search_query))
    qs = qs.order_by('id')

    table = KategoriPemberitahuanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/list.html', context)


@permission_required_403('manajemen_data', 'md_kategori_pemberitahuan', 'create')
def kategori_pemberitahuan_create(request):
    if request.method == 'POST':
        form = MdKategoriPemberitahuanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Pemberitahuan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-pemberitahuan-form-success": {"message": "Kategori Pemberitahuan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:kategori_pemberitahuan_list'),
                })
            return redirect('manajemen_data:kategori_pemberitahuan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-pemberitahuan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/form.html', {'form': form, 'edit_mode': False})

    form = MdKategoriPemberitahuanForm()
    return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_kategori_pemberitahuan', 'edit')
def kategori_pemberitahuan_edit(request, pk):
    obj = get_object_or_404(MdKategoriPemberitahuan, id=pk)
    if request.method == 'POST':
        form = MdKategoriPemberitahuanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Pemberitahuan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-pemberitahuan-form-success": {"message": "Kategori Pemberitahuan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:kategori_pemberitahuan_list'),
                })
            return redirect('manajemen_data:kategori_pemberitahuan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-pemberitahuan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdKategoriPemberitahuanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_kategori_pemberitahuan', 'delete')
def kategori_pemberitahuan_delete(request, pk):
    obj = get_object_or_404(MdKategoriPemberitahuan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Kategori Pemberitahuan berhasil dihapus')
        return redirect('manajemen_data:kategori_pemberitahuan_list')
    return render(request, 'manajemen_data/access/ma_da_kategori_pemberitahuan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_kategori_peraturan', 'view')
def kategori_peraturan_list(request):
    export_qs = MdKategoriPeraturan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, KategoriPeraturanTable, filename_prefix='kategori_peraturan_export', title='Kategori Peraturan Export')
    if export_resp is not None:
        return export_resp
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_kategori_peraturan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_kategori_peraturan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_kategori_peraturan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_kategori_peraturan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:kategori_peraturan_list')

            now = timezone.now()
            qs = MdKategoriPeraturan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_kategori_peraturan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data kategori peraturan berhasil dihapus')
            return redirect('manajemen_data:kategori_peraturan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdKategoriPeraturan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(KPP_01__icontains=search_query))
    qs = qs.order_by('KPP_02', 'id')

    table = KategoriPeraturanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/list.html', context)


@permission_required_403('manajemen_data', 'md_kategori_peraturan', 'create')
def kategori_peraturan_create(request):
    if request.method == 'POST':
        form = MdKategoriPeraturanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Peraturan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-peraturan-form-success": {"message": "Kategori Peraturan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:kategori_peraturan_list'),
                })
            return redirect('manajemen_data:kategori_peraturan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-peraturan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/form.html', {'form': form, 'edit_mode': False})

    form = MdKategoriPeraturanForm()
    return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_kategori_peraturan', 'edit')
def kategori_peraturan_edit(request, pk):
    obj = get_object_or_404(MdKategoriPeraturan, id=pk)
    if request.method == 'POST':
        form = MdKategoriPeraturanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kategori Peraturan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"kategori-peraturan-form-success": {"message": "Kategori Peraturan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:kategori_peraturan_list'),
                })
            return redirect('manajemen_data:kategori_peraturan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'kategori-peraturan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdKategoriPeraturanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_kategori_peraturan', 'delete')
def kategori_peraturan_delete(request, pk):
    obj = get_object_or_404(MdKategoriPeraturan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Kategori Peraturan berhasil dihapus')
        return redirect('manajemen_data:kategori_peraturan_list')
    return render(request, 'manajemen_data/access/ma_da_kategori_peraturan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_peraturan', 'view')
def peraturan_list(request):
    export_qs = MdPeraturan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, PeraturanTable, filename_prefix='peraturan_export', title='Peraturan Export')
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_peraturan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_peraturan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_peraturan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_peraturan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:peraturan_list')

            now = timezone.now()
            qs = MdPeraturan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_peraturan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data peraturan berhasil dihapus')
            return redirect('manajemen_data:peraturan_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdPeraturan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nomor_peraturan__icontains=search_query) | Q(judul_peraturan__icontains=search_query))
    qs = qs.order_by('-tanggal_peraturan', 'id')

    table = PeraturanTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_peraturan/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_peraturan/list.html', context)


@permission_required_403('manajemen_data', 'md_peraturan', 'create')
def peraturan_create(request):
    if request.method == 'POST':
        form = MdPeraturanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Peraturan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"peraturan-form-success": {"message": "Peraturan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:peraturan_list'),
                })
            return redirect('manajemen_data:peraturan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'peraturan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_peraturan/form.html', {'form': form, 'edit_mode': False})

    form = MdPeraturanForm()
    return render(request, 'manajemen_data/access/ma_da_peraturan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_peraturan', 'edit')
def peraturan_edit(request, pk):
    obj = get_object_or_404(MdPeraturan, id=pk)
    if request.method == 'POST':
        form = MdPeraturanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Peraturan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"peraturan-form-success": {"message": "Peraturan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:peraturan_list'),
                })
            return redirect('manajemen_data:peraturan_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'peraturan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_peraturan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdPeraturanForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_peraturan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_peraturan', 'delete')
def peraturan_delete(request, pk):
    obj = get_object_or_404(MdPeraturan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Peraturan berhasil dihapus')
        return redirect('manajemen_data:peraturan_list')
    return render(request, 'manajemen_data/access/ma_da_peraturan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_data', 'md_tentang', 'view')
def tentang_list(request):
    export_qs = MdTentang.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(request, export_qs, TentangTable, filename_prefix='tentang_export', title='Tentang Export')
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_da_tentang_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_da_tentang_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_da_tentang_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_data', 'md_tentang', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_data:tentang_list')

            now = timezone.now()
            qs = MdTentang.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_da_tentang_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data tentang berhasil dihapus')
            return redirect('manajemen_data:tentang_list')

    search_query = request.GET.get('search', '').strip()
    qs = MdTentang.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama_aplikasi__icontains=search_query) | Q(versi__icontains=search_query) | Q(developer__icontains=search_query))
    qs = qs.order_by('-id')

    table = TentangTable(qs)

    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {'table': table, 'total': qs.count(), 'search_query': search_query}
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_data/access/ma_da_tentang/partials/_table.html', context)
    return render(request, 'manajemen_data/access/ma_da_tentang/list.html', context)


@permission_required_403('manajemen_data', 'md_tentang', 'create')
def tentang_create(request):
    if request.method == 'POST':
        form = MdTentangForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Tentang berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"tentang-form-success": {"message": "Tentang berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_data:tentang_list'),
                })
            return redirect('manajemen_data:tentang_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'tentang-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_tentang/form.html', {'form': form, 'edit_mode': False})

    form = MdTentangForm()
    return render(request, 'manajemen_data/access/ma_da_tentang/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_data', 'md_tentang', 'edit')
def tentang_edit(request, pk):
    obj = get_object_or_404(MdTentang, id=pk)
    if request.method == 'POST':
        form = MdTentangForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Tentang berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"tentang-form-success": {"message": "Tentang berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_data:tentang_list'),
                })
            return redirect('manajemen_data:tentang_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'tentang-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_data/access/ma_da_tentang/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MdTentangForm(instance=obj)
    return render(request, 'manajemen_data/access/ma_da_tentang/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_data', 'md_tentang', 'delete')
def tentang_delete(request, pk):
    obj = get_object_or_404(MdTentang, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Tentang berhasil dihapus')
        return redirect('manajemen_data:tentang_list')
    return render(request, 'manajemen_data/access/ma_da_tentang/delete.html', {'obj': obj})
