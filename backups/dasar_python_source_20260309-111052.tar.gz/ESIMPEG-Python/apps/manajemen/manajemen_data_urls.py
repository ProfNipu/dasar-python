from django.urls import path

from apps.manajemen import manajemen_data as views

app_name = 'manajemen_data'

urlpatterns = [
    path('kategori-pegawai/', views.kategori_pegawai_list, name='kategori_pegawai_list'),
    path('kategori-pegawai/create/', views.kategori_pegawai_create, name='kategori_pegawai_create'),
    path('kategori-pegawai/<int:pk>/edit/', views.kategori_pegawai_edit, name='kategori_pegawai_edit'),
    path('kategori-pegawai/<int:pk>/delete/', views.kategori_pegawai_delete, name='kategori_pegawai_delete'),

    path('agama/', views.agama_list, name='agama_list'),
    path('agama/create/', views.agama_create, name='agama_create'),
    path('agama/<int:pk>/edit/', views.agama_edit, name='agama_edit'),
    path('agama/<int:pk>/delete/', views.agama_delete, name='agama_delete'),

    path('status-perkawinan/', views.status_perkawinan_list, name='status_perkawinan_list'),
    path('status-perkawinan/create/', views.status_perkawinan_create, name='status_perkawinan_create'),
    path('status-perkawinan/<int:pk>/edit/', views.status_perkawinan_edit, name='status_perkawinan_edit'),
    path('status-perkawinan/<int:pk>/delete/', views.status_perkawinan_delete, name='status_perkawinan_delete'),

    path('jenjang-pendidikan/', views.jenjang_pendidikan_list, name='jenjang_pendidikan_list'),
    path('jenjang-pendidikan/create/', views.jenjang_pendidikan_create, name='jenjang_pendidikan_create'),
    path('jenjang-pendidikan/<int:pk>/edit/', views.jenjang_pendidikan_edit, name='jenjang_pendidikan_edit'),
    path('jenjang-pendidikan/<int:pk>/delete/', views.jenjang_pendidikan_delete, name='jenjang_pendidikan_delete'),

    path('daftar-pendidikan/', views.daftar_pendidikan_list, name='daftar_pendidikan_list'),
    path('daftar-pendidikan/create/', views.daftar_pendidikan_create, name='daftar_pendidikan_create'),
    path('daftar-pendidikan/<int:pk>/edit/', views.daftar_pendidikan_edit, name='daftar_pendidikan_edit'),
    path('daftar-pendidikan/<int:pk>/delete/', views.daftar_pendidikan_delete, name='daftar_pendidikan_delete'),

    path('kedudukan-pegawai/', views.kedudukan_pegawai_list, name='kedudukan_pegawai_list'),
    path('kedudukan-pegawai/create/', views.kedudukan_pegawai_create, name='kedudukan_pegawai_create'),
    path('kedudukan-pegawai/<int:pk>/edit/', views.kedudukan_pegawai_edit, name='kedudukan_pegawai_edit'),
    path('kedudukan-pegawai/<int:pk>/delete/', views.kedudukan_pegawai_delete, name='kedudukan_pegawai_delete'),

    path('jenis-jabatan/', views.jenis_jabatan_list, name='jenis_jabatan_list'),
    path('jenis-jabatan/create/', views.jenis_jabatan_create, name='jenis_jabatan_create'),
    path('jenis-jabatan/<int:pk>/edit/', views.jenis_jabatan_edit, name='jenis_jabatan_edit'),
    path('jenis-jabatan/<int:pk>/delete/', views.jenis_jabatan_delete, name='jenis_jabatan_delete'),

    path('kategori-jabatan/', views.kategori_jabatan_list, name='kategori_jabatan_list'),
    path('kategori-jabatan/create/', views.kategori_jabatan_create, name='kategori_jabatan_create'),
    path('kategori-jabatan/<int:pk>/edit/', views.kategori_jabatan_edit, name='kategori_jabatan_edit'),
    path('kategori-jabatan/<int:pk>/delete/', views.kategori_jabatan_delete, name='kategori_jabatan_delete'),

    path('pangkat/', views.pangkat_list, name='pangkat_list'),
    path('pangkat/create/', views.pangkat_create, name='pangkat_create'),
    path('pangkat/<int:pk>/edit/', views.pangkat_edit, name='pangkat_edit'),
    path('pangkat/<int:pk>/delete/', views.pangkat_delete, name='pangkat_delete'),

    path('jenjang-jabatan/', views.jenjang_jabatan_list, name='jenjang_jabatan_list'),
    path('jenjang-jabatan/create/', views.jenjang_jabatan_create, name='jenjang_jabatan_create'),
    path('jenjang-jabatan/<str:pk>/edit/', views.jenjang_jabatan_edit, name='jenjang_jabatan_edit'),
    path('jenjang-jabatan/<str:pk>/delete/', views.jenjang_jabatan_delete, name='jenjang_jabatan_delete'),

    path('eselon/', views.eselon_list, name='eselon_list'),
    path('eselon/create/', views.eselon_create, name='eselon_create'),
    path('eselon/<int:pk>/edit/', views.eselon_edit, name='eselon_edit'),
    path('eselon/<int:pk>/delete/', views.eselon_delete, name='eselon_delete'),

    path('diklat-struktural/', views.diklat_struktural_list, name='diklat_struktural_list'),
    path('diklat-struktural/create/', views.diklat_struktural_create, name='diklat_struktural_create'),
    path('diklat-struktural/<int:pk>/edit/', views.diklat_struktural_edit, name='diklat_struktural_edit'),
    path('diklat-struktural/<int:pk>/delete/', views.diklat_struktural_delete, name='diklat_struktural_delete'),

    path('jenis-surat/', views.jenis_surat_list, name='jenis_surat_list'),
    path('jenis-surat/create/', views.jenis_surat_create, name='jenis_surat_create'),
    path('jenis-surat/<int:pk>/edit/', views.jenis_surat_edit, name='jenis_surat_edit'),
    path('jenis-surat/<int:pk>/delete/', views.jenis_surat_delete, name='jenis_surat_delete'),

    path('pejabat-menetapkan/', views.pejabat_menetapkan_list, name='pejabat_menetapkan_list'),
    path('pejabat-menetapkan/create/', views.pejabat_menetapkan_create, name='pejabat_menetapkan_create'),
    path('pejabat-menetapkan/<int:pk>/edit/', views.pejabat_menetapkan_edit, name='pejabat_menetapkan_edit'),
    path('pejabat-menetapkan/<int:pk>/delete/', views.pejabat_menetapkan_delete, name='pejabat_menetapkan_delete'),

    path('jenis-organisasi/', views.jenis_organisasi_list, name='jenis_organisasi_list'),
    path('jenis-organisasi/create/', views.jenis_organisasi_create, name='jenis_organisasi_create'),
    path('jenis-organisasi/<int:pk>/edit/', views.jenis_organisasi_edit, name='jenis_organisasi_edit'),
    path('jenis-organisasi/<int:pk>/delete/', views.jenis_organisasi_delete, name='jenis_organisasi_delete'),

    path('kategori-pemberitahuan/', views.kategori_pemberitahuan_list, name='kategori_pemberitahuan_list'),
    path('kategori-pemberitahuan/create/', views.kategori_pemberitahuan_create, name='kategori_pemberitahuan_create'),
    path('kategori-pemberitahuan/<int:pk>/edit/', views.kategori_pemberitahuan_edit, name='kategori_pemberitahuan_edit'),
    path('kategori-pemberitahuan/<int:pk>/delete/', views.kategori_pemberitahuan_delete, name='kategori_pemberitahuan_delete'),

    path('kategori-peraturan/', views.kategori_peraturan_list, name='kategori_peraturan_list'),
    path('kategori-peraturan/create/', views.kategori_peraturan_create, name='kategori_peraturan_create'),
    path('kategori-peraturan/<int:pk>/edit/', views.kategori_peraturan_edit, name='kategori_peraturan_edit'),
    path('kategori-peraturan/<int:pk>/delete/', views.kategori_peraturan_delete, name='kategori_peraturan_delete'),

    path('peraturan/', views.peraturan_list, name='peraturan_list'),
    path('peraturan/create/', views.peraturan_create, name='peraturan_create'),
    path('peraturan/<int:pk>/edit/', views.peraturan_edit, name='peraturan_edit'),
    path('peraturan/<int:pk>/delete/', views.peraturan_delete, name='peraturan_delete'),

    path('tentang/', views.tentang_list, name='tentang_list'),
    path('tentang/create/', views.tentang_create, name='tentang_create'),
    path('tentang/<int:pk>/edit/', views.tentang_edit, name='tentang_edit'),
    path('tentang/<int:pk>/delete/', views.tentang_delete, name='tentang_delete'),
]
