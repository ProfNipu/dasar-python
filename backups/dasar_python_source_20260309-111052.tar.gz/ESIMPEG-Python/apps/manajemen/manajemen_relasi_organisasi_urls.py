from django.urls import path

from apps.manajemen import manajemen_relasi_organisasi as views

app_name = 'manajemen_relasi_organisasi'

urlpatterns = [
    path('unit-organisasi-tabel/', views.unit_organisasi_tabel_list, name='unit_organisasi_tabel_list'),
    path('unit-organisasi-tabel/create/', views.unit_organisasi_tabel_create, name='unit_organisasi_tabel_create'),
    path('unit-organisasi-tabel/<int:pk>/edit/', views.unit_organisasi_tabel_edit, name='unit_organisasi_tabel_edit'),
    path('unit-organisasi-tabel/<int:pk>/delete/', views.unit_organisasi_tabel_delete, name='unit_organisasi_tabel_delete'),

    path('unit-organisasi-struktural/', views.unit_organisasi_struktural_list, name='unit_organisasi_struktural_list'),
    path('unit-organisasi-struktural/create/', views.unit_organisasi_struktural_create, name='unit_organisasi_struktural_create'),
    path('unit-organisasi-struktural/<int:pk>/edit/', views.unit_organisasi_struktural_edit, name='unit_organisasi_struktural_edit'),
    path('unit-organisasi-struktural/<int:pk>/delete/', views.unit_organisasi_struktural_delete, name='unit_organisasi_struktural_delete'),
    path('unit-organisasi-struktural/<int:pk>/move-parent/', views.unit_organisasi_struktural_move_parent, name='unit_organisasi_struktural_move_parent'),
    path('unit-organisasi-struktural/search-parent/', views.unit_organisasi_struktural_search_parent, name='unit_organisasi_struktural_search_parent'),

    path('jabatan-struktural-tabel/', views.jabatan_struktural_tabel_list, name='jabatan_struktural_tabel_list'),

    path('jabatan-non-struktural/', views.jabatan_non_struktural_list, name='jabatan_non_struktural_list'),
    path('jabatan-non-struktural/create/', views.jabatan_non_struktural_create, name='jabatan_non_struktural_create'),
    path('jabatan-non-struktural/<int:pk>/edit/', views.jabatan_non_struktural_edit, name='jabatan_non_struktural_edit'),
    path('jabatan-non-struktural/<int:pk>/delete/', views.jabatan_non_struktural_delete, name='jabatan_non_struktural_delete'),

    path('jabatan-struktural-tree/', views.jabatan_struktural_tree_list, name='jabatan_struktural_tree_list'),
    path('jabatan-struktural-tree/add/', views.jabatan_struktural_add, name='jabatan_struktural_add'),
    path('jabatan-struktural-tree/add/<int:opd_id>/', views.jabatan_struktural_add, name='jabatan_struktural_add_with_opd'),
    path('jabatan-struktural-tree/<int:pk>/edit/', views.jabatan_struktural_edit, name='jabatan_struktural_edit'),
    path('jabatan-struktural-tree/<int:pk>/delete/', views.jabatan_struktural_delete, name='jabatan_struktural_delete'),

    # Tambah sub-unit/child
    path('unit-organisasi-add-child/', views.unit_organisasi_add_child, name='unit_organisasi_add_child'),
    path('unit-organisasi-add-child/<str:parent_id>/', views.unit_organisasi_add_child, name='unit_organisasi_add_child_with_parent'),

    # Reusable dropdown (remote searchable select)
    path('ajax/jenis-organisasi/', views.ajax_jenis_organisasi_list, name='ajax_jenis_organisasi_list'),
    path('ajax/unit-kerja/', views.ajax_unit_kerja_list, name='ajax_unit_kerja_list'),
    path('ajax/sub-unit-kerja/', views.ajax_sub_unit_kerja_list, name='ajax_sub_unit_kerja_list'),
    path('ajax/jabatan-struktural/', views.ajax_jabatan_struktural_list, name='ajax_jabatan_struktural_list'),
    path('ajax/jabatan-non-struktural/', views.ajax_jabatan_non_struktural_list, name='ajax_jabatan_non_struktural_list'),
    path('ajax/bkn-jabatan-fungsional/', views.ajax_bkn_jabatan_fungsional_list, name='ajax_bkn_jabatan_fungsional_list'),
    path('ajax/bkn-sub-jabatan/', views.ajax_bkn_sub_jabatan_list, name='ajax_bkn_sub_jabatan_list'),
]
