from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.db import models
from django.db.models import Q
from django.core.exceptions import PermissionDenied
from django.db.models.functions import Coalesce
from types import SimpleNamespace
from django_tables2 import RequestConfig

from apps.manajemen.decorators import permission_required_403
from apps.manajemen.models import UserTableSelection
from apps.master_data.models import MsUnitOrganisasi, MdJenisOrganisasi, MsJabatanStruktural, MsJabatanNonStruktural, BknJabatanFungsional, BknSubJabatan
from apps.manajemen.forms_relasi_organisasi import MsUnitOrganisasiForm, MsUnitOrganisasiSimpleForm, MsUnitOrganisasiChildModalForm, MsUnitOrganisasiEditModalForm, MsUnitOrganisasiMoveParentForm, MsJabatanStrukturalModalForm, MsJabatanNonStrukturalForm
from apps.manajemen.tables_relasi_organisasi import MsUnitOrganisasiTabelTable, MsUnitOrganisasiStrukturalTable, MsUnitOrganisasiHierarkiTable, MsJabatanStrukturalTable, MsJabatanNonStrukturalTable
from apps.manajemen.manajemen_data import handle_datatable_export


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def unit_organisasi_tabel_list(request):
    export_qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MsUnitOrganisasiTabelTable,
        filename_prefix='unit_organisasi_export',
        title='Unit Organisasi Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_or_unit_organisasi_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_or_unit_organisasi_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_or_unit_organisasi_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')

            now = timezone.now()
            qs = MsUnitOrganisasi.objects.filter(pk__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_or_unit_organisasi_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} unit organisasi berhasil dihapus')
            return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')

    search_query = request.GET.get('search', '').strip()
    qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True).exclude(status=0)
    if search_query:
        qs = qs.filter(
            Q(nm_opd__icontains=search_query)
            | Q(id_bkn__icontains=search_query)
            | Q(id_bkn_x__icontains=search_query)
        )
    qs = qs.select_related('parent_id', 'nama_opd_ii', 'nama_bidang_iii', 'nama_sub_bidang_iv').order_by('id_opd')

    table = MsUnitOrganisasiTabelTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/partials/_table.html', context)
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/list.html', context)


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def unit_organisasi_struktural_list(request):
    export_qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MsUnitOrganisasiStrukturalTable,
        filename_prefix='unit_organisasi_struktural_export',
        title='Unit Organisasi Struktural Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_or_unit_organisasi_struktural_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_or_unit_organisasi_struktural_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_or_unit_organisasi_struktural_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

            now = timezone.now()
            qs = MsUnitOrganisasi.objects.filter(pk__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_or_unit_organisasi_struktural_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} unit organisasi berhasil dihapus')
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

    use_khusus = (request.GET.get('use_khusus') or '1') != '0'
    try:
        q = request.GET.copy()
        q['use_khusus'] = '0' if use_khusus else '1'
        toggle_use_khusus_url = f"{request.path}?{q.urlencode()}" if q else request.path
    except Exception:
        toggle_use_khusus_url = request.path

    search_query = request.GET.get('search', '').strip()
    base_qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True)
    qs = base_qs
    match_ids = set()

    def _effective_parent_id(u: MsUnitOrganisasi):
        if use_khusus:
            try:
                pid = getattr(u, 'id_opd_khusus_id', None)
            except Exception:
                pid = None
            if pid:
                return pid
        return getattr(u, 'parent_id_id', None)

    def _unit_sort_key(u: MsUnitOrganisasi):
        try:
            no_urut = getattr(u, 'no_urut', None)
        except Exception:
            no_urut = None
        try:
            nm = (getattr(u, 'nm_opd', None) or '').strip().lower()
        except Exception:
            nm = ''
        try:
            uid = getattr(u, 'id_opd', None)
        except Exception:
            uid = None
        return (no_urut is None, no_urut if no_urut is not None else 0, nm, uid if uid is not None else 0)

    if search_query:
        matches = base_qs.filter(nm_opd__icontains=search_query).order_by('id_opd')
        match_ids = {m.id_opd for m in matches}

    all_nodes = list(base_qs.order_by('id_opd'))
    by_id = {n.id_opd: n for n in all_nodes}

    all_children_map = {}
    for n in all_nodes:
        pid = _effective_parent_id(n)
        if pid is None:
            continue
        all_children_map.setdefault(pid, []).append(n.id_opd)

    for pid, kids in all_children_map.items():
        try:
            kids.sort(key=lambda cid: _unit_sort_key(by_id.get(cid)))
        except Exception:
            try:
                kids.sort()
            except Exception:
                pass

    include_ids = None
    expand_ids = set()

    if search_query:
        include_ids = set(match_ids)
        for mid in match_ids:
            pid = getattr(by_id.get(mid), 'parent_id_id', None) if mid in by_id else None
            while pid and pid in by_id:
                include_ids.add(pid)
                expand_ids.add(pid)
                pid = getattr(by_id[pid], 'parent_id_id', None)

        queue = list(match_ids)
        seen = set(match_ids)
        while queue:
            current = queue.pop(0)
            for cid in all_children_map.get(current, []):
                if cid in seen:
                    continue
                seen.add(cid)
                include_ids.add(cid)
                queue.append(cid)

        qs = base_qs.filter(id_opd__in=include_ids).order_by('id_opd')
    else:
        qs = base_qs.order_by('id_opd')
    children_map = {}
    scoped_nodes = list(qs)
    scoped_ids = {n.id_opd for n in scoped_nodes}
    for n in scoped_nodes:
        pid = _effective_parent_id(n)
        if pid is None:
            continue
        if pid in scoped_ids:
            children_map.setdefault(pid, []).append(n)

    for pid, kids in children_map.items():
        try:
            kids.sort(key=_unit_sort_key)
        except Exception:
            kids.sort(key=lambda x: x.id_opd)

    roots = []
    for n in scoped_nodes:
        pid = _effective_parent_id(n)
        if not pid or pid not in scoped_ids:
            roots.append(n)
    try:
        roots.sort(key=_unit_sort_key)
    except Exception:
        roots.sort(key=lambda x: x.id_opd)

    rows = []

    def _walk_flat(node, depth):
        node_id = node.id_opd
        kids = children_map.get(node_id, [])
        rows.append(
            {
                'node': node,
                'id': node_id,
                'parent_id': getattr(node, 'parent_id_id', None),
                'depth': depth,
                'has_children': bool(kids),
            }
        )
        for c in kids:
            _walk_flat(c, depth + 1)

    for r in roots:
        _walk_flat(r, 0)

    context = {
        'rows': rows,
        'match_ids': match_ids,
        'match_ids_csv': ','.join(str(i) for i in sorted(match_ids)),
        'expand_ids_csv': ','.join(str(i) for i in sorted(expand_ids)),
        'total': qs.count(),
        'search_query': search_query,
        'use_khusus': use_khusus,
        'toggle_use_khusus_url': toggle_use_khusus_url,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/partials/_table.html', context)
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/list.html', context)


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_struktural', 'view')
def jabatan_struktural_tabel_list(request):
    qs = MsJabatanStruktural.objects.filter(deleted_at__isnull=True)

    search_query = request.GET.get('search', '').strip()
    if search_query:
        q_filter = Q(nm_jabatan__icontains=search_query)
        try:
            if str(search_query).isdigit():
                q_filter = q_filter | Q(id_jabatan=int(search_query))
        except Exception:
            pass
        qs = qs.filter(q_filter)

    qs = qs.select_related('id_opd', 'id_sub_opd')
    qs = qs.order_by(
        Coalesce('id_sub_opd__no_urut', 'id_opd__no_urut').asc(nulls_last=True),
        Coalesce('id_sub_opd__nm_opd', 'id_opd__nm_opd').asc(nulls_last=True),
        'id_jabatan',
    )

    table = MsJabatanStrukturalTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tabel/partials/_table.html',
            context,
        )
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tabel/list.html',
        context,
    )


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_struktural', 'view')
def jabatan_struktural_tree_list(request):
    search_query = request.GET.get('search', '').strip()

    use_khusus = (request.GET.get('use_khusus') or '1') != '0'
    try:
        q = request.GET.copy()
        q['use_khusus'] = '0' if use_khusus else '1'
        toggle_use_khusus_url = f"{request.path}?{q.urlencode()}" if q else request.path
    except Exception:
        toggle_use_khusus_url = request.path

    def _effective_parent_id(u: MsUnitOrganisasi):
        if use_khusus:
            try:
                pid = getattr(u, 'id_opd_khusus_id', None)
            except Exception:
                pid = None
            if pid:
                return pid
        return getattr(u, 'parent_id_id', None)

    def _unit_sort_key(u: MsUnitOrganisasi):
        try:
            no_urut = getattr(u, 'no_urut', None)
        except Exception:
            no_urut = None
        try:
            nm = (getattr(u, 'nm_opd', None) or '').strip().lower()
        except Exception:
            nm = ''
        try:
            uid = getattr(u, 'id_opd', None)
        except Exception:
            uid = None
        return (no_urut is None, no_urut if no_urut is not None else 0, nm, uid if uid is not None else 0)

    all_units_all = list(
        MsUnitOrganisasi.objects.filter(deleted_at__isnull=True).order_by('id_opd')
    )
    by_id_all = {u.id_opd: u for u in all_units_all}

    base_units = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True, status=1)
    all_units_active = list(base_units.order_by('id_opd'))

    # Opsi B: if a unit's parent/ancestor is non-aktif, then the unit is treated as not shown
    # (subtree is hidden even if the child itself is aktif).
    allowed_ids = set()
    for u in all_units_active:
        cur = u
        ok = True
        guard = 0
        while cur is not None and guard < 50:
            guard += 1
            if getattr(cur, 'status', None) != 1:
                ok = False
                break
            pid = getattr(cur, 'parent_id_id', None)
            if not pid:
                break
            cur = by_id_all.get(pid)
        if ok:
            allowed_ids.add(u.id_opd)

    all_units = [u for u in all_units_active if u.id_opd in allowed_ids]
    by_id = {u.id_opd: u for u in all_units}

    # Build ALL children map (aktif+nonaktif) for search traversal.
    unit_children_map_all = {}
    for u in all_units_all:
        pid = _effective_parent_id(u)
        if not pid:
            continue
        unit_children_map_all.setdefault(pid, []).append(u.id_opd)
    for pid, kids in unit_children_map_all.items():
        try:
            kids.sort(key=lambda cid: _unit_sort_key(by_id_all.get(cid)))
        except Exception:
            try:
                kids.sort()
            except Exception:
                pass

    # Map jabatan -> unit_id (prefer id_sub_opd, fallback id_opd)
    def _jabatan_unit_id(j: MsJabatanStruktural):
        sub_id = getattr(j, 'id_sub_opd_id', None)
        if sub_id:
            return sub_id
        return getattr(j, 'id_opd_id', None)

    match_unit_ids = set()
    if search_query:
        match_unit_ids |= set(
            base_units.filter(nm_opd__icontains=search_query).values_list('id_opd', flat=True)
        )

        jab_matches = MsJabatanStruktural.objects.filter(deleted_at__isnull=True, nm_jabatan__icontains=search_query)
        for j in jab_matches.only('id_jabatan', 'id_opd_id', 'id_sub_opd_id'):
            uid = _jabatan_unit_id(j)
            if uid:
                match_unit_ids.add(uid)

    include_ids = None
    expand_ids = set()

    if search_query:
        include_ids = set(match_unit_ids)

        # add ancestors and auto-expand them
        for mid in list(match_unit_ids):
            pid = _effective_parent_id(by_id_all.get(mid)) if mid in by_id_all else None
            while pid and pid in by_id_all:
                pnode = by_id_all.get(pid)
                if getattr(pnode, 'status', None) == 1 and pid in by_id:
                    include_ids.add(pid)
                    expand_ids.add(pid)
                pid = _effective_parent_id(pnode)

        # add descendants so context is visible
        queue = list(match_unit_ids)
        seen = set(queue)
        while queue:
            cur = queue.pop(0)
            for cid in unit_children_map_all.get(cur, []) or []:
                if cid in seen:
                    continue
                seen.add(cid)
                # Only include nodes that are allowed (aktif + all ancestors aktif)
                if cid in allowed_ids and cid in by_id:
                    include_ids.add(cid)
                queue.append(cid)

    scoped_units = all_units if include_ids is None else [by_id[i] for i in include_ids if i in by_id]
    scoped_ids = {u.id_opd for u in scoped_units}

    # Unit children map within scope using real parent pointers (since allowed_ids already guarantees the chain).
    scoped_children_units = {}
    roots = []
    for u in scoped_units:
        pid = _effective_parent_id(u)
        if pid and pid in scoped_ids:
            scoped_children_units.setdefault(pid, []).append(u)
        else:
            roots.append(u)
    for pid, kids in scoped_children_units.items():
        try:
            kids.sort(key=_unit_sort_key)
        except Exception:
            pass
    try:
        roots.sort(key=_unit_sort_key)
    except Exception:
        pass

    # Fetch jabatan for scoped units
    jabatan_qs = MsJabatanStruktural.objects.filter(deleted_at__isnull=True)
    jabatan_qs = jabatan_qs.select_related('id_eselon').order_by('id_jabatan')
    jabatan_by_unit = {}
    total_jabatan = 0
    for j in jabatan_qs:
        uid = _jabatan_unit_id(j)
        if not uid or uid not in scoped_ids:
            continue
        jabatan_by_unit.setdefault(uid, []).append(j)
        total_jabatan += 1

    def _jabatan_summary(unit_id: int) -> str:
        items = jabatan_by_unit.get(unit_id, [])
        names = []
        for it in items[:3]:
            nm = (getattr(it, 'nm_jabatan', None) or '').strip()
            if nm:
                names.append(nm)
        if not names:
            return '-'
        if len(items) > 3:
            return ', '.join(names) + f' (+{len(items) - 3})'
        return ', '.join(names)

    rows = []

    def _walk(unit: MsUnitOrganisasi, depth: int):
        unit_id = unit.id_opd
        unit_row_id = f'unit-{unit_id}'
        unit_kids = scoped_children_units.get(unit_id, [])
        jab_kids = jabatan_by_unit.get(unit_id, [])
        rows.append(
            SimpleNamespace(
                id=unit_row_id,
                parent_id=f"unit-{getattr(unit, 'parent_id_id', '')}" if getattr(unit, 'parent_id_id', None) in scoped_ids else '',
                depth=depth,
                has_children=bool(unit_kids) or bool(jab_kids),
                kind='unit',
                node=unit,
                jabatan_summary=_jabatan_summary(unit_id),
            )
        )

        # jabatan children first
        for j in jab_kids:
            rows.append(
                SimpleNamespace(
                    id=f'jabatan-{j.id_jabatan}',
                    parent_id=unit_row_id,
                    depth=depth + 1,
                    has_children=False,
                    kind='jabatan',
                    node=j,
                )
            )

        # then unit children
        for c in unit_kids:
            _walk(c, depth + 1)

    for r in roots:
        _walk(r, 0)

    context = {
        'rows': rows,
        'match_unit_ids': match_unit_ids,
        'expand_ids': expand_ids,
        'total_units': len(scoped_units),
        'total_jabatan': total_jabatan,
        'search_query': search_query,
        'use_khusus': use_khusus,
        'toggle_use_khusus_url': toggle_use_khusus_url,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tree/partials/_table.html',
            context,
        )
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tree/list.html',
        context,
    )


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_non_struktural', 'view')
def jabatan_non_struktural_list(request):
    qs = MsJabatanNonStruktural.objects.filter(deleted_at__isnull=True)

    search_query = request.GET.get('search', '').strip()
    if search_query:
        q_filter = Q(nama_jabatan__icontains=search_query) | Q(id_bkn__icontains=search_query)
        try:
            if str(search_query).isdigit():
                q_filter = q_filter | Q(id_jabatan_fungsional=int(search_query))
        except Exception:
            pass
        qs = qs.filter(q_filter)

    qs = qs.select_related('id_jenis_jabatan', 'kategori_jabatan').order_by('id_jabatan_fungsional')

    table = MsJabatanNonStrukturalTable(qs)

    table.request = request
    bkn_key_list = list(
        qs.exclude(id_bkn__isnull=True).exclude(id_bkn='').values_list('id_bkn', flat=True).distinct()
    )
    bkn_map = {}
    if bkn_key_list:
        bkn_rows = (
            BknJabatanFungsional.objects.filter(deleted_at__isnull=True, kel_jabatan_id__in=bkn_key_list)
            .values('kel_jabatan_id', 'nama', 'jenjang')
        )
        for r in bkn_rows:
            key = (r.get('kel_jabatan_id') or '').strip()
            if not key:
                continue
            info = bkn_map.get(key)
            if info is None:
                info = {'nama': '', 'jenjang_set': set()}
                bkn_map[key] = info
            nama = (r.get('nama') or '').strip()
            if nama and not info.get('nama'):
                info['nama'] = nama
            jenjang = (r.get('jenjang') or '').strip()
            if jenjang:
                info['jenjang_set'].add(jenjang)

    for k, v in bkn_map.items():
        v['jenjang_list'] = sorted(list(v.get('jenjang_set') or set()))
        if 'jenjang_set' in v:
            del v['jenjang_set']

    table.bkn_map = bkn_map
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/partials/_table.html',
            context,
        )
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/list.html',
        context,
    )


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_non_struktural', 'create')
def jabatan_non_struktural_create(request):
    if request.method == 'POST':
        form = MsJabatanNonStrukturalForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Non Struktural berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jabatan-non-struktural-form-success": {"message": "Jabatan Non Struktural berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:jabatan_non_struktural_list'),
                })
            return redirect('manajemen_relasi_organisasi:jabatan_non_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jabatan-non-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/form.html',
            {'form': form, 'edit_mode': False},
        )

    form = MsJabatanNonStrukturalForm()
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/form.html',
        {'form': form, 'edit_mode': False},
    )


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_non_struktural', 'edit')
def jabatan_non_struktural_edit(request, pk):
    obj = get_object_or_404(MsJabatanNonStruktural, pk=pk)
    if request.method == 'POST':
        form = MsJabatanNonStrukturalForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Non Struktural berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jabatan-non-struktural-form-success": {"message": "Jabatan Non Struktural berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:jabatan_non_struktural_list'),
                })
            return redirect('manajemen_relasi_organisasi:jabatan_non_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jabatan-non-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MsJabatanNonStrukturalForm(instance=obj)
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_jabatan_non_struktural/form.html',
        {'form': form, 'edit_mode': True, 'obj': obj},
    )


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_non_struktural', 'delete')
def jabatan_non_struktural_delete(request, pk):
    obj = get_object_or_404(MsJabatanNonStruktural, pk=pk)
    obj.deleted_at = timezone.now()
    obj.save(update_fields=['deleted_at'])
    messages.success(request, 'Jabatan Non Struktural berhasil dihapus')
    return redirect('manajemen_relasi_organisasi:jabatan_non_struktural_list')


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_struktural', 'create')
def jabatan_struktural_add(request, opd_id=None):
    parent_unit = None
    root_unit = None
    top_unit = None
    opd_induk = None
    effective_opd = None
    opd_by_type = None
    if opd_id:
        try:
            parent_unit = MsUnitOrganisasi.objects.get(id_opd=opd_id, deleted_at__isnull=True)
        except MsUnitOrganisasi.DoesNotExist:
            parent_unit = None

    if parent_unit is not None:
        def _is_opd_induk_type(unit):
            try:
                t = getattr(unit, 'type_opd', None) or getattr(unit, 'id_unit', None)
                if getattr(t, 'is_opd_induk', False):
                    return True
                name = (getattr(t, 'jo_01', None) or '').strip().lower()
            except Exception:
                name = ''
            if not name:
                return False
            opd_induk_types = {
                'sekretariat daerah',
                'sekretariat dprd',
                'inspektorat',
                'badan',
                'dinas',
                'satuan polisi',
                'rumah sakit umum daerah',
                'kantor camat',
            }
            return name in opd_induk_types

        def _find_opd_induk_by_type(start_unit):
            cur = start_unit
            guard = 0
            while cur is not None and guard < 50:
                if _is_opd_induk_type(cur):
                    return cur
                pid = getattr(cur, 'parent_id_id', None)
                if not pid:
                    break
                try:
                    cur = MsUnitOrganisasi.objects.select_related('type_opd', 'id_unit', 'parent_id').get(
                        id_opd=pid,
                        deleted_at__isnull=True,
                    )
                except MsUnitOrganisasi.DoesNotExist:
                    break
                guard += 1
            return None

        try:
            parent_unit = MsUnitOrganisasi.objects.select_related('type_opd', 'id_unit', 'parent_id', 'nama_opd_ii').get(
                id_opd=parent_unit.id_opd,
                deleted_at__isnull=True,
            )
        except Exception:
            pass

        opd_by_type = _find_opd_induk_by_type(parent_unit)

        root_unit = parent_unit
        try:
            guard = 0
            while getattr(root_unit, 'parent_id_id', None) and guard < 50:
                root_unit = root_unit.parent_id
                guard += 1
        except Exception:
            root_unit = parent_unit

        top_unit = parent_unit
        try:
            guard = 0
            while (
                getattr(top_unit, 'parent_id_id', None)
                and root_unit is not None
                and getattr(top_unit.parent_id, 'id_opd', None) != getattr(root_unit, 'id_opd', None)
                and guard < 50
            ):
                top_unit = top_unit.parent_id
                guard += 1
        except Exception:
            top_unit = parent_unit

        try:
            opd_induk = getattr(parent_unit, 'nama_opd_ii', None)
        except Exception:
            opd_induk = None

        # Some datasets map nama_opd_ii to the root instansi (Kabupaten). For jabatan grouping,
        # we want OPD level II (e.g., Kecamatan/Dinas). If nama_opd_ii points to root, ignore it.
        try:
            if (
                opd_induk is not None
                and getattr(opd_induk, 'id_opd', None)
                and root_unit is not None
                and getattr(root_unit, 'id_opd', None)
                and str(opd_induk.id_opd) == str(root_unit.id_opd)
            ):
                opd_induk = None
        except Exception:
            pass

        effective_opd = opd_by_type or opd_induk or top_unit

    if request.method == 'POST':
        post_data = request.POST.copy()
        if parent_unit is not None:
            if effective_opd is not None and getattr(effective_opd, 'id_opd', None):
                post_data['id_opd'] = str(effective_opd.id_opd)
            post_data['id_sub_opd'] = str(parent_unit.id_opd)
        form = MsJabatanStrukturalModalForm(post_data)
        if form.is_valid():
            instance = form.save()
            now = timezone.now()
            update_fields = []
            if getattr(instance, 'created_at', None) is None:
                instance.created_at = now
                update_fields.append('created_at')
            instance.updated_at = now
            update_fields.append('updated_at')
            if update_fields:
                instance.save(update_fields=update_fields)
            messages.success(request, 'Jabatan Struktural berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jabatan-struktural-form-success": {"message": "Jabatan Struktural berhasil ditambahkan"}}'
                })
            return redirect('manajemen_relasi_organisasi:jabatan_struktural_tree_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jabatan-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

    form = MsJabatanStrukturalModalForm()
    if parent_unit is not None:
        if effective_opd is not None and getattr(effective_opd, 'id_opd', None):
            form.fields['id_opd'].initial = effective_opd.id_opd
        form.fields['id_sub_opd'].initial = parent_unit.id_opd

    context = {
        'form': form,
        'parent_unit': parent_unit,
        'edit_mode': False,
    }

    if request.headers.get('HX-Request'):
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tree/partials/_add_modal_content.html',
            context,
        )
    return redirect('manajemen_relasi_organisasi:jabatan_struktural_tree_list')


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_struktural', 'edit')
def jabatan_struktural_edit(request, pk):
    obj = get_object_or_404(MsJabatanStruktural, pk=pk)
    if request.method == 'POST':
        post_data = request.POST.copy()
        try:
            post_data['id_opd'] = str(getattr(obj, 'id_opd_id', '') or '')
            post_data['id_sub_opd'] = str(getattr(obj, 'id_sub_opd_id', '') or '')
            post_data['id_opd_lama'] = str(getattr(obj, 'id_opd_lama_id', '') or '')
        except Exception:
            pass
        form = MsJabatanStrukturalModalForm(post_data, instance=obj)
        if form.is_valid():
            instance = form.save()
            try:
                instance.updated_at = timezone.now()
                instance.save(update_fields=['updated_at'])
            except Exception:
                pass
            messages.success(request, 'Jabatan Struktural berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"jabatan-struktural-form-success": {"message": "Jabatan Struktural berhasil diupdate"}}'
                })
            return redirect('manajemen_relasi_organisasi:jabatan_struktural_tree_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'jabatan-struktural-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

    form = MsJabatanStrukturalModalForm(instance=obj)
    context = {
        'form': form,
        'obj': obj,
        'edit_mode': True,
        'parent_unit': getattr(obj, 'id_opd', None),
    }
    if request.headers.get('HX-Request'):
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_jabatan_struktural_tree/partials/_edit_modal_content.html',
            context,
        )
    return redirect('manajemen_relasi_organisasi:jabatan_struktural_tree_list')


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_jabatan_struktural', 'delete')
def jabatan_struktural_delete(request, pk):
    obj = get_object_or_404(MsJabatanStruktural, pk=pk)
    now = timezone.now()
    obj.deleted_at = now
    obj.updated_at = now
    obj.save(update_fields=['deleted_at', 'updated_at'])
    messages.success(request, 'Jabatan Struktural berhasil dihapus')
    return redirect('manajemen_relasi_organisasi:jabatan_struktural_tree_list')


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def unit_organisasi_struktural_search_parent(request):
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '5'
    exclude = (request.GET.get('exclude') or '').strip()
    desc_levels = request.GET.get('desc_levels') or '1'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 10
    except Exception:
        page_size = 10
    # Hard limit to avoid huge payload
    page_size = min(page_size, 50)

    try:
        desc_levels = int(desc_levels)
        if desc_levels < 0:
            desc_levels = 0
    except Exception:
        desc_levels = 1
    # Hard cap to keep response safe
    desc_levels = min(desc_levels, 3)

    exclude_ids = []
    if exclude:
        try:
            exclude_ids = [int(x) for x in exclude.split(',') if x.strip().isdigit()]
        except Exception:
            exclude_ids = []

    base_qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True)
    if exclude_ids:
        base_qs = base_qs.exclude(pk__in=exclude_ids)

    # Matched page (primary results)
    qs = base_qs
    if q:
        qs = qs.filter(nm_opd__icontains=q)
    qs = qs.order_by(Coalesce('no_urut', 999999), 'nm_opd')

    offset = (page - 1) * page_size
    matched = list(qs.values('pk', 'nm_opd', 'parent_id_id')[offset:offset + page_size + 1])
    has_more = len(matched) > page_size
    matched = matched[:page_size]

    # Expand context: include ancestors and limited descendants for matched nodes
    max_depth = 10
    max_descendant_levels = desc_levels

    want_ids = set(int(o.get('pk')) for o in matched if o.get('pk') is not None)
    parent_map = {int(o.get('pk')): (o.get('parent_id_id') or None) for o in matched if o.get('pk') is not None}

    # Ancestors
    to_fetch = set()
    for _, pid in parent_map.items():
        if pid and pid not in parent_map and pid not in exclude_ids:
            to_fetch.add(pid)
    for _ in range(max_depth):
        if not to_fetch:
            break
        rows = list(MsUnitOrganisasi.objects.filter(pk__in=list(to_fetch), deleted_at__isnull=True).values('pk', 'nm_opd', 'parent_id_id'))
        to_fetch = set()
        for r in rows:
            pk = r.get('pk')
            pid = r.get('parent_id_id') or None
            if pk is None:
                continue
            want_ids.add(int(pk))
            parent_map[int(pk)] = pid
            if pid and pid not in parent_map and pid not in exclude_ids:
                to_fetch.add(pid)

    # Siblings: for each ancestor chain node, include other children of its parent (e.g. Tahun 2020 next to Tahun 2021)
    try:
        # Collect a few chain nodes (from matched) so we can add siblings in a stable, bounded way
        chain_nodes = []
        for o in matched[:3]:
            pk = o.get('pk')
            if pk is None:
                continue
            cur = int(pk)
            seen_chain = set()
            for _ in range(max_depth):
                if cur in seen_chain:
                    break
                seen_chain.add(cur)
                chain_nodes.append(cur)
                pid = parent_map.get(cur)
                if not pid:
                    break
                cur = int(pid)

        # De-dup while keeping order
        chain_nodes_unique = []
        seen_cn = set()
        for n in chain_nodes:
            if n in seen_cn:
                continue
            seen_cn.add(n)
            chain_nodes_unique.append(n)

        # Add siblings for nodes in the chain (except root where parent_id is None)
        for node_id in chain_nodes_unique:
            remaining = max(0, page_size - len(want_ids))
            if remaining <= 0:
                break
            parent_id = parent_map.get(node_id)
            if not parent_id:
                continue
            sibs = list(
                base_qs.filter(parent_id_id=parent_id)
                .order_by('nm_opd')
                .values('pk', 'nm_opd', 'parent_id_id')[:remaining]
            )
            for r in sibs:
                pk = r.get('pk')
                if pk is None:
                    continue
                pk_i = int(pk)
                if pk_i in want_ids:
                    continue
                want_ids.add(pk_i)
                parent_map[pk_i] = r.get('parent_id_id') or None
    except Exception:
        pass

    # Descendants (limited)
    level_parents = set(int(o.get('pk')) for o in matched if o.get('pk') is not None)
    for _ in range(max_descendant_levels):
        if not level_parents:
            break
        remaining = max(0, page_size - len(want_ids))
        if remaining <= 0:
            break
        children_rows = list(
            base_qs.filter(parent_id_id__in=list(level_parents))
            .order_by('nm_opd')
            .values('pk', 'nm_opd', 'parent_id_id')[:remaining]
        )
        next_level = set()
        for r in children_rows:
            pk = r.get('pk')
            pid = r.get('parent_id_id') or None
            if pk is None:
                continue
            if int(pk) in want_ids:
                continue
            want_ids.add(int(pk))
            parent_map[int(pk)] = pid
            next_level.add(int(pk))
        level_parents = next_level

    # Fetch all required rows (for labels + parent pointers)
    rows_all = list(base_qs.filter(pk__in=list(want_ids)).values('pk', 'nm_opd', 'parent_id_id'))
    name_map = {int(r.get('pk')): (r.get('nm_opd') or '') for r in rows_all if r.get('pk') is not None}
    for r in rows_all:
        pk = r.get('pk')
        if pk is None:
            continue
        parent_map[int(pk)] = r.get('parent_id_id') or None

    def compute_depth(pk: int) -> int:
        depth = 0
        seen = set()
        cur = pk
        while depth < max_depth:
            pid = parent_map.get(cur)
            if not pid:
                break
            if pid in seen:
                break
            seen.add(pid)
            depth += 1
            cur = pid
        return depth

    def compute_root(pk: int) -> int:
        seen = set()
        cur = pk
        for _ in range(max_depth):
            pid = parent_map.get(cur)
            if not pid:
                return cur
            if pid in seen:
                return cur
            seen.add(pid)
            cur = pid
        return cur

    def format_label(name: str, depth: int) -> str:
        name = name or ''
        if depth <= 0:
            return name
        # Make the branch line visually longer as depth increases (like common tree pickers)
        # Example:
        # depth 1: ├──── Nama
        # depth 2: ├──────── Nama
        # depth 3: ├──────────── Nama
        return ('│   ' * (depth - 1)) + '├' + ('────' * depth) + ' ' + name

    # Order results in tree traversal order (pre-order): root -> children -> grandchildren.
    # This makes the dropdown feel similar to the list table which is based on parent_id.
    ids_in_set = [int(r.get('pk')) for r in rows_all if r.get('pk') is not None]
    ids_set = set(ids_in_set)
    children_map = {}
    for pk in ids_in_set:
        pid = parent_map.get(pk)
        if pid and int(pid) in ids_set:
            children_map.setdefault(int(pid), []).append(pk)
        else:
            children_map.setdefault(None, []).append(pk)

    def sort_key(pk: int):
        return (name_map.get(pk) or '').lower()

    for k, v in list(children_map.items()):
        try:
            children_map[k] = sorted(v, key=sort_key)
        except Exception:
            pass

    ids_sorted = []
    seen_walk = set()

    def walk(node_id: int):
        if node_id in seen_walk:
            return
        seen_walk.add(node_id)
        ids_sorted.append(node_id)
        for ch in children_map.get(node_id, []) or []:
            walk(ch)

    for root_id in children_map.get(None, []) or []:
        walk(root_id)

    results = []
    for pk in ids_sorted[:page_size]:
        try:
            if not (name_map.get(pk) or '').strip():
                continue
        except Exception:
            continue
        depth = compute_depth(pk)
        results.append({'value': str(pk), 'label': format_label(name_map.get(pk) or '', depth)})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_jabatan_struktural_list(request):
    id_opd = (request.GET.get('id_opd') or '').strip()
    id_sub_opd = (request.GET.get('id_sub_opd') or '').strip()
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 20000)

    if not id_opd.isdigit():
        return JsonResponse({'results': [], 'has_more': False})

    qs = MsJabatanStruktural.objects.filter(deleted_at__isnull=True).exclude(status=0)
    try:
        if id_sub_opd.isdigit():
            qs = qs.filter(id_sub_opd_id=int(id_sub_opd))
        else:
            qs = qs.filter(id_opd_id=int(id_opd))
    except Exception:
        return JsonResponse({'results': [], 'has_more': False})

    if q:
        q_filter = Q(nm_jabatan__icontains=q)
        try:
            if str(q).isdigit():
                q_filter = q_filter | Q(id_jabatan=int(q))
        except Exception:
            pass
        qs = qs.filter(q_filter)

    qs = qs.order_by('id_jabatan')

    offset = (page - 1) * page_size
    rows = list(qs.values('id_jabatan', 'nm_jabatan')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id_jabatan')
        label = (r.get('nm_jabatan') or '').strip()
        if val is None or not label:
            continue
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_jabatan_non_struktural_list(request):
    id_jenis_jabatan = (request.GET.get('id_jenis_jabatan') or '').strip()
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 20000)

    if not id_jenis_jabatan.isdigit():
        return JsonResponse({'results': [], 'has_more': False})

    qs = MsJabatanNonStruktural.objects.filter(deleted_at__isnull=True, id_status=1)
    try:
        qs = qs.filter(id_jenis_jabatan_id=int(id_jenis_jabatan))
    except Exception:
        return JsonResponse({'results': [], 'has_more': False})

    if q:
        q_filter = Q(nama_jabatan__icontains=q)
        try:
            if str(q).isdigit():
                q_filter = q_filter | Q(id_jabatan_fungsional=int(q))
        except Exception:
            pass
        qs = qs.filter(q_filter)

    qs = qs.order_by('id_jabatan_fungsional')

    offset = (page - 1) * page_size
    rows = list(qs.values('id_jabatan_fungsional', 'nama_jabatan')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id_jabatan_fungsional')
        label = (r.get('nama_jabatan') or '').strip()
        if val is None or not label:
            continue
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_bkn_jabatan_fungsional_list(request):
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 20000)

    qs = BknJabatanFungsional.objects.filter(deleted_at__isnull=True)
    if q:
        q_filter = Q(nama__icontains=q) | Q(id_bkn__icontains=q)
        try:
            if str(q).isdigit():
                q_filter = q_filter | Q(id=int(q))
        except Exception:
            pass
        qs = qs.filter(q_filter)

    qs = qs.order_by('id')

    offset = (page - 1) * page_size
    rows = list(qs.values('id', 'nama')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id')
        label = (r.get('nama') or '').strip()
        if val is None or not label:
            continue
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_bkn_sub_jabatan_list(request):
    id_jabatan_list = [str(v).strip() for v in (request.GET.getlist('id_jabatan') or []) if str(v).strip()]
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 20000)

    # Derive kel_jabatan_id(s) from selected BKN Jabatan Fungsional
    jabatan_ids = [int(v) for v in id_jabatan_list if str(v).isdigit()]
    if not jabatan_ids:
        return JsonResponse({'results': [], 'has_more': False})

    kel_list = list(
        BknJabatanFungsional.objects.filter(deleted_at__isnull=True, id__in=jabatan_ids)
        .exclude(kel_jabatan_id__isnull=True)
        .exclude(kel_jabatan_id='')
        .values_list('kel_jabatan_id', flat=True)
    )
    kel_list = [str(k).strip() for k in kel_list if str(k).strip()]
    if not kel_list:
        return JsonResponse({'results': [], 'has_more': False})

    # Rule: show Sub Jabatan only when selected Jabatan resolve to a single kel_jabatan_id
    kel_unique = sorted(set(kel_list))
    if len(kel_unique) != 1:
        return JsonResponse({'results': [], 'has_more': False})

    qs = BknSubJabatan.objects.all().filter(kel_jabatan_id=kel_unique[0])
    if q:
        qs = qs.filter(Q(nama__icontains=q) | Q(kel_jabatan_id__icontains=q))
    qs = qs.order_by('nama', 'id')

    offset = (page - 1) * page_size
    rows = list(qs.values('id', 'nama')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id')
        label = (r.get('nama') or '').strip()
        if val is None or not label:
            continue
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_jenis_organisasi_list(request):
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'
    only_opd = (request.GET.get('only_opd') or '1').strip()

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 2000)

    qs = MdJenisOrganisasi.objects.filter(deleted_at__isnull=True, jo_03=1)
    if only_opd in ('1', 'true', 'True', 'yes', 'on'):
        qs = qs.filter(is_opd_induk=True)
    if q:
        qs = qs.filter(jo_01__icontains=q)
    qs = qs.order_by('jo_02', 'jo_01', 'id')

    offset = (page - 1) * page_size
    rows = list(qs.values('id', 'jo_01')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id')
        label = (r.get('jo_01') or '').strip()
        if val is None or not label:
            continue
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_unit_kerja_list(request):
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 5000)

    qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True).exclude(status=0)
    # Unit Kerja = unit yang jenis organisasinya ditandai OPD (is_opd_induk) dan aktif
    # (legacy data bisa menyimpan penanda di type_opd atau id_unit)
    qs = qs.filter(
        Q(type_opd__deleted_at__isnull=True, type_opd__jo_03=1, type_opd__is_opd_induk=True)
        | Q(id_unit__deleted_at__isnull=True, id_unit__jo_03=1, id_unit__is_opd_induk=True)
    )
    if q:
        qs = qs.filter(nm_opd__icontains=q)
    qs = qs.order_by(Coalesce('no_urut', 999999), 'nm_opd')

    offset = (page - 1) * page_size
    rows = list(qs.values('id_opd', 'nm_opd', 'no_urut')[offset:offset + page_size + 1])
    has_more = len(rows) > page_size
    rows = rows[:page_size]

    results = []
    for r in rows:
        val = r.get('id_opd')
        label = (r.get('nm_opd') or '').strip()
        if val is None or not label:
            continue
        try:
            nu = r.get('no_urut')
            if nu is not None and str(nu).strip() != '':
                label = f"{int(nu):02d}. {label}"
        except Exception:
            pass
        results.append({'value': str(val), 'label': label})
    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def ajax_sub_unit_kerja_list(request):
    parent_id = (request.GET.get('parent_id') or '').strip()
    q = (request.GET.get('q') or '').strip()
    page = request.GET.get('page') or '1'
    page_size = request.GET.get('page_size') or '50'

    try:
        page = max(1, int(page))
    except Exception:
        page = 1
    try:
        page_size = int(page_size)
        if page_size <= 0:
            page_size = 50
    except Exception:
        page_size = 50
    page_size = min(page_size, 20000)

    if not parent_id.isdigit():
        return JsonResponse({'results': [], 'has_more': False})

    root_id = int(parent_id)

    base_filter = Q(deleted_at__isnull=True) & ~Q(status=0) & (
        Q(type_opd__deleted_at__isnull=True, type_opd__jo_03=1)
        | Q(id_unit__deleted_at__isnull=True, id_unit__jo_03=1)
    )

    # Fetch all descendants (child, sub-child, cucu, ...) using iterative BFS
    nodes = []
    frontier = [root_id]
    guard = 0
    seen = set([root_id])
    while frontier and guard < 200:
        guard += 1
        batch = frontier[:200]
        frontier = frontier[200:]
        qs_children = MsUnitOrganisasi.objects.filter(base_filter, parent_id_id__in=batch)
        rows = list(qs_children.values('id_opd', 'parent_id_id', 'nm_opd', 'no_urut'))
        if not rows:
            continue
        for r in rows:
            cid = r.get('id_opd')
            if cid is None or cid in seen:
                continue
            seen.add(cid)
            nodes.append(r)
            frontier.append(cid)
        if len(seen) > 10000:
            break

    # Build adjacency
    children_by_parent = {}
    for r in nodes:
        pid = r.get('parent_id_id')
        children_by_parent.setdefault(pid, []).append(r)

    root_row = None
    try:
        root_row = MsUnitOrganisasi.objects.filter(
            deleted_at__isnull=True,
            id_opd=root_id,
        ).exclude(status=0).values('id_opd', 'parent_id_id', 'nm_opd', 'no_urut').first()
    except Exception:
        root_row = None

    def _sort_key(row):
        nu = row.get('no_urut')
        try:
            nu = int(nu)
        except Exception:
            nu = 999999
        try:
            cid = int(row.get('id_opd') or 0)
        except Exception:
            cid = 0
        return (nu, cid)

    for pid, lst in children_by_parent.items():
        lst.sort(key=_sort_key)

    def _flatten(start_id):
        out = []
        guard = 0

        def walk(pid, depth):
            nonlocal guard
            kids = children_by_parent.get(pid) or []
            for child in kids:
                if guard > 20000:
                    return
                guard += 1
                cid = child.get('id_opd')
                if cid is None:
                    continue
                out.append((child, depth, cid))
                walk(cid, depth + 1)

        walk(start_id, 1)
        return out

    flat = []
    if root_row and (root_row.get('nm_opd') or '').strip():
        flat.append((root_row, 0, root_id))
    flat.extend(_flatten(root_id))

    # Optional search filter (keep hierarchy indent based on real depth)
    if q:
        ql = q.lower()
        flat = [item for item in flat if ql in ((item[0].get('nm_opd') or '').lower())]

    offset = (page - 1) * page_size
    sliced = flat[offset:offset + page_size + 1]
    has_more = len(sliced) > page_size
    sliced = sliced[:page_size]

    results = []
    for row, depth, _cid in sliced:
        val = row.get('id_opd')
        name = (row.get('nm_opd') or '').strip()
        if val is None or not name:
            continue
        try:
            d = int(depth) if depth is not None else 0
        except Exception:
            d = 0
        # Use NBSP so indentation is preserved in the dropdown UI (normal spaces collapse).
        indent = ('\u00A0' * 4) * max(0, d)
        branch = '└──── ' if d > 0 else ''
        results.append({'value': str(val), 'label': f"{indent}{branch}{name}"})

    return JsonResponse({'results': results, 'has_more': bool(has_more)})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'create')
def unit_organisasi_tabel_create(request):
    if request.method == 'POST':
        form = MsUnitOrganisasiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Unit Organisasi berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"unit-organisasi-form-success": {"message": "Unit Organisasi berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:unit_organisasi_tabel_list'),
                })
            return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/form.html', {'form': form, 'edit_mode': False})

    form = MsUnitOrganisasiForm()
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'edit')
def unit_organisasi_tabel_edit(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    if request.method == 'POST':
        form = MsUnitOrganisasiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Unit Organisasi berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"unit-organisasi-form-success": {"message": "Unit Organisasi berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:unit_organisasi_tabel_list'),
                })
            return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MsUnitOrganisasiForm(instance=obj)
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_tabel/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'delete')
def unit_organisasi_tabel_delete(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    obj.deleted_at = timezone.now()
    obj.save(update_fields=['deleted_at'])
    messages.success(request, 'Unit Organisasi berhasil dihapus')
    return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'create')
def unit_organisasi_struktural_create(request):
    if request.method == 'POST':
        form = MsUnitOrganisasiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Unit Organisasi berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"unit-organisasi-form-success": {"message": "Unit Organisasi berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:unit_organisasi_struktural_list'),
                })
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/form.html',
            {'form': form, 'edit_mode': False},
        )

    form = MsUnitOrganisasiForm()
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/form.html',
        {'form': form, 'edit_mode': False},
    )


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'edit')
def unit_organisasi_struktural_edit(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    is_htmx = bool(request.headers.get('HX-Request'))
    parent_unit = getattr(obj, 'parent_id', None)
    if request.method == 'POST':
        form = MsUnitOrganisasiEditModalForm(request.POST, instance=obj) if is_htmx else MsUnitOrganisasiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Unit Organisasi berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"unit-organisasi-form-success": {"message": "Unit Organisasi berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:unit_organisasi_struktural_list'),
                })
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/form.html',
            {'form': form, 'edit_mode': True, 'obj': obj},
        )

    form = MsUnitOrganisasiEditModalForm(instance=obj) if is_htmx else MsUnitOrganisasiForm(instance=obj)
    if is_htmx:
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/partials/_edit_unit_modal_content.html',
            {
                'form': form,
                'edit_mode': True,
                'obj': obj,
                'parent_unit': parent_unit,
                'parent_hierarchy_multiline': (parent_unit.get_hierarchy_string('\n') if parent_unit else ''),
            },
        )
    return render(
        request,
        'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/form.html',
        {'form': form, 'edit_mode': True, 'obj': obj},
    )


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'delete')
def unit_organisasi_struktural_delete(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    obj.deleted_at = timezone.now()
    obj.save(update_fields=['deleted_at'])
    messages.success(request, 'Unit Organisasi berhasil dihapus')
    return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')


@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'delete')
def unit_organisasi_delete(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    obj.deleted_at = timezone.now()
    obj.save(update_fields=['deleted_at'])
    messages.success(request, 'Unit Organisasi berhasil dihapus')
    return redirect('manajemen_relasi_organisasi:unit_organisasi_tabel_list')


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'view')
def unit_organisasi_hierarki_export(request):
    """Export khusus dengan format hierarki Dinas-Bidang-Seksi untuk Excel"""
    export_qs = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MsUnitOrganisasiHierarkiTable,
        filename_prefix='unit_organisasi_hierarki_export',
        title='Export Unit Organisasi (Format Hierarki)',
    )
    if export_resp is not None:
        return export_resp

    search_query = request.GET.get('search', '').strip()
    qs = export_qs
    if search_query:
        qs = qs.filter(
            Q(nm_opd__icontains=search_query)
            | Q(id_bkn__icontains=search_query)
            | Q(id_bkn_x__icontains=search_query)
        )
    qs = qs.order_by('id_opd')

    table = MsUnitOrganisasiHierarkiTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
        'export_mode': 'hierarki',
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_hierarki/partials/_table.html', context)
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_hierarki/list.html', context)


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'create')
def unit_organisasi_add_child(request, parent_id=None):
    """Tambah sub-unit/child untuk unit organisasi tertentu"""
    parent_unit = None
    if parent_id:
        try:
            parent_unit = MsUnitOrganisasi.objects.get(id_opd=parent_id, deleted_at__isnull=True)
        except MsUnitOrganisasi.DoesNotExist:
            messages.error(request, 'Unit induk tidak ditemukan')
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')
    
    if request.method == 'POST':
        post_data = request.POST.copy()
        # If parent_id is provided via URL, lock it.
        if parent_id and parent_unit:
            post_data['parent'] = str(parent_unit.id_opd)

        form = MsUnitOrganisasiChildModalForm(post_data)
        if form.is_valid():
            instance = form.save()
            
            messages.success(request, f'Sub-unit "{instance.nm_opd}" berhasil ditambahkan di bawah "{instance.parent_id.nm_opd}"')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"unit-organisasi-form-success": {"message": "Sub-unit berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_relasi_organisasi:unit_organisasi_struktural_list'),
                })
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

    form = MsUnitOrganisasiChildModalForm()
    if parent_unit:
        form.fields['parent'].initial = parent_unit

    context = {
        'form': form,
        'parent_unit': parent_unit,
        'parent_hierarchy_multiline': (parent_unit.get_hierarchy_string('\n') if parent_unit else ''),
        'edit_mode': False,
        'title': 'Tambah Sub Unit Organisasi',
        'breadcrumb_title': 'Tambah Sub Unit',
    }

    if request.headers.get('HX-Request'):
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/partials/_add_child_modal_content.html',
            context,
        )
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/add_child.html', context)


@ensure_csrf_cookie
@permission_required_403('manajemen_relasi_organisasi', 'ma_re_or_unit_organisasi', 'move')
def unit_organisasi_struktural_move_parent(request, pk):
    obj = get_object_or_404(MsUnitOrganisasi, pk=pk)
    current_parent = getattr(obj, 'parent_id', None)
    blocked_ids_csv = ''
    try:
        nodes = MsUnitOrganisasi.objects.filter(deleted_at__isnull=True).values('pk', 'parent_id_id')
        children_map = {}
        for n in nodes:
            pid = n.get('parent_id_id')
            if not pid:
                continue
            children_map.setdefault(pid, []).append(n.get('pk'))
        descendants = set()
        queue = [obj.pk]
        while queue:
            current = queue.pop(0)
            for cid in children_map.get(current, []) or []:
                if cid in descendants:
                    continue
                descendants.add(cid)
                queue.append(cid)
        blocked_ids = descendants | {obj.pk}
        blocked_ids_csv = ','.join([str(x) for x in blocked_ids])
    except Exception:
        blocked_ids_csv = str(obj.pk)

    if request.method == 'POST':
        form = MsUnitOrganisasiMoveParentForm(request.POST, instance=obj)
        if form.is_valid():
            new_parent = form.cleaned_data.get('parent')
            obj.parent_id = new_parent
            obj.save(update_fields=['parent_id'])
            messages.success(request, 'Unit Organisasi berhasil dipindahkan')
            if request.headers.get('HX-Request'):
                import json
                new_parent_id = getattr(new_parent, 'pk', None) if new_parent else None
                payload = {
                    'unit-organisasi-form-success': {
                        'message': 'Unit Organisasi berhasil dipindahkan',
                        'moved_id': str(obj.pk),
                        'new_parent_id': str(new_parent_id or ''),
                    }
                }
                return HttpResponse('', headers={'HX-Trigger': json.dumps(payload)})
            return redirect('manajemen_relasi_organisasi:unit_organisasi_struktural_list')

        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'unit-organisasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp

    form = MsUnitOrganisasiMoveParentForm(instance=obj)
    context = {
        'form': form,
        'obj': obj,
        'current_parent': current_parent,
        'parent_hierarchy_multiline': (current_parent.get_hierarchy_string('\n') if current_parent else ''),
        'blocked_ids_csv': blocked_ids_csv,
        'edit_mode': True,
    }
    if request.headers.get('HX-Request'):
        return render(
            request,
            'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/partials/_move_parent_modal_content.html',
            context,
        )
    return render(request, 'manajemen_relasi_organisasi/access/ma_re_or_unit_organisasi_struktural/list.html', context)
