from django.urls import path

from apps.manajemen import manajemen_analisis_jabatan as views

app_name = 'manajemen_analisis_jabatan'

urlpatterns = [
    path('satuan-kerja/', views.satuan_kerja_list, name='satuan_kerja_list'),
    path('satuan-kerja/create/', views.satuan_kerja_create, name='satuan_kerja_create'),
    path('satuan-kerja/<int:pk>/edit/', views.satuan_kerja_edit, name='satuan_kerja_edit'),
    path('satuan-kerja/<int:pk>/delete/', views.satuan_kerja_delete, name='satuan_kerja_delete'),

    path('syarat-jabatan/bakat/', views.sj_bakat_list, name='sj_bakat_list'),
    path('syarat-jabatan/bakat/create/', views.sj_bakat_create, name='sj_bakat_create'),
    path('syarat-jabatan/bakat/<int:pk>/edit/', views.sj_bakat_edit, name='sj_bakat_edit'),
    path('syarat-jabatan/bakat/<int:pk>/delete/', views.sj_bakat_delete, name='sj_bakat_delete'),

    path('syarat-jabatan/temperamen-kerja/', views.sj_temperamen_kerja_list, name='sj_temperamen_kerja_list'),
    path('syarat-jabatan/temperamen-kerja/create/', views.sj_temperamen_kerja_create, name='sj_temperamen_kerja_create'),
    path('syarat-jabatan/temperamen-kerja/<int:pk>/edit/', views.sj_temperamen_kerja_edit, name='sj_temperamen_kerja_edit'),
    path('syarat-jabatan/temperamen-kerja/<int:pk>/delete/', views.sj_temperamen_kerja_delete, name='sj_temperamen_kerja_delete'),

    path('syarat-jabatan/minat-kerja/', views.sj_minat_kerja_list, name='sj_minat_kerja_list'),
    path('syarat-jabatan/minat-kerja/create/', views.sj_minat_kerja_create, name='sj_minat_kerja_create'),
    path('syarat-jabatan/minat-kerja/<int:pk>/edit/', views.sj_minat_kerja_edit, name='sj_minat_kerja_edit'),
    path('syarat-jabatan/minat-kerja/<int:pk>/delete/', views.sj_minat_kerja_delete, name='sj_minat_kerja_delete'),

    path('syarat-jabatan/jabatan-data/', views.sj_jabatan_data_list, name='sj_jabatan_data_list'),
    path('syarat-jabatan/jabatan-data/create/', views.sj_jabatan_data_create, name='sj_jabatan_data_create'),
    path('syarat-jabatan/jabatan-data/<int:pk>/edit/', views.sj_jabatan_data_edit, name='sj_jabatan_data_edit'),
    path('syarat-jabatan/jabatan-data/<int:pk>/delete/', views.sj_jabatan_data_delete, name='sj_jabatan_data_delete'),

    path('syarat-jabatan/jabatan-orang/', views.sj_jabatan_orang_list, name='sj_jabatan_orang_list'),
    path('syarat-jabatan/jabatan-orang/create/', views.sj_jabatan_orang_create, name='sj_jabatan_orang_create'),
    path('syarat-jabatan/jabatan-orang/<int:pk>/edit/', views.sj_jabatan_orang_edit, name='sj_jabatan_orang_edit'),
    path('syarat-jabatan/jabatan-orang/<int:pk>/delete/', views.sj_jabatan_orang_delete, name='sj_jabatan_orang_delete'),

    path('syarat-jabatan/jabatan-benda/', views.sj_jabatan_benda_list, name='sj_jabatan_benda_list'),
    path('syarat-jabatan/jabatan-benda/create/', views.sj_jabatan_benda_create, name='sj_jabatan_benda_create'),
    path('syarat-jabatan/jabatan-benda/<int:pk>/edit/', views.sj_jabatan_benda_edit, name='sj_jabatan_benda_edit'),
    path('syarat-jabatan/jabatan-benda/<int:pk>/delete/', views.sj_jabatan_benda_delete, name='sj_jabatan_benda_delete'),

    path('syarat-jabatan/upaya-fisik/', views.sj_upaya_fisik_list, name='sj_upaya_fisik_list'),
    path('syarat-jabatan/upaya-fisik/create/', views.sj_upaya_fisik_create, name='sj_upaya_fisik_create'),
    path('syarat-jabatan/upaya-fisik/<int:pk>/edit/', views.sj_upaya_fisik_edit, name='sj_upaya_fisik_edit'),
    path('syarat-jabatan/upaya-fisik/<int:pk>/delete/', views.sj_upaya_fisik_delete, name='sj_upaya_fisik_delete'),

    path('syarat-jabatan/pengetahuan-kerja/', views.sj_pengetahuan_kerja_list, name='sj_pengetahuan_kerja_list'),
    path('syarat-jabatan/pengetahuan-kerja/create/', views.sj_pengetahuan_kerja_create, name='sj_pengetahuan_kerja_create'),
    path('syarat-jabatan/pengetahuan-kerja/<int:pk>/edit/', views.sj_pengetahuan_kerja_edit, name='sj_pengetahuan_kerja_edit'),
    path('syarat-jabatan/pengetahuan-kerja/<int:pk>/delete/', views.sj_pengetahuan_kerja_delete, name='sj_pengetahuan_kerja_delete'),

    path('syarat-jabatan/keterampilan-kerja/', views.sj_keterampilan_kerja_list, name='sj_keterampilan_kerja_list'),
    path('syarat-jabatan/keterampilan-kerja/create/', views.sj_keterampilan_kerja_create, name='sj_keterampilan_kerja_create'),
    path('syarat-jabatan/keterampilan-kerja/<int:pk>/edit/', views.sj_keterampilan_kerja_edit, name='sj_keterampilan_kerja_edit'),
    path('syarat-jabatan/keterampilan-kerja/<int:pk>/delete/', views.sj_keterampilan_kerja_delete, name='sj_keterampilan_kerja_delete'),

    path('syarat-jabatan/pelatihan-fungsional/', views.sj_pelatihan_fungsional_list, name='sj_pelatihan_fungsional_list'),
    path('syarat-jabatan/pelatihan-fungsional/create/', views.sj_pelatihan_fungsional_create, name='sj_pelatihan_fungsional_create'),
    path('syarat-jabatan/pelatihan-fungsional/<int:pk>/edit/', views.sj_pelatihan_fungsional_edit, name='sj_pelatihan_fungsional_edit'),
    path('syarat-jabatan/pelatihan-fungsional/<int:pk>/delete/', views.sj_pelatihan_fungsional_delete, name='sj_pelatihan_fungsional_delete'),

    path('syarat-jabatan/jenis-kelamin/', views.sj_jenis_kelamin_list, name='sj_jenis_kelamin_list'),
    path('syarat-jabatan/jenis-kelamin/create/', views.sj_jenis_kelamin_create, name='sj_jenis_kelamin_create'),
    path('syarat-jabatan/jenis-kelamin/<int:pk>/edit/', views.sj_jenis_kelamin_edit, name='sj_jenis_kelamin_edit'),
    path('syarat-jabatan/jenis-kelamin/<int:pk>/delete/', views.sj_jenis_kelamin_delete, name='sj_jenis_kelamin_delete'),

    path('syarat-jabatan/pelatihan-teknis/', views.sj_pelatihan_teknis_list, name='sj_pelatihan_teknis_list'),
    path('syarat-jabatan/pelatihan-teknis/create/', views.sj_pelatihan_teknis_create, name='sj_pelatihan_teknis_create'),
    path('syarat-jabatan/pelatihan-teknis/<int:pk>/edit/', views.sj_pelatihan_teknis_edit, name='sj_pelatihan_teknis_edit'),
    path('syarat-jabatan/pelatihan-teknis/<int:pk>/delete/', views.sj_pelatihan_teknis_delete, name='sj_pelatihan_teknis_delete'),
]
