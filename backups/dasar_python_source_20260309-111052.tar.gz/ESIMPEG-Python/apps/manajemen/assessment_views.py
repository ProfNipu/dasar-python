from django.shortcuts import render, get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie
from django.db.models import Q
from django_tables2 import RequestConfig

from apps.manajemen.decorators import permission_required_403
from apps.pegawai.models import MrAssessment
from apps.manajemen.tables_kepegawaian import MrAssessmentTable


@ensure_csrf_cookie
@permission_required_403('assessment', 'Mr_assessment', 'view')
def mr_assessment_list(request):
    search_query = request.GET.get('search', '').strip()

    qs = MrAssessment.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_pegawai__B_02B__icontains=search_query)
            | Q(id_pegawai__B_02__icontains=search_query)
            | Q(id_pegawai__B_03__icontains=search_query)
            | Q(MRA_02__icontains=search_query)
        )

    qs = qs.select_related('id_pegawai').order_by('-MRA_01', '-id')

    table = MrAssessmentTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'assessment/access/ma_as_Mr_assessment/partials/_table.html', context)
    return render(request, 'assessment/access/ma_as_Mr_assessment/list.html', context)


@permission_required_403('assessment', 'Mr_assessment', 'view')
def mr_assessment_detail(request, pk):
    obj = get_object_or_404(MrAssessment, id=pk, deleted_at__isnull=True)
    context = {
        'obj': obj,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'assessment/access/ma_as_Mr_assessment/partials/_form.html', context)
    return render(request, 'assessment/access/ma_as_Mr_assessment/form.html', context)
