from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.db.models import Q
from django.core.exceptions import PermissionDenied
from django_tables2 import RequestConfig

from apps.manajemen.decorators import permission_required_403
from apps.manajemen.helpers import check_permission
from apps.manajemen.models import UserTableSelection
from apps.master_data.models import BknLokasiKerja, BknAlasanHukuman, BknJenisHukuman, BknTingkatHukdis, BknNomorppHukdis, BknJabatanFungsional, BknJenisKenaikanPangkat, BknJenisDiklat, BknDaftarKppn, BknJenisPenghargaan, BknJenisMutasi, BknJenisPenugasan, BknSubJabatan
from apps.manajemen.forms_master_data import BknLokasiKerjaForm, BknAlasanHukumanForm, BknJenisHukumanForm, BknTingkatHukdisForm, BknNomorppHukdisForm, BknJabatanFungsionalForm, BknJenisKenaikanPangkatForm, BknJenisDiklatForm, BknDaftarKppnForm, BknJenisPenghargaanForm, BknJenisMutasiForm, BknJenisPenugasanForm, BknSubJabatanForm
from apps.manajemen.tables_master_data import BknLokasiKerjaTable, BknAlasanHukumanTable, BknJenisHukumanTable, BknTingkatHukdisTable, BknNomorppHukdisTable, BknJabatanFungsionalTable, BknJenisKenaikanPangkatTable, BknJenisDiklatTable, BknDaftarKppnTable, BknJenisPenghargaanTable, BknJenisMutasiTable, BknJenisPenugasanTable, BknSubJabatanTable
from apps.manajemen.manajemen_data import handle_datatable_export


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_lokasi_kerja', 'view')
def bkn_lokasi_kerja_list(request):
    export_qs = BknLokasiKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknLokasiKerjaTable,
        filename_prefix='bkn_lokasi_kerja_export',
        title='BKN Lokasi Kerja Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_lokasi_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_lokasi_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_lokasi_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list')

            now = timezone.now()
            qs = BknLokasiKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_lokasi_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data lokasi kerja berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknLokasiKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(nama_lokasi__icontains=search_query)
            | Q(cepat_kode__icontains=search_query)
            | Q(kanreg_id__icontains=search_query)
            | Q(jenis_lokasi__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = BknLokasiKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_lokasi_kerja', 'create')
def bkn_lokasi_kerja_create(request):
    if request.method == 'POST':
        form = BknLokasiKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Lokasi Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-lokasi-kerja-form-success": {"message": "BKN Lokasi Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-lokasi-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/form.html', {'form': form, 'edit_mode': False})

    form = BknLokasiKerjaForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_lokasi_kerja', 'edit')
def bkn_lokasi_kerja_edit(request, pk):
    obj = get_object_or_404(BknLokasiKerja, id=pk)
    if request.method == 'POST':
        form = BknLokasiKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Lokasi Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-lokasi-kerja-form-success": {"message": "BKN Lokasi Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-lokasi-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknLokasiKerjaForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_lokasi_kerja', 'delete')
def bkn_lokasi_kerja_delete(request, pk):
    obj = get_object_or_404(BknLokasiKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Lokasi Kerja berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_lokasi_kerja_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_lokasi_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_alasan_hukuman', 'view')
def bkn_alasan_hukuman_list(request):
    export_qs = BknAlasanHukuman.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknAlasanHukumanTable,
        filename_prefix='bkn_alasan_hukuman_export',
        title='BKN Alasan Hukuman Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_alasan_hukuman_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_alasan_hukuman_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_alasan_hukuman_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_referensi_data_bkn', 'bkn_alasan_hukuman', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list')

            now = timezone.now()
            qs = BknAlasanHukuman.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_alasan_hukuman_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data alasan hukuman berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknAlasanHukuman.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_bkn__icontains=search_query)
            | Q(nama__icontains=search_query)
            | Q(keterangan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = BknAlasanHukumanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_alasan_hukuman', 'create')
def bkn_alasan_hukuman_create(request):
    if request.method == 'POST':
        form = BknAlasanHukumanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Alasan Hukuman berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-alasan-hukuman-form-success": {"message": "BKN Alasan Hukuman berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-alasan-hukuman-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/form.html', {'form': form, 'edit_mode': False})

    form = BknAlasanHukumanForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_alasan_hukuman', 'edit')
def bkn_alasan_hukuman_edit(request, pk):
    obj = get_object_or_404(BknAlasanHukuman, id=pk)
    if request.method == 'POST':
        form = BknAlasanHukumanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Alasan Hukuman berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-alasan-hukuman-form-success": {"message": "BKN Alasan Hukuman berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-alasan-hukuman-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknAlasanHukumanForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_alasan_hukuman', 'delete')
def bkn_alasan_hukuman_delete(request, pk):
    obj = get_object_or_404(BknAlasanHukuman, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Alasan Hukuman berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_alasan_hukuman_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_alasan_hukuman/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_hukuman', 'view')
def bkn_jenis_hukuman_list(request):
    export_qs = BknJenisHukuman.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisHukumanTable,
        filename_prefix='bkn_jenis_hukuman_export',
        title='BKN Jenis Hukuman Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_hukuman_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_hukuman_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_hukuman_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list')

            now = timezone.now()
            qs = BknJenisHukuman.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_hukuman_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis hukuman berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisHukuman.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_bkn__icontains=search_query)
            | Q(nama__icontains=search_query)
            | Q(jenis_tingkat_hukuman__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = BknJenisHukumanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_hukuman', 'create')
def bkn_jenis_hukuman_create(request):
    if request.method == 'POST':
        form = BknJenisHukumanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Hukuman berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-hukuman-form-success": {"message": "BKN Jenis Hukuman berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-hukuman-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisHukumanForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_hukuman', 'edit')
def bkn_jenis_hukuman_edit(request, pk):
    obj = get_object_or_404(BknJenisHukuman, id=pk)
    if request.method == 'POST':
        form = BknJenisHukumanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Hukuman berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-hukuman-form-success": {"message": "BKN Jenis Hukuman berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-hukuman-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisHukumanForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_hukuman', 'delete')
def bkn_jenis_hukuman_delete(request, pk):
    obj = get_object_or_404(BknJenisHukuman, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Jenis Hukuman berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_hukuman_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_hukuman/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_tingkat_hukdis', 'view')
def bkn_tingkat_hukdis_list(request):
    export_qs = BknTingkatHukdis.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknTingkatHukdisTable,
        filename_prefix='bkn_tingkat_hukdis_export',
        title='BKN Tingkat Hukdis Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_tingkat_hukdis_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_tingkat_hukdis_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_tingkat_hukdis_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list')

            now = timezone.now()
            qs = BknTingkatHukdis.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_tingkat_hukdis_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data tingkat hukuman disiplin berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknTingkatHukdis.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(id_bkn__icontains=search_query) | Q(nama__icontains=search_query))
    qs = qs.order_by('id')

    table = BknTingkatHukdisTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_tingkat_hukdis', 'create')
def bkn_tingkat_hukdis_create(request):
    if request.method == 'POST':
        form = BknTingkatHukdisForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Tingkat Hukdis berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-tingkat-hukdis-form-success": {"message": "BKN Tingkat Hukdis berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-tingkat-hukdis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/form.html', {'form': form, 'edit_mode': False})

    form = BknTingkatHukdisForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_tingkat_hukdis', 'edit')
def bkn_tingkat_hukdis_edit(request, pk):
    obj = get_object_or_404(BknTingkatHukdis, id=pk)
    if request.method == 'POST':
        form = BknTingkatHukdisForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Tingkat Hukdis berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-tingkat-hukdis-form-success": {"message": "BKN Tingkat Hukdis berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-tingkat-hukdis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknTingkatHukdisForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_tingkat_hukdis', 'delete')
def bkn_tingkat_hukdis_delete(request, pk):
    obj = get_object_or_404(BknTingkatHukdis, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Tingkat Hukdis berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_tingkat_hukdis_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_tingkat_hukdis/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_nomorpp_hukdis', 'view')
def bkn_nomorpp_hukdis_list(request):
    export_qs = BknNomorppHukdis.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknNomorppHukdisTable,
        filename_prefix='bkn_nomorpp_hukdis_export',
        title='BKN Nomor PP Hukdis Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_nomorpp_hukdis_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_nomorpp_hukdis_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_nomorpp_hukdis_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list')

            now = timezone.now()
            qs = BknNomorppHukdis.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_nomorpp_hukdis_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data nomor PP hukuman disiplin berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknNomorppHukdis.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(id_bkn__icontains=search_query) | Q(nomor__icontains=search_query))
    qs = qs.order_by('id')

    table = BknNomorppHukdisTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_nomorpp_hukdis', 'create')
def bkn_nomorpp_hukdis_create(request):
    if request.method == 'POST':
        form = BknNomorppHukdisForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Nomor PP Hukdis berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-nomorpp-hukdis-form-success": {"message": "BKN Nomor PP Hukdis berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-nomorpp-hukdis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/form.html', {'form': form, 'edit_mode': False})

    form = BknNomorppHukdisForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_nomorpp_hukdis', 'edit')
def bkn_nomorpp_hukdis_edit(request, pk):
    obj = get_object_or_404(BknNomorppHukdis, id=pk)
    if request.method == 'POST':
        form = BknNomorppHukdisForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Nomor PP Hukdis berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-nomorpp-hukdis-form-success": {"message": "BKN Nomor PP Hukdis berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-nomorpp-hukdis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknNomorppHukdisForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_nomorpp_hukdis', 'delete')
def bkn_nomorpp_hukdis_delete(request, pk):
    obj = get_object_or_404(BknNomorppHukdis, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Nomor PP Hukdis berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_nomorpp_hukdis_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_nomorpp_hukdis/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jabatan_fungsional', 'view')
def bkn_jabatan_fungsional_list(request):
    export_qs = BknJabatanFungsional.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJabatanFungsionalTable,
        filename_prefix='bkn_jabatan_fungsional_export',
        title='BKN Jabatan Fungsional Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jabatan_fungsional_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jabatan_fungsional_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jabatan_fungsional_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list')

            now = timezone.now()
            qs = BknJabatanFungsional.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jabatan_fungsional_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jabatan fungsional berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJabatanFungsional.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(id_bkn__icontains=search_query)
            | Q(nama__icontains=search_query)
            | Q(cepat_kode__icontains=search_query)
            | Q(jenjang__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = BknJabatanFungsionalTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jabatan_fungsional', 'create')
def bkn_jabatan_fungsional_create(request):
    if request.method == 'POST':
        form = BknJabatanFungsionalForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jabatan Fungsional berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jabatan-fungsional-form-success": {"message": "BKN Jabatan Fungsional berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jabatan-fungsional-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/form.html', {'form': form, 'edit_mode': False})

    form = BknJabatanFungsionalForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jabatan_fungsional', 'edit')
def bkn_jabatan_fungsional_edit(request, pk):
    obj = get_object_or_404(BknJabatanFungsional, id=pk)
    if request.method == 'POST':
        form = BknJabatanFungsionalForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jabatan Fungsional berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jabatan-fungsional-form-success": {"message": "BKN Jabatan Fungsional berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jabatan-fungsional-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJabatanFungsionalForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jabatan_fungsional', 'delete')
def bkn_jabatan_fungsional_delete(request, pk):
    obj = get_object_or_404(BknJabatanFungsional, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Jabatan Fungsional berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jabatan_fungsional_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jabatan_fungsional/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_kenaikan_pangkat', 'view')
def bkn_jenis_kenaikan_pangkat_list(request):
    export_qs = BknJenisKenaikanPangkat.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisKenaikanPangkatTable,
        filename_prefix='bkn_jenis_kenaikan_pangkat_export',
        title='BKN Jenis Kenaikan Pangkat Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_kenaikan_pangkat_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_kenaikan_pangkat_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_kenaikan_pangkat_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list')

            now = timezone.now()
            qs = BknJenisKenaikanPangkat.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_kenaikan_pangkat_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis kenaikan pangkat berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisKenaikanPangkat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama__icontains=search_query))
    qs = qs.order_by('id')

    table = BknJenisKenaikanPangkatTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_kenaikan_pangkat', 'create')
def bkn_jenis_kenaikan_pangkat_create(request):
    if request.method == 'POST':
        form = BknJenisKenaikanPangkatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Kenaikan Pangkat berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-kenaikan-pangkat-form-success": {"message": "BKN Jenis Kenaikan Pangkat berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-kenaikan-pangkat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisKenaikanPangkatForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_kenaikan_pangkat', 'edit')
def bkn_jenis_kenaikan_pangkat_edit(request, pk):
    obj = get_object_or_404(BknJenisKenaikanPangkat, id=pk)
    if request.method == 'POST':
        form = BknJenisKenaikanPangkatForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Kenaikan Pangkat berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-kenaikan-pangkat-form-success": {"message": "BKN Jenis Kenaikan Pangkat berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-kenaikan-pangkat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisKenaikanPangkatForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_kenaikan_pangkat', 'delete')
def bkn_jenis_kenaikan_pangkat_delete(request, pk):
    obj = get_object_or_404(BknJenisKenaikanPangkat, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Jenis Kenaikan Pangkat berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_kenaikan_pangkat_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_kenaikan_pangkat/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_diklat', 'view')
def bkn_jenis_diklat_list(request):
    export_qs = BknJenisDiklat.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisDiklatTable,
        filename_prefix='bkn_jenis_diklat_export',
        title='BKN Jenis Diklat Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_diklat_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_diklat_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_diklat_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_diklat_list')

            now = timezone.now()
            qs = BknJenisDiklat.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_diklat_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis diklat berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_diklat_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisDiklat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(jenis_diklat__icontains=search_query) | Q(jenis_kursus_sertipikat__icontains=search_query))
    qs = qs.order_by('id')

    table = BknJenisDiklatTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_diklat', 'create')
def bkn_jenis_diklat_create(request):
    if request.method == 'POST':
        form = BknJenisDiklatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Diklat berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-diklat-form-success": {"message": "BKN Jenis Diklat berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_diklat_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_diklat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-diklat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisDiklatForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_diklat', 'edit')
def bkn_jenis_diklat_edit(request, pk):
    obj = get_object_or_404(BknJenisDiklat, id=pk)
    if request.method == 'POST':
        form = BknJenisDiklatForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Diklat berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-diklat-form-success": {"message": "BKN Jenis Diklat berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_diklat_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_diklat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-diklat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisDiklatForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_diklat', 'delete')
def bkn_jenis_diklat_delete(request, pk):
    obj = get_object_or_404(BknJenisDiklat, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Jenis Diklat berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_diklat_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_diklat/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_daftar_kppn', 'view')
def bkn_daftar_kppn_list(request):
    export_qs = BknDaftarKppn.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknDaftarKppnTable,
        filename_prefix='bkn_daftar_kppn_export',
        title='BKN Daftar KPPN Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_daftar_kppn_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_daftar_kppn_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_daftar_kppn_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_referensi_data_bkn', 'bkn_daftar_kppn', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_daftar_kppn_list')

            now = timezone.now()
            qs = BknDaftarKppn.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_daftar_kppn_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data daftar KPPN berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_daftar_kppn_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknDaftarKppn.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(id_bkn__icontains=search_query) | Q(nama_kppn__icontains=search_query))
    qs = qs.order_by('id')

    table = BknDaftarKppnTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_daftar_kppn', 'create')
def bkn_daftar_kppn_create(request):
    if request.method == 'POST':
        form = BknDaftarKppnForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Daftar KPPN berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-daftar-kppn-form-success": {"message": "BKN Daftar KPPN berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_daftar_kppn_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_daftar_kppn_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-daftar-kppn-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/form.html', {'form': form, 'edit_mode': False})

    form = BknDaftarKppnForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_daftar_kppn', 'edit')
def bkn_daftar_kppn_edit(request, pk):
    obj = get_object_or_404(BknDaftarKppn, id=pk)
    if request.method == 'POST':
        form = BknDaftarKppnForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Daftar KPPN berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-daftar-kppn-form-success": {"message": "BKN Daftar KPPN berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_daftar_kppn_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_daftar_kppn_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-daftar-kppn-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknDaftarKppnForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_daftar_kppn', 'delete')
def bkn_daftar_kppn_delete(request, pk):
    obj = get_object_or_404(BknDaftarKppn, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Daftar KPPN berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_daftar_kppn_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_daftar_kppn/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penghargaan', 'view')
def bkn_jenis_penghargaan_list(request):
    export_qs = BknJenisPenghargaan.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisPenghargaanTable,
        filename_prefix='bkn_jenis_penghargaan_export',
        title='BKN Jenis Penghargaan Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_penghargaan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_penghargaan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_penghargaan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list')

            now = timezone.now()
            qs = BknJenisPenghargaan.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_penghargaan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis penghargaan berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisPenghargaan.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(nama__icontains=search_query))
    qs = qs.order_by('id')

    table = BknJenisPenghargaanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penghargaan', 'create')
def bkn_jenis_penghargaan_create(request):
    if request.method == 'POST':
        form = BknJenisPenghargaanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Penghargaan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-penghargaan-form-success": {"message": "BKN Jenis Penghargaan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-penghargaan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisPenghargaanForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penghargaan', 'edit')
def bkn_jenis_penghargaan_edit(request, pk):
    obj = get_object_or_404(BknJenisPenghargaan, id=pk)
    if request.method == 'POST':
        form = BknJenisPenghargaanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Penghargaan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-penghargaan-form-success": {"message": "BKN Jenis Penghargaan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-penghargaan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisPenghargaanForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penghargaan', 'delete')
def bkn_jenis_penghargaan_delete(request, pk):
    obj = get_object_or_404(BknJenisPenghargaan, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'BKN Jenis Penghargaan berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_penghargaan_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penghargaan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_mutasi', 'view')
def bkn_jenis_mutasi_list(request):
    export_qs = BknJenisMutasi.objects.all()
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisMutasiTable,
        filename_prefix='bkn_jenis_mutasi_export',
        title='BKN Jenis Mutasi Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_mutasi_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_mutasi_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_mutasi_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_referensi_data_bkn', 'bkn_jenis_mutasi', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list')

            qs = BknJenisMutasi.objects.filter(id__in=selected_ids)
            affected = qs.count()
            qs.delete()
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_mutasi_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis mutasi berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisMutasi.objects.all()
    if search_query:
        qs = qs.filter(Q(id_bkn__icontains=search_query) | Q(jm_01__icontains=search_query))
    qs = qs.order_by('id')

    table = BknJenisMutasiTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_mutasi', 'create')
def bkn_jenis_mutasi_create(request):
    if request.method == 'POST':
        form = BknJenisMutasiForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Mutasi berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-mutasi-form-success": {"message": "BKN Jenis Mutasi berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-mutasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisMutasiForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_mutasi', 'edit')
def bkn_jenis_mutasi_edit(request, pk):
    obj = get_object_or_404(BknJenisMutasi, id=pk)
    if request.method == 'POST':
        form = BknJenisMutasiForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Mutasi berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-mutasi-form-success": {"message": "BKN Jenis Mutasi berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-mutasi-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisMutasiForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_mutasi', 'delete')
def bkn_jenis_mutasi_delete(request, pk):
    obj = get_object_or_404(BknJenisMutasi, id=pk)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'BKN Jenis Mutasi berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_mutasi_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_mutasi/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penugasan', 'view')
def bkn_jenis_penugasan_list(request):
    export_qs = BknJenisPenugasan.objects.all()
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknJenisPenugasanTable,
        filename_prefix='bkn_jenis_penugasan_export',
        title='BKN Jenis Penugasan Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_penugasan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_jenis_penugasan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_jenis_penugasan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_referensi_data_bkn', 'bkn_jenis_penugasan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list')

            qs = BknJenisPenugasan.objects.filter(id__in=selected_ids)
            affected = qs.count()
            qs.delete()
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_jenis_penugasan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis penugasan berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknJenisPenugasan.objects.all()
    if search_query:
        qs = qs.filter(Q(id_bkn__icontains=search_query) | Q(jp_01__icontains=search_query))
    qs = qs.order_by('id')

    table = BknJenisPenugasanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penugasan', 'create')
def bkn_jenis_penugasan_create(request):
    if request.method == 'POST':
        form = BknJenisPenugasanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Penugasan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-penugasan-form-success": {"message": "BKN Jenis Penugasan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-penugasan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/form.html', {'form': form, 'edit_mode': False})

    form = BknJenisPenugasanForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penugasan', 'edit')
def bkn_jenis_penugasan_edit(request, pk):
    obj = get_object_or_404(BknJenisPenugasan, id=pk)
    if request.method == 'POST':
        form = BknJenisPenugasanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Jenis Penugasan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-jenis-penugasan-form-success": {"message": "BKN Jenis Penugasan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-jenis-penugasan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknJenisPenugasanForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_jenis_penugasan', 'delete')
def bkn_jenis_penugasan_delete(request, pk):
    obj = get_object_or_404(BknJenisPenugasan, id=pk)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'BKN Jenis Penugasan berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_jenis_penugasan_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_jenis_penugasan/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_referensi_data_bkn', 'bkn_sub_jabatan', 'view')
def bkn_sub_jabatan_list(request):
    export_qs = BknSubJabatan.objects.all()
    export_resp = handle_datatable_export(
        request,
        export_qs,
        BknSubJabatanTable,
        filename_prefix='bkn_sub_jabatan_export',
        title='BKN Sub Jabatan Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_re_bkn_sub_jabatan_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_re_bkn_sub_jabatan_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_re_bkn_sub_jabatan_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_referensi_data_bkn', 'bkn_sub_jabatan', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_referensi_data_bkn:bkn_sub_jabatan_list')

            qs = BknSubJabatan.objects.filter(id__in=selected_ids)
            affected = qs.count()
            qs.delete()
            UserTableSelection.objects.filter(user=request.user, page_key='ma_re_bkn_sub_jabatan_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data sub jabatan berhasil dihapus')
            return redirect('manajemen_referensi_data_bkn:bkn_sub_jabatan_list')

    search_query = request.GET.get('search', '').strip()
    qs = BknSubJabatan.objects.all()
    if search_query:
        qs = qs.filter(Q(kel_jabatan_id__icontains=search_query) | Q(nama__icontains=search_query))
    qs = qs.order_by('id')

    table = BknSubJabatanTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/partials/_table.html', context)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/list.html', context)


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_sub_jabatan', 'create')
def bkn_sub_jabatan_create(request):
    if request.method == 'POST':
        form = BknSubJabatanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Sub Jabatan berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-sub-jabatan-form-success": {"message": "BKN Sub Jabatan berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_sub_jabatan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_sub_jabatan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-sub-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/form.html', {'form': form, 'edit_mode': False})

    form = BknSubJabatanForm()
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_sub_jabatan', 'edit')
def bkn_sub_jabatan_edit(request, pk):
    obj = get_object_or_404(BknSubJabatan, id=pk)
    if request.method == 'POST':
        form = BknSubJabatanForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'BKN Sub Jabatan berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"bkn-sub-jabatan-form-success": {"message": "BKN Sub Jabatan berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_referensi_data_bkn:bkn_sub_jabatan_list'),
                })
            return redirect('manajemen_referensi_data_bkn:bkn_sub_jabatan_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'bkn-sub-jabatan-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = BknSubJabatanForm(instance=obj)
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_referensi_data_bkn', 'bkn_sub_jabatan', 'delete')
def bkn_sub_jabatan_delete(request, pk):
    obj = get_object_or_404(BknSubJabatan, id=pk)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'BKN Sub Jabatan berhasil dihapus')
        return redirect('manajemen_referensi_data_bkn:bkn_sub_jabatan_list')
    return render(request, 'manajemen_referensi_data_bkn/access/Ma_re_Bkn_sub_jabatan/delete.html', {'obj': obj})
