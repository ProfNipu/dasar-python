from django.views.decorators.csrf import ensure_csrf_cookie
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse
from django.utils import timezone
from django.db.models import Q
from django.core.exceptions import PermissionDenied
from django_tables2 import RequestConfig

from django.shortcuts import render, redirect, get_object_or_404

from apps.manajemen.decorators import permission_required_403
from apps.manajemen.helpers import check_permission
from apps.manajemen.models import UserTableSelection
from apps.master_data.models import (
    MaAnSatuanKerja,
    MaAnSjBakat,
    MaAnSjTemperamenKerja,
    MaAnSjMinatKerja,
    MaAnSjJabatanData,
    MaAnSjJabatanOrang,
    MaAnSjJabatanBenda,
    MaAnSjUpayaFisik,
    MaAnSjPengetahuanKerja,
    MaAnSjKeterampilanKerja,
    MaAnSjPelatihanFungsional,
    MaAnSjJenisKelamin,
    MaAnSjPelatihanTeknis,
)
from apps.manajemen.forms_analisis_jabatan import (
    MaAnSatuanKerjaForm,
    MaAnSjBakatForm,
    MaAnSjTemperamenKerjaForm,
    MaAnSjMinatKerjaForm,
    MaAnSjJabatanDataForm,
    MaAnSjJabatanOrangForm,
    MaAnSjJabatanBendaForm,
    MaAnSjUpayaFisikForm,
    MaAnSjPengetahuanKerjaForm,
    MaAnSjKeterampilanKerjaForm,
    MaAnSjPelatihanFungsionalForm,
    MaAnSjJenisKelaminForm,
    MaAnSjPelatihanTeknisForm,
)
from apps.manajemen.tables_analisis_jabatan import (
    MaAnSatuanKerjaTable,
    MaAnSjBakatTable,
    MaAnSjTemperamenKerjaTable,
    MaAnSjMinatKerjaTable,
    MaAnSjJabatanDataTable,
    MaAnSjJabatanOrangTable,
    MaAnSjJabatanBendaTable,
    MaAnSjUpayaFisikTable,
    MaAnSjPengetahuanKerjaTable,
    MaAnSjKeterampilanKerjaTable,
    MaAnSjPelatihanFungsionalTable,
    MaAnSjJenisKelaminTable,
    MaAnSjPelatihanTeknisTable,
)
from apps.manajemen.manajemen_data import handle_datatable_export


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_satuan_kerja', 'view')
def satuan_kerja_list(request):
    export_qs = MaAnSatuanKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSatuanKerjaTable,
        filename_prefix='ma_an_satuan_kerja_export',
        title='Satuan Kerja (Anjab) Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_satuan_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_satuan_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_satuan_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_analisis_jabatan', 'ma_an_satuan_kerja', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:satuan_kerja_list')

            now = timezone.now()
            qs = MaAnSatuanKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_satuan_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data satuan kerja berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:satuan_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSatuanKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(Q(satuan_kerja__icontains=search_query))
    qs = qs.order_by('id')

    table = MaAnSatuanKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_satuan_kerja', 'create')
def satuan_kerja_create(request):
    if request.method == 'POST':
        form = MaAnSatuanKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Satuan Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-satuan-kerja-form-success": {"message": "Satuan Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:satuan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:satuan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-satuan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSatuanKerjaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_satuan_kerja', 'edit')
def satuan_kerja_edit(request, pk):
    obj = get_object_or_404(MaAnSatuanKerja, id=pk)
    if request.method == 'POST':
        form = MaAnSatuanKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Satuan Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-satuan-kerja-form-success": {"message": "Satuan Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:satuan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:satuan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-satuan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSatuanKerjaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_satuan_kerja', 'delete')
def satuan_kerja_delete(request, pk):
    obj = get_object_or_404(MaAnSatuanKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Satuan Kerja berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:satuan_kerja_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_satuan_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_bakat', 'view')
def sj_bakat_list(request):
    export_qs = MaAnSjBakat.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjBakatTable,
        filename_prefix='ma_an_sj_bakat_export',
        title='Syarat Jabatan - Bakat Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_bakat_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_bakat_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_bakat_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_analisis_jabatan', 'ma_an_sj_bakat', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_bakat_list')

            now = timezone.now()
            qs = MaAnSjBakat.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_bakat_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data bakat berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_bakat_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjBakat.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_bakat__icontains=search_query)
            | Q(nama_bakat__icontains=search_query)
            | Q(deskripsi_bakat__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjBakatTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_bakat', 'create')
def sj_bakat_create(request):
    if request.method == 'POST':
        form = MaAnSjBakatForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Bakat berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-bakat-form-success": {"message": "Bakat berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_bakat_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_bakat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-bakat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjBakatForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_bakat', 'edit')
def sj_bakat_edit(request, pk):
    obj = get_object_or_404(MaAnSjBakat, id=pk)
    if request.method == 'POST':
        form = MaAnSjBakatForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Bakat berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-bakat-form-success": {"message": "Bakat berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_bakat_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_bakat_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-bakat-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjBakatForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_bakat', 'delete')
def sj_bakat_delete(request, pk):
    obj = get_object_or_404(MaAnSjBakat, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Bakat berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_bakat_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_bakat/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_temperamen_kerja', 'view')
def sj_temperamen_kerja_list(request):
    export_qs = MaAnSjTemperamenKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjTemperamenKerjaTable,
        filename_prefix='ma_an_sj_temperamen_kerja_export',
        title='Syarat Jabatan - Temperamen Kerja Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_temperamen_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_temperamen_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_temperamen_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_temperamen_kerja_list')

            now = timezone.now()
            qs = MaAnSjTemperamenKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_temperamen_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data temperamen kerja berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_temperamen_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjTemperamenKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_temperamen__icontains=search_query)
            | Q(nama_temperamen__icontains=search_query)
            | Q(deskripsi_temperamen__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjTemperamenKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_temperamen_kerja', 'create')
def sj_temperamen_kerja_create(request):
    if request.method == 'POST':
        form = MaAnSjTemperamenKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Temperamen Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-temperamen-kerja-form-success": {"message": "Temperamen Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_temperamen_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_temperamen_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-temperamen-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjTemperamenKerjaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_temperamen_kerja', 'edit')
def sj_temperamen_kerja_edit(request, pk):
    obj = get_object_or_404(MaAnSjTemperamenKerja, id=pk)
    if request.method == 'POST':
        form = MaAnSjTemperamenKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Temperamen Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-temperamen-kerja-form-success": {"message": "Temperamen Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_temperamen_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_temperamen_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-temperamen-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjTemperamenKerjaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_temperamen_kerja', 'delete')
def sj_temperamen_kerja_delete(request, pk):
    obj = get_object_or_404(MaAnSjTemperamenKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Temperamen Kerja berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_temperamen_kerja_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_temperamen_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_minat_kerja', 'view')
def sj_minat_kerja_list(request):
    export_qs = MaAnSjMinatKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjMinatKerjaTable,
        filename_prefix='ma_an_sj_minat_kerja_export',
        title='Syarat Jabatan - Minat Kerja Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_minat_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_minat_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_minat_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_minat_kerja_list')

            now = timezone.now()
            qs = MaAnSjMinatKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_minat_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data minat kerja berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_minat_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjMinatKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_minat__icontains=search_query)
            | Q(nama_minat__icontains=search_query)
            | Q(deskripsi_minat__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjMinatKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }

    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_minat_kerja', 'create')
def sj_minat_kerja_create(request):
    if request.method == 'POST':
        form = MaAnSjMinatKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Minat Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-minat-kerja-form-success": {"message": "Minat Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_minat_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_minat_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-minat-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjMinatKerjaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_minat_kerja', 'edit')
def sj_minat_kerja_edit(request, pk):
    obj = get_object_or_404(MaAnSjMinatKerja, id=pk)
    if request.method == 'POST':
        form = MaAnSjMinatKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Minat Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-minat-kerja-form-success": {"message": "Minat Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_minat_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_minat_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-minat-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjMinatKerjaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_minat_kerja', 'delete')
def sj_minat_kerja_delete(request, pk):
    obj = get_object_or_404(MaAnSjMinatKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Minat Kerja berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_minat_kerja_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_minat_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_data', 'view')
def sj_jabatan_data_list(request):
    export_qs = MaAnSjJabatanData.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjJabatanDataTable,
        filename_prefix='ma_an_sj_jabatan_data_export',
        title='Syarat Jabatan - Jabatan Data Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_data_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_data_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_jabatan_data_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_jabatan_data_list')

            now = timezone.now()
            qs = MaAnSjJabatanData.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_jabatan_data_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jabatan data berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_jabatan_data_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjJabatanData.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_jabatan_data__icontains=search_query)
            | Q(nama_jabatan_data__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjJabatanDataTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_data', 'create')
def sj_jabatan_data_create(request):
    if request.method == 'POST':
        form = MaAnSjJabatanDataForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Data berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-data-form-success": {"message": "Jabatan Data berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_data_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_data_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-data-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjJabatanDataForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_data', 'edit')
def sj_jabatan_data_edit(request, pk):
    obj = get_object_or_404(MaAnSjJabatanData, id=pk)
    if request.method == 'POST':
        form = MaAnSjJabatanDataForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Data berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-data-form-success": {"message": "Jabatan Data berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_data_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_data_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-data-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjJabatanDataForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_data', 'delete')
def sj_jabatan_data_delete(request, pk):
    obj = get_object_or_404(MaAnSjJabatanData, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jabatan Data berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_jabatan_data_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_data/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_orang', 'view')
def sj_jabatan_orang_list(request):
    export_qs = MaAnSjJabatanOrang.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjJabatanOrangTable,
        filename_prefix='ma_an_sj_jabatan_orang_export',
        title='Syarat Jabatan - Jabatan Orang Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_orang_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_orang_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_jabatan_orang_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_jabatan_orang_list')

            now = timezone.now()
            qs = MaAnSjJabatanOrang.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_jabatan_orang_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jabatan orang berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_jabatan_orang_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjJabatanOrang.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_jabatan_orang__icontains=search_query)
            | Q(nama_jabatan_orang__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjJabatanOrangTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_orang', 'create')
def sj_jabatan_orang_create(request):
    if request.method == 'POST':
        form = MaAnSjJabatanOrangForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Orang berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-orang-form-success": {"message": "Jabatan Orang berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_orang_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_orang_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-orang-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjJabatanOrangForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_orang', 'edit')
def sj_jabatan_orang_edit(request, pk):
    obj = get_object_or_404(MaAnSjJabatanOrang, id=pk)
    if request.method == 'POST':
        form = MaAnSjJabatanOrangForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Orang berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-orang-form-success": {"message": "Jabatan Orang berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_orang_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_orang_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-orang-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjJabatanOrangForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_orang', 'delete')
def sj_jabatan_orang_delete(request, pk):
    obj = get_object_or_404(MaAnSjJabatanOrang, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jabatan Orang berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_jabatan_orang_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_orang/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_benda', 'view')
def sj_jabatan_benda_list(request):
    export_qs = MaAnSjJabatanBenda.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjJabatanBendaTable,
        filename_prefix='ma_an_sj_jabatan_benda_export',
        title='Syarat Jabatan - Jabatan Benda Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_benda_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_jabatan_benda_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_jabatan_benda_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_analisis_jabatan', 'ma_an_sj_jabatan_benda', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_jabatan_benda_list')

            now = timezone.now()
            qs = MaAnSjJabatanBenda.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_jabatan_benda_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jabatan benda berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_jabatan_benda_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjJabatanBenda.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_jabatan_benda__icontains=search_query)
            | Q(nama_jabatan_benda__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjJabatanBendaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_benda', 'create')
def sj_jabatan_benda_create(request):
    if request.method == 'POST':
        form = MaAnSjJabatanBendaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Benda berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-benda-form-success": {"message": "Jabatan Benda berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_benda_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_benda_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-benda-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjJabatanBendaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_benda', 'edit')
def sj_jabatan_benda_edit(request, pk):
    obj = get_object_or_404(MaAnSjJabatanBenda, id=pk)
    if request.method == 'POST':
        form = MaAnSjJabatanBendaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jabatan Benda berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jabatan-benda-form-success": {"message": "Jabatan Benda berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jabatan_benda_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jabatan_benda_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jabatan-benda-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjJabatanBendaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jabatan_benda', 'delete')
def sj_jabatan_benda_delete(request, pk):
    obj = get_object_or_404(MaAnSjJabatanBenda, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jabatan Benda berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_jabatan_benda_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jabatan_benda/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_upaya_fisik', 'view')
def sj_upaya_fisik_list(request):
    export_qs = MaAnSjUpayaFisik.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjUpayaFisikTable,
        filename_prefix='ma_an_sj_upaya_fisik_export',
        title='Syarat Jabatan - Upaya Fisik Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_upaya_fisik_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_upaya_fisik_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_upaya_fisik_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_upaya_fisik_list')

            now = timezone.now()
            qs = MaAnSjUpayaFisik.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_upaya_fisik_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data upaya fisik berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_upaya_fisik_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjUpayaFisik.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_upaya__icontains=search_query)
            | Q(nama_upaya__icontains=search_query)
            | Q(deskripsi_upaya__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjUpayaFisikTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_upaya_fisik', 'create')
def sj_upaya_fisik_create(request):
    if request.method == 'POST':
        form = MaAnSjUpayaFisikForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Upaya Fisik berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-upaya-fisik-form-success": {"message": "Upaya Fisik berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_upaya_fisik_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_upaya_fisik_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-upaya-fisik-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjUpayaFisikForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_upaya_fisik', 'edit')
def sj_upaya_fisik_edit(request, pk):
    obj = get_object_or_404(MaAnSjUpayaFisik, id=pk)
    if request.method == 'POST':
        form = MaAnSjUpayaFisikForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Upaya Fisik berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-upaya-fisik-form-success": {"message": "Upaya Fisik berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_upaya_fisik_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_upaya_fisik_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-upaya-fisik-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjUpayaFisikForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_upaya_fisik', 'delete')
def sj_upaya_fisik_delete(request, pk):
    obj = get_object_or_404(MaAnSjUpayaFisik, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Upaya Fisik berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_upaya_fisik_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_upaya_fisik/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pengetahuan_kerja', 'view')
def sj_pengetahuan_kerja_list(request):
    export_qs = MaAnSjPengetahuanKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjPengetahuanKerjaTable,
        filename_prefix='ma_an_sj_pengetahuan_kerja_export',
        title='Syarat Jabatan - Pengetahuan Kerja Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_pengetahuan_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_pengetahuan_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_pengetahuan_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list')

            now = timezone.now()
            qs = MaAnSjPengetahuanKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_pengetahuan_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data pengetahuan kerja berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjPengetahuanKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_pengetahuan__icontains=search_query)
            | Q(nama_pengetahuan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjPengetahuanKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pengetahuan_kerja', 'create')
def sj_pengetahuan_kerja_create(request):
    if request.method == 'POST':
        form = MaAnSjPengetahuanKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pengetahuan Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pengetahuan-kerja-form-success": {"message": "Pengetahuan Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pengetahuan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjPengetahuanKerjaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pengetahuan_kerja', 'edit')
def sj_pengetahuan_kerja_edit(request, pk):
    obj = get_object_or_404(MaAnSjPengetahuanKerja, id=pk)
    if request.method == 'POST':
        form = MaAnSjPengetahuanKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pengetahuan Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pengetahuan-kerja-form-success": {"message": "Pengetahuan Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pengetahuan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjPengetahuanKerjaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pengetahuan_kerja', 'delete')
def sj_pengetahuan_kerja_delete(request, pk):
    obj = get_object_or_404(MaAnSjPengetahuanKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Pengetahuan Kerja berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_pengetahuan_kerja_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pengetahuan_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_keterampilan_kerja', 'view')
def sj_keterampilan_kerja_list(request):
    export_qs = MaAnSjKeterampilanKerja.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjKeterampilanKerjaTable,
        filename_prefix='ma_an_sj_keterampilan_kerja_export',
        title='Syarat Jabatan - Keterampilan Kerja Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_keterampilan_kerja_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_keterampilan_kerja_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_keterampilan_kerja_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_keterampilan_kerja_list')

            now = timezone.now()
            qs = MaAnSjKeterampilanKerja.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_keterampilan_kerja_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data keterampilan kerja berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_keterampilan_kerja_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjKeterampilanKerja.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_keterampilan__icontains=search_query)
            | Q(nama_keterampilan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjKeterampilanKerjaTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_keterampilan_kerja', 'create')
def sj_keterampilan_kerja_create(request):
    if request.method == 'POST':
        form = MaAnSjKeterampilanKerjaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Keterampilan Kerja berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-keterampilan-kerja-form-success": {"message": "Keterampilan Kerja berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_keterampilan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_keterampilan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-keterampilan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjKeterampilanKerjaForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_keterampilan_kerja', 'edit')
def sj_keterampilan_kerja_edit(request, pk):
    obj = get_object_or_404(MaAnSjKeterampilanKerja, id=pk)
    if request.method == 'POST':
        form = MaAnSjKeterampilanKerjaForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Keterampilan Kerja berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-keterampilan-kerja-form-success": {"message": "Keterampilan Kerja berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_keterampilan_kerja_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_keterampilan_kerja_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-keterampilan-kerja-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjKeterampilanKerjaForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_keterampilan_kerja', 'delete')
def sj_keterampilan_kerja_delete(request, pk):
    obj = get_object_or_404(MaAnSjKeterampilanKerja, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Keterampilan Kerja berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_keterampilan_kerja_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_keterampilan_kerja/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_fungsional', 'view')
def sj_pelatihan_fungsional_list(request):
    export_qs = MaAnSjPelatihanFungsional.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjPelatihanFungsionalTable,
        filename_prefix='ma_an_sj_pelatihan_fungsional_export',
        title='Syarat Jabatan - Pelatihan Fungsional Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_pelatihan_fungsional_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_pelatihan_fungsional_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_pelatihan_fungsional_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list')

            now = timezone.now()
            qs = MaAnSjPelatihanFungsional.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_pelatihan_fungsional_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data pelatihan fungsional berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjPelatihanFungsional.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_pelatihan__icontains=search_query)
            | Q(nama_pelatihan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjPelatihanFungsionalTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_fungsional', 'create')
def sj_pelatihan_fungsional_create(request):
    if request.method == 'POST':
        form = MaAnSjPelatihanFungsionalForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pelatihan Fungsional berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pelatihan-fungsional-form-success": {"message": "Pelatihan Fungsional berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pelatihan-fungsional-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjPelatihanFungsionalForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_fungsional', 'edit')
def sj_pelatihan_fungsional_edit(request, pk):
    obj = get_object_or_404(MaAnSjPelatihanFungsional, id=pk)
    if request.method == 'POST':
        form = MaAnSjPelatihanFungsionalForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pelatihan Fungsional berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pelatihan-fungsional-form-success": {"message": "Pelatihan Fungsional berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pelatihan-fungsional-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjPelatihanFungsionalForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_fungsional', 'delete')
def sj_pelatihan_fungsional_delete(request, pk):
    obj = get_object_or_404(MaAnSjPelatihanFungsional, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Pelatihan Fungsional berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_pelatihan_fungsional_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_fungsional/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jenis_kelamin', 'view')
def sj_jenis_kelamin_list(request):
    export_qs = MaAnSjJenisKelamin.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjJenisKelaminTable,
        filename_prefix='ma_an_sj_jenis_kelamin_export',
        title='Syarat Jabatan - Jenis Kelamin Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_jenis_kelamin_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_jenis_kelamin_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_jenis_kelamin_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_analisis_jabatan', 'ma_an_sj_jenis_kelamin', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_jenis_kelamin_list')

            now = timezone.now()
            qs = MaAnSjJenisKelamin.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_jenis_kelamin_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data jenis kelamin berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_jenis_kelamin_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjJenisKelamin.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_jenis_kelamin__icontains=search_query)
            | Q(nama_jenis_kelamin__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjJenisKelaminTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jenis_kelamin', 'create')
def sj_jenis_kelamin_create(request):
    if request.method == 'POST':
        form = MaAnSjJenisKelaminForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Kelamin berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jenis-kelamin-form-success": {"message": "Jenis Kelamin berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jenis_kelamin_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jenis_kelamin_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jenis-kelamin-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjJenisKelaminForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jenis_kelamin', 'edit')
def sj_jenis_kelamin_edit(request, pk):
    obj = get_object_or_404(MaAnSjJenisKelamin, id=pk)
    if request.method == 'POST':
        form = MaAnSjJenisKelaminForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Jenis Kelamin berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-jenis-kelamin-form-success": {"message": "Jenis Kelamin berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_jenis_kelamin_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_jenis_kelamin_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-jenis-kelamin-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjJenisKelaminForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_jenis_kelamin', 'delete')
def sj_jenis_kelamin_delete(request, pk):
    obj = get_object_or_404(MaAnSjJenisKelamin, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Jenis Kelamin berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_jenis_kelamin_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_jenis_kelamin/delete.html', {'obj': obj})


@ensure_csrf_cookie
@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_teknis', 'view')
def sj_pelatihan_teknis_list(request):
    export_qs = MaAnSjPelatihanTeknis.objects.filter(deleted_at__isnull=True)
    export_resp = handle_datatable_export(
        request,
        export_qs,
        MaAnSjPelatihanTeknisTable,
        filename_prefix='ma_an_sj_pelatihan_teknis_export',
        title='Syarat Jabatan - Pelatihan Teknis Export',
    )
    if export_resp is not None:
        return export_resp

    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        content_type = request.headers.get('Content-Type', '') or ''
        if 'application/json' in content_type:
            import json
            try:
                payload = request.body.decode('utf-8') if isinstance(request.body, (bytes, bytearray)) else (request.body or '')
                data = json.loads(payload or '{}')
            except Exception:
                data = {}
            action = data.get('action')
            if action == 'save_selection':
                page_key = data.get('page_key', 'ma_an_sj_pelatihan_teknis_list')
                selected_ids = data.get('selected_ids', [])
                UserTableSelection.objects.update_or_create(
                    user=request.user,
                    page_key=page_key,
                    defaults={'selected_ids': selected_ids},
                )
                return JsonResponse({'success': True, 'count': len(selected_ids)})
            if action == 'load_selection':
                page_key = data.get('page_key', 'ma_an_sj_pelatihan_teknis_list')
                try:
                    selection = UserTableSelection.objects.get(user=request.user, page_key=page_key)
                    return JsonResponse({'success': True, 'selected_ids': selection.selected_ids})
                except UserTableSelection.DoesNotExist:
                    return JsonResponse({'success': True, 'selected_ids': []})

    if request.method == 'POST' and 'action' in request.POST:
        action = request.POST.get('action')
        selected_ids = request.POST.getlist('selected_ids')
        if not selected_ids:
            single_id = request.POST.get('id')
            if single_id:
                selected_ids = [single_id]
        if not selected_ids:
            try:
                selection = UserTableSelection.objects.get(user=request.user, page_key='ma_an_sj_pelatihan_teknis_list')
                selected_ids = selection.selected_ids or []
            except UserTableSelection.DoesNotExist:
                selected_ids = []

        if action in ('bulk_delete', 'delete_single'):
            required_func = 'bulk_delete' if action == 'bulk_delete' else 'delete'
            if not check_permission(request.user, 'manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_teknis', required_func):
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak memiliki izin'}, status=403)
                raise PermissionDenied

            if not selected_ids:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'error': 'Tidak ada item yang dipilih'}, status=400)
                messages.error(request, 'Tidak ada item yang dipilih')
                return redirect('manajemen_analisis_jabatan:sj_pelatihan_teknis_list')

            now = timezone.now()
            qs = MaAnSjPelatihanTeknis.objects.filter(id__in=selected_ids, deleted_at__isnull=True)
            affected = qs.update(deleted_at=now)
            UserTableSelection.objects.filter(user=request.user, page_key='ma_an_sj_pelatihan_teknis_list').delete()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': True, 'deleted': True, 'count': affected, 'ids': selected_ids})
            messages.success(request, f'{affected} data pelatihan teknis berhasil dihapus')
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_teknis_list')

    search_query = request.GET.get('search', '').strip()
    qs = MaAnSjPelatihanTeknis.objects.filter(deleted_at__isnull=True)
    if search_query:
        qs = qs.filter(
            Q(kode_pelatihan__icontains=search_query)
            | Q(nama_pelatihan__icontains=search_query)
        )
    qs = qs.order_by('id')

    table = MaAnSjPelatihanTeknisTable(qs)
    table.request = request
    per_page = request.GET.get('per_page', '10')
    try:
        per_page = int(per_page)
        if per_page not in [10, 25, 50, 100]:
            per_page = 10
    except (ValueError, TypeError):
        per_page = 10
    RequestConfig(request, paginate={'per_page': per_page}).configure(table)

    context = {
        'table': table,
        'total': qs.count(),
        'search_query': search_query,
    }
    is_htmx = request.headers.get('HX-Request') or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if is_htmx:
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/partials/_table.html', context)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/list.html', context)


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_teknis', 'create')
def sj_pelatihan_teknis_create(request):
    if request.method == 'POST':
        form = MaAnSjPelatihanTeknisForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pelatihan Teknis berhasil ditambahkan')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pelatihan-teknis-form-success": {"message": "Pelatihan Teknis berhasil ditambahkan", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pelatihan_teknis_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_teknis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pelatihan-teknis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/form.html', {'form': form, 'edit_mode': False})

    form = MaAnSjPelatihanTeknisForm()
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/form.html', {'form': form, 'edit_mode': False})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_teknis', 'edit')
def sj_pelatihan_teknis_edit(request, pk):
    obj = get_object_or_404(MaAnSjPelatihanTeknis, id=pk)
    if request.method == 'POST':
        form = MaAnSjPelatihanTeknisForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pelatihan Teknis berhasil diupdate')
            if request.headers.get('HX-Request'):
                return HttpResponse('', headers={
                    'HX-Trigger': '{"ma-an-sj-pelatihan-teknis-form-success": {"message": "Pelatihan Teknis berhasil diupdate", "redirect": "%s"}}' % reverse('manajemen_analisis_jabatan:sj_pelatihan_teknis_list'),
                })
            return redirect('manajemen_analisis_jabatan:sj_pelatihan_teknis_list')
        if request.headers.get('HX-Request'):
            import json
            errors = []
            field_errors = {}
            try:
                for name, errs in form.errors.items():
                    if name == '__all__':
                        errors.extend([str(e) for e in errs])
                    else:
                        field_errors[name] = [str(e) for e in errs]
                        errors.extend([str(e) for e in errs])
            except Exception:
                errors = ['Periksa kembali input Anda.']
            resp = HttpResponse(status=204)
            resp['HX-Trigger'] = json.dumps({'ma-an-sj-pelatihan-teknis-form-invalid': {'errors': errors, 'fieldErrors': field_errors}})
            return resp
        return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})

    form = MaAnSjPelatihanTeknisForm(instance=obj)
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/form.html', {'form': form, 'edit_mode': True, 'obj': obj})


@permission_required_403('manajemen_analisis_jabatan', 'ma_an_sj_pelatihan_teknis', 'delete')
def sj_pelatihan_teknis_delete(request, pk):
    obj = get_object_or_404(MaAnSjPelatihanTeknis, id=pk)
    if request.method == 'POST':
        obj.deleted_at = timezone.now()
        obj.save(update_fields=['deleted_at'])
        messages.success(request, 'Pelatihan Teknis berhasil dihapus')
        return redirect('manajemen_analisis_jabatan:sj_pelatihan_teknis_list')
    return render(request, 'manajemen_analisis_jabatan/access/ma_an_sj_pelatihan_teknis/delete.html', {'obj': obj})
