#!/bin/bash

echo "======================================="
echo "🐍 Starting ESIMPEG Python Application"
echo "======================================="

# Wait for MySQL
echo "⏳ Waiting for MySQL..."
while ! mysqladmin ping -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_PASSWORD" --silent --skip-ssl; do
    echo "⏳ MySQL is unavailable - sleeping..."
    sleep 2
done
echo "✅ MySQL is up and running!"

# Skip Redis check for now
echo "ℹ️ Skipping Redis check - will use database cache instead"

# Create database if not exists
echo "🗄️ Setting up database..."
mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_PASSWORD" --skip-ssl -e "
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
" 2>/dev/null || echo "⚠️ Database setup skipped (might already exist)"

# Run migrations
echo "🔄 Running database migrations..."
python manage.py makemigrations --noinput
python manage.py migrate --noinput

# Collect static files
echo "📁 Collecting static files..."
python manage.py collectstatic --noinput

# Create superuser if not exists
echo "👤 Creating superuser..."
python manage.py shell -c "
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@esimpeg.com', 'admin123')
    print('✅ Superuser created: admin/admin123')
else:
    print('ℹ️ Superuser already exists')
"

# Load initial data
echo "📊 Loading initial data..."
python manage.py loaddata initial_data.json 2>/dev/null || echo "ℹ️ No initial data to load"

echo "======================================="
echo "🚀 Starting Django development server..."
echo "🌐 Access at: http://localhost:8005"
echo "🔧 Admin at: http://localhost:8005/admin"
echo "👤 Login: admin / admin123"
echo "======================================="

# Start Django server
exec "$@"
